import { base44 } from './base44Client';


export const Produto = base44.entities.Produto;

export const Preparacao = base44.entities.Preparacao;

export const Producao = base44.entities.Producao;

export const HistoricoEstoque = base44.entities.HistoricoEstoque;

export const Configuracao = base44.entities.Configuracao;

export const RegistroTemperatura = base44.entities.RegistroTemperatura;

export const RegistroManutencao = base44.entities.RegistroManutencao;

export const Venda = base44.entities.Venda;

export const CategoriaProduto = base44.entities.CategoriaProduto;

export const Organizacao = base44.entities.Organizacao;

export const MembroEquipe = base44.entities.MembroEquipe;

export const Fatura = base44.entities.Fatura;



// auth sdk:
export const User = base44.auth;