import { createClient } from '@base44/sdk';
// import { getAccessToken } from '@base44/sdk/utils/auth-utils';

// Create a client with authentication required
export const base44 = createClient({
  appId: "690b33fa7c04b9c3304273d6", 
  requiresAuth: true // Ensure authentication is required for all operations
});
