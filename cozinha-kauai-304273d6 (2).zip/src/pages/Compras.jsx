import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  ShoppingCart, 
  Download, 
  Filter,
  AlertTriangle,
  CheckCircle
} from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useOrganization } from "@/components/auth/OrganizationProvider";

export default function Compras() {
  const { organizacao } = useOrganization();
  const [filtroCategoria, setFiltroCategoria] = useState("all");
  const [filtroPraca, setFiltroPraca] = useState("all");

  const { data: produtos = [], isLoading } = useQuery({
    queryKey: ['produtos', organizacao?.id],
    queryFn: async () => {
        if (!organizacao?.id) return [];
        const res = await base44.entities.Produto.filter({ organizacao_id: organizacao.id }, undefined, 1000);
        return Array.isArray(res) ? res : [];
    },
    enabled: !!organizacao?.id,
  });

  const safeProdutos = Array.isArray(produtos) ? produtos : [];

  const produtosComprar = safeProdutos.filter(p => {
    const precisaComprar = p.estoque_atual < p.par_stock && p.par_stock > 0;
    const matchCategoria = filtroCategoria === "all" || p.categoria === filtroCategoria;
    const matchPraca = filtroPraca === "all" || p.praca === filtroPraca;
    return precisaComprar && matchCategoria && matchPraca;
  });

  const produtosOk = safeProdutos.filter(p => 
    p.estoque_atual >= p.par_stock && p.par_stock > 0
  );

  const handleExportCSV = () => {
    const headers = ['Nome', 'Categoria', 'Praça', 'Estoque Atual', 'Par-Stock', 'Falta', 'Unidade', 'Custo Unit.', 'Custo Total'];
    const rows = produtosComprar.map(p => {
      const falta = p.par_stock - p.estoque_atual;
      return [
        `"${(p.nome || "").replace(/"/g, '""')}"`,
        `"${(p.categoria || "").replace(/"/g, '""')}"`,
        `"${(p.praca || "").replace(/"/g, '""')}"`,
        p.estoque_atual.toString().replace('.', ','),
        p.par_stock.toString().replace('.', ','),
        falta.toFixed(2).replace('.', ','),
        `"${(p.unidade || "")}"`,
        (p.custo_unitario?.toFixed(2) || '0.00').replace('.', ','),
        (falta * (p.custo_unitario || 0)).toFixed(2).replace('.', ',')
      ];
    });

    const csv = "\uFEFF" + [
      headers.join(';'),
      ...rows.map(row => row.join(';'))
    ].join('\n');

    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `lista-compras-${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const categorias = [...new Set(safeProdutos.map(p => p.categoria))];
  const pracas = [...new Set(safeProdutos.map(p => p.praca))];

  const custoTotalCompras = produtosComprar.reduce((sum, p) => {
    const falta = p.par_stock - p.estoque_atual;
    return sum + (falta * (p.custo_unitario || 0));
  }, 0);

  return (
    <div className="p-4 md:p-8 min-h-screen">
      <div className="max-w-7xl mx-auto space-y-6">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
              <ShoppingCart className="w-8 h-8 text-orange-600" />
              Lista de Compras
            </h1>
            <p className="text-gray-600 mt-1">Produtos que precisam ser repostos</p>
          </div>
          <Button
            onClick={handleExportCSV}
            disabled={produtosComprar.length === 0}
            className="gap-2 bg-gradient-to-r from-orange-500 to-amber-600 hover:from-orange-600 hover:to-amber-700"
          >
            <Download className="w-4 h-4" />
            Exportar CSV
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="border-red-200 bg-red-50/50">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-red-800">
                Produtos p/ Comprar
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-baseline gap-2">
                <span className="text-4xl font-bold text-red-600">
                  {produtosComprar.length}
                </span>
                <AlertTriangle className="w-6 h-6 text-red-500" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-green-200 bg-green-50/50">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-green-800">
                Produtos OK
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-baseline gap-2">
                <span className="text-4xl font-bold text-green-600">
                  {produtosOk.length}
                </span>
                <CheckCircle className="w-6 h-6 text-green-500" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-orange-200 bg-orange-50/50">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-orange-800">
                Custo Estimado
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-orange-600">
                R$ {custoTotalCompras.toFixed(2)}
              </div>
            </CardContent>
          </Card>
        </div>

        <Card className="border-orange-200/50 shadow-lg">
          <CardHeader className="bg-gradient-to-r from-orange-50 to-amber-50">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
              <CardTitle className="flex items-center gap-2">
                <Filter className="w-5 h-5 text-orange-600" />
                Filtros
              </CardTitle>
              <div className="flex gap-3">
                <Select value={filtroCategoria} onValueChange={setFiltroCategoria}>
                  <SelectTrigger className="w-40">
                    <SelectValue placeholder="Categoria" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todas</SelectItem>
                    {categorias.map(cat => (
                      <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                <Select value={filtroPraca} onValueChange={setFiltroPraca}>
                  <SelectTrigger className="w-40">
                    <SelectValue placeholder="Praça" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todas</SelectItem>
                    {pracas.map(p => (
                      <SelectItem key={p} value={p}>{p}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardHeader>
        </Card>

        <Card className="border-orange-200/50 shadow-lg">
          <CardHeader className="bg-gradient-to-r from-orange-50 to-amber-50">
            <CardTitle>Produtos para Comprar</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            {produtosComprar.length === 0 ? (
              <div className="p-12 text-center">
                <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
                <p className="text-lg font-medium text-gray-900">
                  Nenhum produto precisa de reposição
                </p>
                <p className="text-gray-500 mt-1">
                  Todos os produtos estão com estoque adequado
                </p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-orange-50">
                      <TableHead>Produto</TableHead>
                      <TableHead>Categoria</TableHead>
                      <TableHead>Praça</TableHead>
                      <TableHead>Estoque</TableHead>
                      <TableHead>Par-Stock</TableHead>
                      <TableHead>Falta</TableHead>
                      <TableHead>Custo Unit.</TableHead>
                      <TableHead>Custo Total</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {produtosComprar.map((produto) => {
                      const falta = produto.par_stock - produto.estoque_atual;
                      const custoTotal = falta * (produto.custo_unitario || 0);
                      
                      return (
                        <TableRow key={produto.id} className="hover:bg-orange-50/50">
                          <TableCell className="font-medium">{produto.nome}</TableCell>
                          <TableCell>
                            <Badge variant="outline" className="bg-orange-50 text-orange-700 border-orange-200">
                              {produto.categoria}
                            </Badge>
                          </TableCell>
                          <TableCell>{produto.praca}</TableCell>
                          <TableCell className="text-red-600 font-medium">
                            {produto.estoque_atual} {produto.unidade}
                          </TableCell>
                          <TableCell>
                            {produto.par_stock} {produto.unidade}
                          </TableCell>
                          <TableCell className="font-bold text-red-700">
                            {falta.toFixed(1)} {produto.unidade}
                          </TableCell>
                          <TableCell>
                            R$ {produto.custo_unitario?.toFixed(2) || '0.00'}
                          </TableCell>
                          <TableCell className="font-semibold">
                            R$ {custoTotal.toFixed(2)}
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}