import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { 
  ChefHat, 
  ArrowRight, 
  CheckCircle2,
  Star,
  MessageCircle,
  Smartphone,
  ShieldCheck,
  TrendingUp,
  Trash2,
  ClipboardList,
  AlertTriangle,
  ChevronDown,
  ChevronUp,
  DollarSign,
  Sparkles,
  Utensils,
  Instagram,
  Facebook,
  Linkedin,
  Youtube
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

// Components
const FaqItem = ({ question, answer }) => {
  const [isOpen, setIsOpen] = useState(false);
  return (
    <div className="border-b border-gray-200 last:border-0">
      <button 
        className="w-full py-4 flex items-center justify-between text-left focus:outline-none group"
        onClick={() => setIsOpen(!isOpen)}
      >
        <span className="font-semibold text-gray-900 group-hover:text-orange-600 transition-colors">{question}</span>
        {isOpen ? <ChevronUp className="w-5 h-5 text-gray-500" /> : <ChevronDown className="w-5 h-5 text-gray-500" />}
      </button>
      <AnimatePresence>
        {isOpen && (
          <motion.div 
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="overflow-hidden"
          >
            <p className="pb-4 text-gray-600 leading-relaxed">{answer}</p>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

const BenefitCard = ({ icon: Icon, title, description }) => (
  <motion.div 
    initial={{ opacity: 0, y: 20 }}
    whileInView={{ opacity: 1, y: 0 }}
    viewport={{ once: true }}
    className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 hover:shadow-xl hover:-translate-y-1 transition-all flex gap-4 group"
  >
    <div className="w-12 h-12 bg-orange-100 rounded-xl flex items-center justify-center flex-shrink-0 group-hover:bg-orange-600 transition-colors">
      <Icon className="w-6 h-6 text-orange-600 group-hover:text-white transition-colors" />
    </div>
    <div>
      <h3 className="font-bold text-gray-900 text-lg mb-2">{title}</h3>
      <p className="text-gray-600 text-sm leading-relaxed">{description}</p>
    </div>
  </motion.div>
);

const DishCard = ({ image, name, cost, price, profit, delay }) => (
  <motion.div 
    initial={{ opacity: 0, scale: 0.9 }}
    whileInView={{ opacity: 1, scale: 1 }}
    viewport={{ once: true }}
    transition={{ duration: 0.5, delay }}
    className="relative group overflow-hidden rounded-2xl shadow-2xl aspect-[4/5] cursor-pointer"
  >
    <img src={image} alt={name} className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" />
    <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-transparent opacity-90 md:opacity-0 md:group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-6">
      <h3 className="text-white text-2xl font-bold mb-3">{name}</h3>
      <div className="grid grid-cols-3 gap-3 text-white/90 bg-white/10 backdrop-blur-md rounded-lg p-3 border border-white/10">
        <div>
          <p className="text-[10px] text-gray-300 uppercase tracking-wider">Custo</p>
          <p className="font-semibold text-red-400">R$ {cost}</p>
        </div>
        <div>
          <p className="text-[10px] text-gray-300 uppercase tracking-wider">Venda</p>
          <p className="font-semibold text-green-400">R$ {price}</p>
        </div>
        <div>
          <p className="text-[10px] text-gray-300 uppercase tracking-wider">Margem</p>
          <p className="font-bold text-amber-400">{profit}%</p>
        </div>
      </div>
      <div className="mt-4 pt-3 border-t border-white/20 flex items-center gap-2 text-xs text-gray-300">
        <Sparkles className="w-3 h-3 text-amber-400" />
        <span>Análise em tempo real</span>
      </div>
    </div>
    {/* Mobile Label */}
    <div className="absolute bottom-4 left-4 md:hidden bg-black/60 backdrop-blur-md px-3 py-1 rounded-lg border border-white/10">
        <p className="text-white font-bold text-sm">{name}</p>
    </div>
  </motion.div>
);

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-white font-sans text-gray-900 overflow-x-hidden">
      
      {/* Navigation */}
      <nav className="fixed w-full bg-white/90 backdrop-blur-md z-50 border-b border-orange-100/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2 group">
            <div className="w-10 h-10 bg-gray-900 rounded-lg flex items-center justify-center shadow-lg group-hover:bg-orange-600 transition-colors">
              <ChefHat className="w-6 h-6 text-white" />
            </div>
            <span className="font-bold text-xl tracking-tight text-gray-900">
              Cozinha<span className="text-orange-600">ChefPro</span>
            </span>
          </Link>
          <div className="hidden md:flex items-center gap-8">
            <a href="#beneficios" className="text-gray-600 hover:text-orange-600 font-medium transition-colors">Benefícios</a>
            <a href="#analise" className="text-gray-600 hover:text-orange-600 font-medium transition-colors">Análise</a>
            <a href="#planos" className="text-gray-600 hover:text-orange-600 font-medium transition-colors">Planos</a>
          </div>
          <div className="flex items-center gap-4">
            <Link to={createPageUrl("Dashboard")}>
              <Button variant="ghost" className="font-semibold text-gray-700 hover:text-orange-600 hover:bg-orange-50">
                Entrar
              </Button>
            </Link>
            <Link to={createPageUrl("SetupOrganizacao")}>
              <Button className="bg-orange-600 hover:bg-orange-700 text-white font-bold shadow-lg shadow-orange-200/50 hover:shadow-orange-300/50 transition-all hover:-translate-y-0.5">
                Testar Agora
              </Button>
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="pt-32 pb-20 lg:pt-40 lg:pb-32 bg-gradient-to-br from-orange-50 via-white to-amber-50 relative overflow-hidden">
        {/* Background Elements */}
        <div className="absolute top-0 right-0 w-1/3 h-full bg-orange-100/30 -skew-x-12 translate-x-32 pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-64 h-64 bg-amber-200/20 rounded-full blur-3xl pointer-events-none" />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="flex flex-col lg:flex-row items-center gap-12 lg:gap-20">
            
            {/* Text Content */}
            <div className="flex-1 text-center lg:text-left">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6 }}
              >
                <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white border border-orange-200 text-orange-700 font-bold text-xs uppercase tracking-wide mb-6 shadow-sm">
                  <Sparkles className="w-3.5 h-3.5" />
                  Sistema feito por Chef para Chefs
                </div>
                <h1 className="text-4xl lg:text-6xl font-extrabold tracking-tight text-gray-900 mb-6 leading-[1.15]">
                  Controle total da sua cozinha <br className="hidden lg:block"/>
                  <span className="text-transparent bg-clip-text bg-gradient-to-r from-orange-600 to-amber-600">
                    sem planilhas e sem perdas.
                  </span>
                </h1>
                <p className="text-lg lg:text-xl text-gray-600 mb-8 leading-relaxed max-w-2xl mx-auto lg:mx-0">
                  Estoque, validade, CMV, temperaturas, etiquetas e limpeza em um único sistema. Domine sua operação hoje.
                </p>
                
                <div className="flex flex-col sm:flex-row items-center gap-4 justify-center lg:justify-start">
                  <Link to={createPageUrl("SetupOrganizacao")} className="w-full sm:w-auto">
                    <Button size="lg" className="bg-gray-900 hover:bg-gray-800 text-white h-14 px-8 text-lg shadow-xl hover:shadow-2xl transition-all w-full">
                      Testar Agora <ArrowRight className="ml-2 w-5 h-5" />
                    </Button>
                  </Link>
                  <a href="https://wa.me/5582981656009" target="_blank" rel="noopener noreferrer" className="w-full sm:w-auto">
                    <Button size="lg" variant="outline" className="border-2 border-green-500 text-green-600 hover:bg-green-50 h-14 px-8 text-lg w-full bg-white">
                      <MessageCircle className="mr-2 w-5 h-5" /> Falar no WhatsApp
                    </Button>
                  </a>
                </div>
              </motion.div>
            </div>

            {/* Hero Image Composition */}
            <div className="flex-1 relative w-full max-w-lg lg:max-w-none">
              <motion.div 
                 initial={{ opacity: 0, scale: 0.95 }}
                 animate={{ opacity: 1, scale: 1 }}
                 transition={{ duration: 0.8, delay: 0.2 }}
                 className="relative"
              >
                <div className="absolute -inset-2 bg-gradient-to-tr from-orange-500 to-amber-500 rounded-[2rem] blur-lg opacity-30"></div>
                <img 
                  src="https://images.unsplash.com/photo-1577219491135-ce391730fb2c?q=80&w=2577&auto=format&fit=crop" 
                  alt="Chef profissional na cozinha usando tablet" 
                  className="relative rounded-[2rem] shadow-2xl border-4 border-white w-full object-cover aspect-[4/3]"
                />
                
                {/* Floating Cards */}
                <motion.div 
                  animate={{ y: [0, -8, 0] }}
                  transition={{ repeat: Infinity, duration: 4 }}
                  className="absolute -bottom-6 -left-6 bg-white p-4 rounded-xl shadow-xl border border-gray-100 hidden md:flex items-center gap-4"
                >
                  <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                    <DollarSign className="w-6 h-6 text-green-600" />
                  </div>
                  <div>
                    <p className="text-xs text-gray-500 font-semibold uppercase">Lucro Mensal</p>
                    <p className="text-xl font-bold text-gray-900">+28%</p>
                  </div>
                </motion.div>

                <motion.div 
                   animate={{ y: [0, 8, 0] }}
                   transition={{ repeat: Infinity, duration: 5, delay: 1 }}
                   className="absolute -top-6 -right-6 bg-white p-4 rounded-xl shadow-xl border border-gray-100 hidden md:flex items-center gap-4"
                >
                  <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center">
                    <Trash2 className="w-6 h-6 text-red-600" />
                  </div>
                  <div>
                    <p className="text-xs text-gray-500 font-semibold uppercase">Desperdício</p>
                    <p className="text-xl font-bold text-gray-900">-15%</p>
                  </div>
                </motion.div>
              </motion.div>
            </div>
          </div>
        </div>
      </section>

      {/* Authority Proof Section */}
      <section className="py-12 bg-gray-900 text-white border-b border-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            {[
              { icon: ChefHat, text: "Criado por Chef Executivo" },
              { icon: CheckCircle2, text: "Usado por Cozinhas Profissionais" },
              { icon: ShieldCheck, text: "Validado em Alto Volume" },
              { icon: Star, text: "Desenvolvido na Prática" }
            ].map((item, idx) => (
              <div key={idx} className="flex flex-col items-center gap-3 group hover:-translate-y-1 transition-transform duration-300">
                <item.icon className="w-8 h-8 text-orange-500 group-hover:text-orange-400" />
                <span className="text-sm font-medium text-gray-300 group-hover:text-white transition-colors">{item.text}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section id="beneficios" className="py-24 bg-white relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Resultados reais para sua cozinha</h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Não vendemos apenas software. Entregamos paz de espírito para quem vive na pressão.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            <BenefitCard 
              icon={Trash2} 
              title="Evite perdas por vencimento" 
              description="Alertas automáticos antes dos produtos vencerem. Pare de jogar dinheiro no lixo."
            />
            <BenefitCard 
              icon={TrendingUp} 
              title="Tenha controle real do CMV" 
              description="Saiba exatamente quanto custa cada prato e onde está sua margem de lucro."
            />
            <BenefitCard 
              icon={ClipboardList} 
              title="Padronize sua cozinha" 
              description="Fichas técnicas acessíveis para toda a equipe. O mesmo sabor, sempre."
            />
            <BenefitCard 
              icon={ShieldCheck} 
              title="Evite multas da vigilância" 
              description="Controle de temperatura, limpeza e etiquetas em dia. Durma tranquilo."
            />
            <BenefitCard 
              icon={Smartphone} 
              title="Tenha dados em tempo real" 
              description="Acesse do celular, tablet ou computador. Sua cozinha na palma da mão."
            />
            <BenefitCard 
              icon={CheckCircle2} 
              title="Fim do papel e planilhas" 
              description="Centralize tudo em um lugar só. Mais organização, menos dor de cabeça."
            />
          </div>
        </div>
      </section>

      {/* Visual Analysis / Food Section */}
      <section id="analise" className="py-24 bg-gray-900 overflow-hidden relative">
        <div className="absolute inset-0 opacity-10 bg-[url('https://www.transparenttextures.com/patterns/food.png')] z-0" />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="flex flex-col md:flex-row justify-between items-end mb-12 gap-6">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
                Você sabe qual prato te dá lucro de verdade?
              </h2>
              <p className="text-gray-400 max-w-2xl text-lg">
                Nossa Engenharia de Cardápio mostra o que vender mais e o que tirar do menu.
                <span className="block mt-2 text-orange-500 font-medium text-sm animate-pulse">
                  Passe o mouse sobre os pratos (ou toque no celular) 👇
                </span>
              </p>
            </div>
            <Link to={createPageUrl("SetupOrganizacao")}>
              <Button className="bg-orange-600 hover:bg-orange-700 text-white shadow-lg shadow-orange-900/20" size="lg">
                Quero essa análise
              </Button>
            </Link>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <DishCard 
              image="https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=800&q=80"
              name="Salada Bowl"
              cost="12,50"
              price="45,00"
              profit="72"
              delay={0}
            />
            <DishCard 
              image="https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=800&q=80"
              name="Burger Artesanal"
              cost="18,90"
              price="52,00"
              profit="64"
              delay={0.2}
            />
            <DishCard 
              image="https://images.unsplash.com/photo-1551024601-562963525602?auto=format&fit=crop&w=800&q=80"
              name="Sobremesa"
              cost="8,20"
              price="32,00"
              profit="74"
              delay={0.4}
            />
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-24 bg-orange-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900">Simples como deve ser</h2>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8 relative">
            {/* Connecting Line (Desktop) */}
            <div className="hidden md:block absolute top-12 left-[16%] right-[16%] h-0.5 bg-orange-200 z-0 border-t-2 border-dashed border-orange-300"></div>

            {[
              { step: "1", title: "Crie sua conta", desc: "Rápido e sem burocracia." },
              { step: "2", title: "Cadastre produtos", desc: "Importe via IA ou planilha." },
              { step: "3", title: "Controle tudo", desc: "Pelo celular, de onde estiver." }
            ].map((item, idx) => (
              <div key={idx} className="relative z-10 flex flex-col items-center text-center group">
                <div className="w-24 h-24 bg-white rounded-full border-4 border-orange-500 flex items-center justify-center text-3xl font-bold text-orange-600 shadow-lg mb-6 group-hover:scale-110 transition-transform duration-300">
                  {item.step}
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">{item.title}</h3>
                <p className="text-gray-600">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="planos" className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-lg mx-auto">
            <div className="bg-gray-900 rounded-[2rem] p-8 md:p-12 shadow-2xl border border-gray-800 text-center relative overflow-hidden hover:shadow-orange-900/20 transition-shadow duration-500">
              <div className="absolute top-0 right-0 bg-gradient-to-bl from-orange-500 to-red-600 text-white text-xs font-bold px-4 py-2 rounded-bl-xl uppercase tracking-wider shadow-lg">
                Oferta Especial
              </div>
              
              <h2 className="text-2xl font-bold text-white mb-2">Plano Único CozinhaChefPro</h2>
              <p className="text-gray-400 mb-8">Tudo o que você precisa, sem pegadinhas.</p>
              
              <div className="flex items-center justify-center text-white mb-2">
                <span className="text-2xl text-gray-500 mr-2 font-light line-through">R$ 199</span>
                <span className="text-6xl font-extrabold tracking-tighter">R$ 99</span>
                <span className="text-xl text-gray-400 self-end mb-2 ml-1">/mês</span>
              </div>
              
              <div className="h-px w-full bg-gray-800 my-8"></div>

              <ul className="text-left space-y-4 mb-10 text-gray-300">
                {[
                  "Acesso completo ao sistema",
                  "Todos os módulos liberados",
                  "Suporte direto via WhatsApp",
                  "Atualizações automáticas",
                  "Sem contrato de fidelidade"
                ].map((item, i) => (
                  <li key={i} className="flex items-center gap-3">
                    <div className="w-5 h-5 rounded-full bg-green-900/50 flex items-center justify-center flex-shrink-0">
                      <CheckCircle2 className="w-3.5 h-3.5 text-green-500" />
                    </div>
                    {item}
                  </li>
                ))}
              </ul>

              <Link to={createPageUrl("SetupOrganizacao")}>
                <Button className="w-full bg-orange-600 hover:bg-orange-700 text-white h-14 text-lg font-bold shadow-lg hover:scale-105 transition-transform rounded-xl">
                  Quero começar agora
                </Button>
              </Link>
              <p className="text-xs text-gray-500 mt-4">
                Teste grátis por 7 dias. Cancele quando quiser.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-24 bg-gray-50">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900">Perguntas Frequentes</h2>
          </div>
          
          <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6 md:p-8 space-y-2">
            <FaqItem 
              question="Funciona no celular?" 
              answer="Sim! O sistema é 100% otimizado para celulares e tablets, além do computador. Você pode acessar de qualquer lugar."
            />
            <FaqItem 
              question="Posso cancelar quando quiser?" 
              answer="Com certeza. Não temos contrato de fidelidade. Você usa enquanto fizer sentido para o seu negócio."
            />
            <FaqItem 
              question="Serve para restaurante pequeno?" 
              answer="Perfeitamente. O sistema foi desenhado para ser simples e eficiente, ideal tanto para quem está começando quanto para grandes operações."
            />
            <FaqItem 
              question="Tem limite de usuários?" 
              answer="Não. Você pode cadastrar toda a sua equipe (cozinheiros, estoquistas, gerentes) sem custo adicional."
            />
            <FaqItem 
              question="O suporte é humano?" 
              answer="Sim! Nosso suporte é feito por pessoas reais via WhatsApp, prontas para ajudar no dia a dia da operação."
            />
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-24 bg-gradient-to-br from-orange-600 to-red-700 text-white text-center relative overflow-hidden">
        {/* Decorative food pattern opacity */}
        <div className="absolute inset-0 opacity-10 bg-[url('https://www.transparenttextures.com/patterns/food.png')] z-0" />
        
        <div className="max-w-4xl mx-auto px-4 relative z-10">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Agora é sua vez de assumir o controle.
          </h2>
          <p className="text-xl text-orange-100 mb-12 max-w-2xl mx-auto">
            Pare de perder dinheiro todos os dias com falta de controle.
          </p>
          
          <Link to={createPageUrl("SetupOrganizacao")}>
            <Button size="lg" className="bg-white text-orange-700 hover:bg-gray-100 h-16 px-12 text-xl font-bold shadow-2xl hover:scale-105 transition-transform rounded-xl">
              Teste agora o CozinhaChefPro
            </Button>
          </Link>
          <p className="mt-6 text-sm text-orange-200 opacity-80">
            Junte-se a chefs que levam a gestão a sério.
          </p>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-950 text-gray-400 py-12 border-t border-gray-900">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <div className="flex items-center justify-center gap-2 text-white mb-4">
            <ChefHat className="w-6 h-6" />
            <span className="font-bold text-xl">CozinhaChefPro</span>
          </div>
          <div className="flex justify-center gap-6 mb-8">
            <a href="https://instagram.com/cozinhachefpro" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-orange-500 transition-colors">
              <Instagram className="w-6 h-6" />
            </a>
            <a href="https://facebook.com" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-blue-600 transition-colors">
              <Facebook className="w-6 h-6" />
            </a>
            <a href="https://linkedin.com" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-blue-500 transition-colors">
              <Linkedin className="w-6 h-6" />
            </a>
            <a href="https://youtube.com" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-red-600 transition-colors">
              <Youtube className="w-6 h-6" />
            </a>
          </div>
          <div className="flex justify-center gap-6 mb-8 text-sm">
            <a href="#" className="hover:text-white transition-colors">Termos de Uso</a>
            <a href="#" className="hover:text-white transition-colors">Privacidade</a>
            <a href="#" className="hover:text-white transition-colors">Suporte</a>
          </div>
          <p className="text-sm text-gray-600">
            © 2024 CozinhaChefPro. Feito com 🔥 e código.
          </p>
          <p className="text-sm text-gray-600 mt-2">
            Contato: contato@cozinhachefpro.com.br
          </p>
        </div>
      </footer>
    </div>
  );
}