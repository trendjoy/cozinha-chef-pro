import React, { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useOrganization } from "@/components/auth/OrganizationProvider";
import LandingPage from "./LandingPage";

export default function Index() {
  return <LandingPage />;
}