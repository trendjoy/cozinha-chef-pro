import React, { useState } from 'react';
import { base44 } from "@/api/base44Client";
import { useNavigate } from 'react-router-dom';
import { useQuery } from "@tanstack/react-query";
import { useOrganization } from "@/components/auth/OrganizationProvider";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { ChefHat, ArrowRight, Loader2, LayoutDashboard, Building2, LogOut } from "lucide-react";
import { toast } from "sonner";

export default function SetupOrganizacao() {
  const navigate = useNavigate();
  const { user, switchOrganization } = useOrganization();
  const [nome, setNome] = useState("");
  const [loading, setLoading] = useState(false);

  // Verifica se o usuário já tem organizações (Recuperação de conta)
  const { data: minhasOrgs = [] } = useQuery({
    queryKey: ['recover-orgs', user?.email],
    queryFn: async () => {
      if (!user?.email) return [];
      try {
        const membros = await base44.entities.MembroEquipe.filter({ email_usuario: user.email });
        if (!membros?.length) return [];
        
        const orgs = await Promise.all(membros.map(async (m) => {
          if (!m.organizacao_id) return null;
          try {
            const org = await base44.entities.Organizacao.get(m.organizacao_id);
            return org && org.status !== 'cancelado' ? org : null;
          } catch { return null; }
        }));
        
        return orgs.filter(Boolean);
      } catch (err) {
        console.error(err);
        return [];
      }
    },
    enabled: !!user?.email
  });

  const handleCriarConta = async (e) => {
    e.preventDefault();
    if (!nome) return;

    setLoading(true);
    try {
      const currentUser = await base44.auth.me();
      
      // 1. Criar Organização
      const novaOrg = await base44.entities.Organizacao.create({
        nome: nome,
        dono_email: currentUser.email,
        plano: 'free',
        status: 'ativo'
      });

      // 2. Vincular usuário como Admin desta organização
      await base44.entities.MembroEquipe.create({
        organizacao_id: novaOrg.id,
        email_usuario: currentUser.email,
        cargo: 'admin',
        status: 'ativo'
      });

      toast.success("Cozinha criada com sucesso!");
      localStorage.setItem('chefpro_org_id', novaOrg.id);
      window.location.href = "/Dashboard"; 
      
    } catch (error) {
      console.error(error);
      toast.error("Erro ao criar organização. Tente novamente.");
      setLoading(false);
    }
  };

  const handleRecover = (orgId) => {
    switchOrganization(orgId);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-orange-600 to-amber-700 p-4">
      <Card className="w-full max-w-md shadow-2xl border-0">
        <CardHeader className="text-center pb-2">
          <div className="mx-auto w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mb-4">
            <ChefHat className="w-8 h-8 text-orange-600" />
          </div>
          <CardTitle className="text-2xl font-bold text-gray-900">Bem-vindo ao ChefPro</CardTitle>
          <CardDescription className="text-base">
            {minhasOrgs.length > 0 
              ? "Encontramos contas vinculadas ao seu email." 
              : "Vamos configurar seu ambiente de trabalho."}
          </CardDescription>
          {user?.email && (
            <p className="text-xs text-gray-500 mt-1 flex items-center justify-center gap-1">
              Logado como: <span className="font-medium text-gray-700">{user.email}</span>
            </p>
          )}
        </CardHeader>
        <CardContent>
          {minhasOrgs.length > 0 && (
            <div className="mb-6 space-y-3">
              <p className="text-sm font-medium text-gray-700 text-center">
                Deseja acessar uma cozinha existente?
              </p>
              <div className="space-y-2 max-h-40 overflow-y-auto pr-1">
                {minhasOrgs.map((org) => (
                  <Button
                    key={org.id}
                    variant="outline"
                    className="w-full justify-between h-auto py-3 px-4 border-orange-200 hover:bg-orange-50 hover:text-orange-700 hover:border-orange-300"
                    onClick={() => handleRecover(org.id)}
                  >
                    <span className="flex items-center gap-2">
                      <Building2 className="w-4 h-4 text-orange-500" />
                      <span className="font-medium truncate">{org.nome}</span>
                    </span>
                    <ArrowRight className="w-4 h-4 opacity-50" />
                  </Button>
                ))}
              </div>
              <div className="relative py-2">
                <div className="absolute inset-0 flex items-center">
                  <span className="w-full border-t border-gray-200" />
                </div>
                <div className="relative flex justify-center text-xs uppercase">
                  <span className="bg-white px-2 text-gray-500">Ou crie uma nova</span>
                </div>
              </div>
            </div>
          )}

          <form onSubmit={handleCriarConta} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="nome" className="text-gray-700">Nome do seu Restaurante / Cozinha</Label>
              <div className="relative">
                <LayoutDashboard className="absolute left-3 top-3 w-5 h-5 text-gray-400" />
                <Input 
                  id="nome"
                  placeholder="Ex: Cantina da Nona" 
                  className="pl-10 h-12 text-lg border-orange-200 focus:border-orange-500 focus:ring-orange-500"
                  value={nome}
                  onChange={(e) => setNome(e.target.value)}
                  required
                />
              </div>
            </div>

            <Button 
              type="submit" 
              className="w-full h-12 text-lg bg-orange-600 hover:bg-orange-700 text-white shadow-lg shadow-orange-200"
              disabled={loading}
            >
              {loading ? (
                <>
                  <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                  Configurando...
                </>
              ) : (
                <>
                  Começar Agora
                  <ArrowRight className="w-5 h-5 ml-2" />
                </>
              )}
            </Button>
            
            <div className="flex justify-center mt-4">
              <Button 
                type="button" 
                variant="ghost" 
                size="sm"
                className="text-gray-500 hover:text-red-600 hover:bg-red-50"
                onClick={() => base44.auth.logout()}
              >
                <LogOut className="w-4 h-4 mr-2" />
                Sair e trocar de conta
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}