import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  DollarSign, 
  Upload, 
  Calendar as CalendarIcon, 
  ShoppingBag,
  Search,
  TrendingUp
} from "lucide-react";
import { format } from "date-fns";
import ModalImportVendas from "../components/vendas/ModalImportVendas";
import { useOrganization } from "@/components/auth/OrganizationProvider";

export default function Vendas() {
  const [modalImport, setModalImport] = useState(false);
  const [busca, setBusca] = useState("");
  const { organizacao } = useOrganization();

  const { data: vendas = [], isLoading } = useQuery({
    queryKey: ['vendas', organizacao?.id],
    queryFn: () => {
      if (!organizacao?.id) return [];
      return base44.entities.Venda.filter({ organizacao_id: organizacao.id }, '-data_venda', 500);
    },
    enabled: !!organizacao?.id,
  });

  // Cálculos rápidos (últimos dados carregados)
  const totalVendas = vendas.reduce((acc, v) => acc + (v.valor_total || 0), 0);
  const totalItens = vendas.reduce((acc, v) => acc + (v.quantidade || 0), 0);

  const vendasFiltradas = vendas.filter(v => 
    (v.nome_produto || '').toLowerCase().includes(busca.toLowerCase()) ||
    (v.canal || '').toLowerCase().includes(busca.toLowerCase())
  );

  return (
    <div className="p-4 md:p-8 min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto space-y-6">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
              <ShoppingBag className="w-8 h-8 text-emerald-600" />
              Registro de Vendas
            </h1>
            <p className="text-gray-600 mt-1">Importe relatórios diários para controle financeiro e de saída.</p>
          </div>
          
          <Button 
            onClick={() => setModalImport(true)}
            className="bg-emerald-600 hover:bg-emerald-700 text-white gap-2 shadow-md"
          >
            <Upload className="w-4 h-4" />
            Importar CSV Diário
          </Button>
        </div>

        {/* Cards de Resumo (Baseado na lista atual) */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card className="border-emerald-200 shadow-sm">
            <CardContent className="p-6 flex justify-between items-center">
              <div>
                <p className="text-sm text-gray-500 font-medium">Total Registrado (Lista)</p>
                <h3 className="text-2xl font-bold text-gray-900">R$ {totalVendas.toFixed(2)}</h3>
              </div>
              <div className="p-3 bg-emerald-100 rounded-full text-emerald-600">
                <DollarSign className="w-6 h-6" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-blue-200 shadow-sm">
            <CardContent className="p-6 flex justify-between items-center">
              <div>
                <p className="text-sm text-gray-500 font-medium">Itens Vendidos</p>
                <h3 className="text-2xl font-bold text-gray-900">{totalItens}</h3>
              </div>
              <div className="p-3 bg-blue-100 rounded-full text-blue-600">
                <ShoppingBag className="w-6 h-6" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-purple-200 shadow-sm">
            <CardContent className="p-6 flex justify-between items-center">
              <div>
                <p className="text-sm text-gray-500 font-medium">Ticket Médio Aprox.</p>
                <h3 className="text-2xl font-bold text-gray-900">
                  R$ {totalItens > 0 ? (totalVendas / totalItens).toFixed(2) : '0.00'}
                </h3>
              </div>
              <div className="p-3 bg-purple-100 rounded-full text-purple-600">
                <TrendingUp className="w-6 h-6" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Lista de Vendas */}
        <Card className="border-gray-200 shadow-md">
          <CardHeader className="flex flex-row items-center justify-between pb-2 border-b">
            <CardTitle className="text-lg">Histórico de Vendas</CardTitle>
            <div className="relative w-64">
              <Search className="absolute left-2 top-2.5 h-4 w-4 text-gray-400" />
              <Input 
                placeholder="Buscar item ou canal..." 
                value={busca}
                onChange={(e) => setBusca(e.target.value)}
                className="pl-8 h-9"
              />
            </div>
          </CardHeader>
          <CardContent className="p-0">
            <div className="max-h-[600px] overflow-auto">
              <table className="w-full">
                <thead className="bg-gray-50 sticky top-0">
                  <tr className="text-xs text-gray-500 uppercase text-left">
                    <th className="p-4 font-medium">Data</th>
                    <th className="p-4 font-medium">Item</th>
                    <th className="p-4 font-medium text-center">Qtd</th>
                    <th className="p-4 font-medium text-right">Valor Total</th>
                    <th className="p-4 font-medium text-center">Canal</th>
                    <th className="p-4 font-medium text-right">Origem</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {isLoading ? (
                     <tr><td colSpan="6" className="p-8 text-center text-gray-500">Carregando vendas...</td></tr>
                  ) : vendasFiltradas.length === 0 ? (
                     <tr><td colSpan="6" className="p-8 text-center text-gray-500">Nenhuma venda encontrada.</td></tr>
                  ) : (
                    vendasFiltradas.map((venda) => (
                      <tr key={venda.id} className="hover:bg-gray-50/50 transition-colors text-sm">
                        <td className="p-4 text-gray-600 whitespace-nowrap">
                          {(() => {
                            try {
                              return venda.data_venda ? format(new Date(venda.data_venda), "dd/MM HH:mm") : "-";
                            } catch {
                              return "-";
                            }
                          })()}
                        </td>
                        <td className="p-4 font-medium text-gray-900">
                          {venda.nome_produto}
                          {venda.codigo_produto && <span className="text-xs text-gray-400 ml-2">({venda.codigo_produto})</span>}
                        </td>
                        <td className="p-4 text-center text-gray-700 font-medium">
                          {venda.quantidade}
                        </td>
                        <td className="p-4 text-right text-emerald-700 font-bold">
                          R$ {(venda.valor_total || 0).toFixed(2)}
                        </td>
                        <td className="p-4 text-center">
                          <Badge variant="outline" className="bg-white">
                            {venda.canal}
                          </Badge>
                        </td>
                        <td className="p-4 text-right text-xs text-gray-400 max-w-[150px] truncate" title={venda.arquivo_importacao}>
                          {venda.arquivo_importacao || '-'}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>

        {modalImport && (
          <ModalImportVendas 
            onClose={() => setModalImport(false)}
            onSuccess={() => setModalImport(false)} // Query auto-updates via invalidate inside modal if handled, or we rely on list refresh
          />
        )}
      </div>
    </div>
  );
}