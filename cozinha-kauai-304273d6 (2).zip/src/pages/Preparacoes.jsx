import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Plus, Search, Sparkles } from "lucide-react";

import TabelaPreparacoes from "../components/preparacoes/TabelaPreparacoes";
import ModalPreparacao from "../components/preparacoes/ModalPreparacao";
import ModalImportarFichas from "../components/preparacoes/ModalImportarFichas";
import BotaoImportarPadroes from "../components/preparacoes/BotaoImportarPadroes";
import { useOrganization } from "@/components/auth/OrganizationProvider";

export default function Preparacoes() {
  const [busca, setBusca] = useState("");
  const [modalAberto, setModalAberto] = useState(false);
  const [modalImportIA, setModalImportIA] = useState(false);
  const [preparacaoEdit, setPreparacaoEdit] = useState(null);
  const { organizacao } = useOrganization();

  const queryClient = useQueryClient();

  const { data: preparacoes = [], isLoading } = useQuery({
    queryKey: ['preparacoes', organizacao?.id],
    queryFn: () => {
      if (!organizacao?.id) return [];
      return base44.entities.Preparacao.filter({ organizacao_id: organizacao.id });
    },
    enabled: !!organizacao?.id,
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.Preparacao.create({ ...data, organizacao_id: organizacao.id }),
    onSuccess: () => {
      queryClient.invalidateQueries(['preparacoes']);
      setModalAberto(false);
      setPreparacaoEdit(null);
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Preparacao.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries(['preparacoes']);
      setModalAberto(false);
      setPreparacaoEdit(null);
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Preparacao.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries(['preparacoes']);
    },
  });

  const handleSave = (data) => {
    if (preparacaoEdit) {
      updateMutation.mutate({ id: preparacaoEdit.id, data });
    } else {
      createMutation.mutate(data);
    }
  };

  const handleEdit = (preparacao) => {
    setPreparacaoEdit(preparacao);
    setModalAberto(true);
  };

  const handleDelete = (id) => {
    if (confirm('Tem certeza que deseja excluir esta preparação?')) {
      deleteMutation.mutate(id);
    }
  };

  const preparacoesFiltradas = preparacoes.filter(p =>
    p.nome?.toLowerCase().includes(busca.toLowerCase()) ||
    p.categoria?.toLowerCase().includes(busca.toLowerCase())
  );

  return (
    <div className="p-4 md:p-8 min-h-screen">
      <div className="max-w-7xl mx-auto space-y-6">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Preparações</h1>
            <p className="text-gray-600 mt-1">Gerencie receitas e fichas técnicas</p>
          </div>
          <div className="flex gap-3">
            <BotaoImportarPadroes />
            <Button
              variant="outline"
              onClick={() => setModalImportIA(true)}
              className="gap-2 bg-orange-100 text-orange-800 hover:bg-orange-200 border-orange-300"
            >
              <Sparkles className="w-4 h-4" />
              Importar Cardápio (Excel/Foto)
            </Button>
            <Button
              onClick={() => {
                setPreparacaoEdit(null);
                setModalAberto(true);
              }}
              className="gap-2 bg-gradient-to-r from-orange-500 to-amber-600 hover:from-orange-600 hover:to-amber-700"
            >
              <Plus className="w-4 h-4" />
              Nova Preparação
            </Button>
          </div>
        </div>

        <div className="bg-white rounded-xl border border-orange-200/50 shadow-lg p-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
            <Input
              placeholder="Buscar preparação..."
              value={busca}
              onChange={(e) => setBusca(e.target.value)}
              className="pl-10 border-orange-200 focus:border-orange-400"
            />
          </div>
        </div>

        <TabelaPreparacoes
          preparacoes={preparacoesFiltradas}
          loading={isLoading}
          onEdit={handleEdit}
          onDelete={handleDelete}
        />

        {modalAberto && (
          <ModalPreparacao
            preparacao={preparacaoEdit}
            onClose={() => {
              setModalAberto(false);
              setPreparacaoEdit(null);
            }}
            onSave={handleSave}
            saving={createMutation.isPending || updateMutation.isPending}
          />
        )}

        {modalImportIA && (
          <ModalImportarFichas
            onClose={() => setModalImportIA(false)}
            onSuccess={() => {
              queryClient.invalidateQueries(['preparacoes']);
            }}
          />
        )}
      </div>
    </div>
  );
}