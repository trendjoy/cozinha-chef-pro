import React from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ShieldCheck, Droplets, ThermometerSnowflake, Download } from "lucide-react";
import { Button } from "@/components/ui/button";
import { format } from "date-fns";
import { useOrganization } from "@/components/auth/OrganizationProvider";

import FormTemperatura from "../components/qualidade/FormTemperatura";
import FormManutencao from "../components/qualidade/FormManutencao";

const getStatusTemperatura = (equipamento, temp) => {
  const nome = (equipamento || "").toLowerCase();
  let min = 0, max = 4;

  if (nome.includes('congelad') || nome.includes('freezer')) {
    min = -18; max = -12;
  } else if (nome.includes('hortifr') || nome.includes('pista fria') || nome.includes('expositor')) {
    min = 2; max = 8;
  } else if (nome.includes('confeitaria') || nome.includes('sobremesa')) {
    min = 2; max = 6;
  }
  
  const fora = temp < min || temp > max;
  return { 
    variant: fora ? "destructive" : "outline",
    className: fora ? "" : "bg-green-50 text-green-700 border-green-200",
    faixa: `${min} a ${max}°C`
  };
};

export default function ControleQualidade() {
  const { organizacao } = useOrganization();
  const searchParams = new URLSearchParams(window.location.search);
  const defaultTab = searchParams.get("tab") || "temperatura";

  // Queries para as listas de histórico
  const { data: temps = [] } = useQuery({
    queryKey: ['registros-temperatura', organizacao?.id],
    queryFn: () => {
      if (!organizacao?.id) return [];
      return base44.entities.RegistroTemperatura.filter({ organizacao_id: organizacao.id }, '-created_date', 20);
    },
    enabled: !!organizacao?.id,
  });

  const { data: manutencoes = [] } = useQuery({
    queryKey: ['registros-manutencao', organizacao?.id],
    queryFn: () => {
      if (!organizacao?.id) return [];
      return base44.entities.RegistroManutencao.filter({ organizacao_id: organizacao.id }, '-created_date', 20);
    },
    enabled: !!organizacao?.id,
  });

  return (
    <div className="p-4 md:p-8 min-h-screen">
      <div className="max-w-6xl mx-auto space-y-6">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
              <ShieldCheck className="w-8 h-8 text-orange-600" />
              Controle de Qualidade
            </h1>
            <p className="text-gray-600 mt-1">
              Registros de temperatura, limpeza e manutenção de equipamentos
            </p>
          </div>
          <Button 
            onClick={() => {
              // Função simples de exportação para CSV baseada na aba atual
              const activeTab = document.querySelector('[role="tab"][data-state="active"]')?.dataset.value || defaultTab;
              let data = [];
              let filename = "";

              if (activeTab === "temperatura") {
                 data = temps;
                 filename = "registros_temperatura.csv";
              } else {
                 data = manutencoes;
                 filename = "registros_manutencao.csv";
              }

              if (!data || data.length === 0) {
                 alert("Sem dados para exportar.");
                 return;
              }

              const headers = Object.keys(data[0] || {}).join(";");
              const rows = data.map(row => 
                Object.values(row).map(value => {
                  const stringValue = String(value || "");
                  return `"${stringValue.replace(/"/g, '""')}"`;
                }).join(";")
              );

              const csvContent = "\uFEFF" + [headers, ...rows].join("\n");
              const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
              const link = document.createElement("a");
              const url = URL.createObjectURL(blob);

              link.setAttribute("href", url);
              link.setAttribute("download", filename);
              document.body.appendChild(link);
              link.click();
              document.body.removeChild(link);
            }} 
            variant="outline" 
            className="gap-2"
          >
            <Download className="w-4 h-4" />
            Exportar CSV
          </Button>
        </div>

        <Tabs defaultValue={defaultTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2 mb-8">
            <TabsTrigger value="temperatura" className="gap-2">
              <ThermometerSnowflake className="w-4 h-4" />
              Controle de Temperatura
            </TabsTrigger>
            <TabsTrigger value="manutencao" className="gap-2">
              <Droplets className="w-4 h-4" />
              Limpeza e Óleo
            </TabsTrigger>
          </TabsList>

          {/* ABA TEMPERATURA */}
          <TabsContent value="temperatura" className="space-y-6">
            <div className="grid lg:grid-cols-3 gap-6">
              {/* Coluna da Esquerda: Formulário */}
              <div className="lg:col-span-1">
                <Card className="border-blue-200 shadow-md">
                  <CardHeader className="bg-blue-50">
                    <CardTitle className="text-blue-800 text-lg">Novo Registro</CardTitle>
                  </CardHeader>
                  <CardContent className="p-0">
                    <FormTemperatura />
                  </CardContent>
                </Card>
              </div>

              {/* Coluna da Direita: Histórico */}
              <div className="lg:col-span-2">
                <Card className="border-gray-200 shadow-sm h-full">
                  <CardHeader>
                    <CardTitle>Últimos Registros</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {temps.length === 0 ? (
                        <p className="text-gray-500 text-center py-8">Nenhum registro encontrado.</p>
                      ) : (
                        temps.map((t) => (
                          <div key={t.id} className="flex items-start justify-between p-4 bg-gray-50 rounded-lg border border-gray-100">
                            <div>
                              <div className="flex items-center gap-2">
                                <h4 className="font-semibold text-gray-900">{t.equipamento}</h4>
                                {(() => {
                                  const status = getStatusTemperatura(t.equipamento, t.temperatura);
                                  return (
                                    <Badge variant={status.variant} className={status.className}>
                                      {t.temperatura}°C
                                    </Badge>
                                  );
                                })()}
                              </div>
                              <p className="text-sm text-gray-500 mt-1">
                                {t.periodo} • Resp: {t.responsavel} • Meta: {getStatusTemperatura(t.equipamento, t.temperatura).faixa}
                              </p>
                              {t.acao_corretiva && (
                                <p className="text-sm text-red-600 mt-2 bg-red-50 p-2 rounded border border-red-100">
                                  ⚠️ {t.acao_corretiva}
                                </p>
                              )}
                            </div>
                            <div className="text-xs text-gray-400 text-right">
                              {format(new Date(t.created_date), "dd/MM HH:mm")}
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>

          {/* ABA MANUTENÇÃO */}
          <TabsContent value="manutencao" className="space-y-6">
            <div className="grid lg:grid-cols-3 gap-6">
              {/* Coluna da Esquerda: Formulário */}
              <div className="lg:col-span-1">
                <Card className="border-green-200 shadow-md">
                  <CardHeader className="bg-green-50">
                    <CardTitle className="text-green-800 text-lg">Novo Registro</CardTitle>
                  </CardHeader>
                  <CardContent className="p-0">
                    <FormManutencao />
                  </CardContent>
                </Card>
              </div>

              {/* Coluna da Direita: Histórico */}
              <div className="lg:col-span-2">
                <Card className="border-gray-200 shadow-sm h-full">
                  <CardHeader>
                    <CardTitle>Histórico de Manutenção</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {manutencoes.length === 0 ? (
                        <p className="text-gray-500 text-center py-8">Nenhum registro encontrado.</p>
                      ) : (
                        manutencoes.map((m) => (
                          <div key={m.id} className="flex items-start justify-between p-4 bg-gray-50 rounded-lg border border-gray-100">
                            <div>
                              <div className="flex items-center gap-2">
                                <Badge className={
                                  m.tipo === 'Troca de Óleo' ? 'bg-amber-500' : 'bg-green-600'
                                }>
                                  {m.tipo}
                                </Badge>
                                <span className="font-semibold text-gray-900">{m.item}</span>
                              </div>
                              <p className="text-sm text-gray-500 mt-1">
                                Resp: {m.responsavel}
                              </p>
                              {m.observacoes && (
                                <p className="text-sm text-gray-600 mt-2 bg-white p-2 rounded border border-gray-200 italic">
                                  "{m.observacoes}"
                                </p>
                              )}
                            </div>
                            <div className="text-xs text-gray-400 text-right">
                              {format(new Date(m.created_date), "dd/MM/yyyy")}
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}