import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Wand2, 
  Download, 
  Image as ImageIcon, 
  Sparkles, 
  Loader2, 
  Share2,
  Copy,
  PenTool,
  MessageSquare,
  FileText,
  Check
} from "lucide-react";
import { toast } from "sonner";

const PROMPT_TEMPLATES = [
  {
    label: "Cozinha Dark Premium",
    prompt: "Professional commercial kitchen, dark cinematic lighting, chef working in background, selective focus, 8k resolution, hyperrealistic, elegant atmosphere, black and orange accents"
  },
  {
    label: "Chef em Ação (Close)",
    prompt: "Close up of professional chef hands plating a gourmet dish, fine dining, steam rising, dramatic lighting, culinary art, high detail, 4k"
  },
  {
    label: "Ingredientes Frescos",
    prompt: "Fresh vegetables and herbs on a rustic wooden table, dark background, professional food photography, top down view, natural lighting"
  },
  {
    label: "Prato Gourmet",
    prompt: "Michelin star dish presentation, dark slate plate, artistic plating, molecular gastronomy details, macro photography, dark moody lighting"
  }
];

const TEXT_TEMPLATES = [
  {
    label: "Post de WhatsApp",
    prompt: "Crie uma mensagem curta e persuasiva para um grupo de WhatsApp de chefs de cozinha, convidando para conhecer o sistema CozinhaChefPro. Destaque que é feito de chef para chef, sem planilhas. Inclua o link https://cozinhachefpro.base44.app/ e emojis."
  },
  {
    label: "Legenda Instagram (Prato)",
    prompt: "Crie uma legenda para Instagram de um restaurante sofisticado apresentando um novo prato de Risoto de Camarão. Use um tom elegante e convidativo. Inclua hashtags."
  },
  {
    label: "Convite Inauguração",
    prompt: "Escreva um texto curto para convidar clientes vips para a inauguração de um novo menu de degustação. Tom exclusivo e urgente."
  }
];

export default function Marketing() {
  // Image State
  const [prompt, setPrompt] = useState("");
  const [loading, setLoading] = useState(false);
  const [generatedImage, setGeneratedImage] = useState(null);

  // Text State
  const [textPrompt, setTextPrompt] = useState("");
  const [textLoading, setTextLoading] = useState(false);
  const [generatedText, setGeneratedText] = useState("");

  // Image Handlers
  const handleGenerate = async () => {
    if (!prompt) {
      toast.error("Por favor, descreva a imagem que deseja gerar.");
      return;
    }
    setLoading(true);
    setGeneratedImage(null);
    try {
      const res = await base44.integrations.Core.GenerateImage({
        prompt: prompt + ", photorealistic, 8k, high quality"
      });
      if (res && res.url) {
        setGeneratedImage(res.url);
        toast.success("Imagem gerada com sucesso!");
      } else {
        toast.error("Não foi possível gerar a imagem.");
      }
    } catch (error) {
      console.error("Erro ao gerar imagem:", error);
      toast.error("Erro ao gerar imagem.");
    } finally {
      setLoading(false);
    }
  };

  const handleDownload = async () => {
    if (!generatedImage) return;
    try {
      const response = await fetch(generatedImage);
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `chefpro-marketing-${Date.now()}.png`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
    } catch (error) {
      window.open(generatedImage, '_blank');
    }
  };

  // Text Handlers
  const handleGenerateText = async () => {
    if (!textPrompt) {
      toast.error("Por favor, descreva o texto que deseja gerar.");
      return;
    }
    setTextLoading(true);
    try {
      const res = await base44.integrations.Core.InvokeLLM({
        prompt: `Atue como um copywriter especialista em gastronomia e marketing para restaurantes. Crie o seguinte conteúdo: ${textPrompt}. O tom deve ser profissional, persuasivo e direto.`
      });
      setGeneratedText(res);
      toast.success("Texto gerado com sucesso!");
    } catch (error) {
      console.error("Erro ao gerar texto:", error);
      toast.error("Erro ao gerar texto.");
    } finally {
      setTextLoading(false);
    }
  };

  const handleCopyText = () => {
    if (!generatedText) return;
    navigator.clipboard.writeText(generatedText);
    toast.success("Texto copiado!");
  };

  return (
    <div className="p-4 md:p-8 min-h-screen bg-gray-50/50">
      <div className="max-w-5xl mx-auto space-y-8">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-2">
            <Wand2 className="w-8 h-8 text-orange-600" />
            Estúdio de Marketing AI
          </h1>
          <p className="text-gray-600 mt-2 text-lg">
            Crie imagens e textos profissionais para divulgar seu restaurante.
          </p>
        </div>

        <Tabs defaultValue="text" className="w-full">
          <TabsList className="grid w-full grid-cols-2 mb-8">
            <TabsTrigger value="text" className="gap-2">
              <MessageSquare className="w-4 h-4" />
              Gerador de Textos & Posts
            </TabsTrigger>
            <TabsTrigger value="image" className="gap-2">
              <ImageIcon className="w-4 h-4" />
              Gerador de Imagens
            </TabsTrigger>
          </TabsList>

          {/* TEXT GENERATOR TAB */}
          <TabsContent value="text">
            <div className="grid lg:grid-cols-2 gap-8">
              <div className="space-y-6">
                <Card className="border-orange-100 shadow-md">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <PenTool className="w-5 h-5 text-orange-500" />
                      Criar Copy / Legenda
                    </CardTitle>
                    <CardDescription>
                      Peça para a IA escrever posts, legendas ou emails.
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-gray-700">O que você quer escrever?</label>
                      <Textarea 
                        placeholder="Ex: Crie um post convidando para o Happy Hour com 50% de desconto..."
                        value={textPrompt}
                        onChange={(e) => setTextPrompt(e.target.value)}
                        className="h-32 resize-none text-base"
                      />
                    </div>

                    <div className="space-y-2">
                      <label className="text-xs font-medium text-gray-500 uppercase tracking-wider">Ideias Rápidas</label>
                      <div className="flex flex-col gap-2">
                        {TEXT_TEMPLATES.map((template, idx) => (
                          <Button
                            key={idx}
                            variant="outline"
                            size="sm"
                            className="justify-start h-auto py-2 px-3 text-left hover:bg-orange-50 hover:text-orange-700 border-gray-200"
                            onClick={() => setTextPrompt(template.prompt)}
                          >
                            <FileText className="w-4 h-4 mr-2 shrink-0" />
                            <span className="truncate">{template.label}</span>
                          </Button>
                        ))}
                      </div>
                    </div>

                    <Button 
                      onClick={handleGenerateText} 
                      disabled={textLoading || !textPrompt}
                      className="w-full h-12 text-lg bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-700 hover:to-amber-700 text-white shadow-lg shadow-orange-200"
                    >
                      {textLoading ? (
                        <>
                          <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                          Escrevendo...
                        </>
                      ) : (
                        <>
                          <Sparkles className="w-5 h-5 mr-2" />
                          Gerar Texto
                        </>
                      )}
                    </Button>
                  </CardContent>
                </Card>
              </div>

              <div className="space-y-6">
                <Card className="h-full border-gray-200 bg-white shadow-md flex flex-col">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <FileText className="w-5 h-5 text-gray-500" />
                      Resultado
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="flex-1 p-6 bg-gray-50/50 min-h-[400px] border-t border-gray-100 relative">
                    {generatedText ? (
                      <div className="space-y-4">
                        <div className="bg-white p-4 rounded-lg border border-gray-200 whitespace-pre-wrap text-gray-800 leading-relaxed shadow-sm">
                          {generatedText}
                        </div>
                        <Button onClick={handleCopyText} variant="outline" className="w-full gap-2">
                          <Copy className="w-4 h-4" />
                          Copiar Texto
                        </Button>
                      </div>
                    ) : (
                      <div className="flex flex-col items-center justify-center h-full text-gray-400 text-center">
                        <MessageSquare className="w-12 h-12 mb-3 opacity-20" />
                        <p>O texto gerado aparecerá aqui.</p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>

          {/* IMAGE GENERATOR TAB */}
          <TabsContent value="image">
            <div className="grid lg:grid-cols-2 gap-8">
              <div className="space-y-6">
                <Card className="border-orange-100 shadow-md">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Sparkles className="w-5 h-5 text-orange-500" />
                      Criar Nova Imagem
                    </CardTitle>
                    <CardDescription>
                      Descreva o que você quer ver ou use um modelo pronto.
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-gray-700">Descrição da Imagem (Prompt)</label>
                      <Textarea 
                        placeholder="Ex: Um prato de risoto de camarão em um prato preto, iluminação dramática..."
                        value={prompt}
                        onChange={(e) => setPrompt(e.target.value)}
                        className="h-32 resize-none text-base"
                      />
                    </div>

                    <div className="space-y-2">
                      <label className="text-xs font-medium text-gray-500 uppercase tracking-wider">Modelos Prontos</label>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        {PROMPT_TEMPLATES.map((template, idx) => (
                          <Button
                            key={idx}
                            variant="outline"
                            size="sm"
                            className="justify-start h-auto py-2 px-3 text-left hover:bg-orange-50 hover:text-orange-700 border-gray-200"
                            onClick={() => setPrompt(template.prompt)}
                          >
                            <span className="truncate">{template.label}</span>
                          </Button>
                        ))}
                      </div>
                    </div>

                    <Button 
                      onClick={handleGenerate} 
                      disabled={loading || !prompt}
                      className="w-full h-12 text-lg bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-700 hover:to-amber-700 text-white shadow-lg shadow-orange-200"
                    >
                      {loading ? (
                        <>
                          <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                          Gerando sua arte... (aprox. 10s)
                        </>
                      ) : (
                        <>
                          <Wand2 className="w-5 h-5 mr-2" />
                          Gerar Imagem
                        </>
                      )}
                    </Button>
                  </CardContent>
                </Card>
              </div>

              <div className="space-y-6">
                <Card className="h-full border-gray-200 bg-white shadow-md flex flex-col">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <ImageIcon className="w-5 h-5 text-gray-500" />
                      Resultado
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="flex-1 flex items-center justify-center p-6 bg-gray-50/50 min-h-[400px] border-t border-gray-100">
                    {loading ? (
                      <div className="text-center space-y-4">
                        <div className="relative w-20 h-20 mx-auto">
                          <div className="absolute inset-0 border-4 border-orange-200 rounded-full animate-pulse"></div>
                          <div className="absolute inset-0 border-4 border-orange-500 border-t-transparent rounded-full animate-spin"></div>
                        </div>
                        <p className="text-gray-500 font-medium animate-pulse">A inteligência artificial está desenhando...</p>
                      </div>
                    ) : generatedImage ? (
                      <div className="w-full space-y-4">
                        <div className="relative group rounded-xl overflow-hidden shadow-2xl border-4 border-white">
                          <img 
                            src={generatedImage} 
                            alt="Imagem Gerada" 
                            className="w-full h-auto object-cover"
                          />
                        </div>
                        <div className="flex gap-3">
                          <Button className="flex-1" onClick={handleDownload}>
                            <Download className="w-4 h-4 mr-2" />
                            Baixar Imagem
                          </Button>
                          <Button variant="outline" onClick={() => window.open(generatedImage, '_blank')}>
                            <Share2 className="w-4 h-4 mr-2" />
                            Abrir
                          </Button>
                        </div>
                      </div>
                    ) : (
                      <div className="text-center text-gray-400 max-w-xs mx-auto">
                        <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                          <Wand2 className="w-10 h-10 text-gray-300" />
                        </div>
                        <p>Sua imagem aparecerá aqui.</p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}