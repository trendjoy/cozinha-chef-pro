import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Shield, ShieldAlert, UserPlus, Mail, UserCog } from "lucide-react";
import { toast } from "sonner";

export default function Manager() {
  const [currentUser, setCurrentUser] = useState(null);
  
  React.useEffect(() => {
    base44.auth.me().then(setCurrentUser).catch(() => {});
  }, []);

  const { data: users = [], isLoading } = useQuery({
    queryKey: ['users'],
    queryFn: () => base44.entities.User.list(),
    enabled: !!currentUser && currentUser.role === 'admin',
  });

  const queryClient = useQueryClient();

  // Note: We can't create users via API, only invite. 
  // But we might be able to update roles if the user is admin.
  // However, usually role update is restricted too. 
  // For now, we will just list them.

  if (!currentUser) return <div className="p-8">Carregando...</div>;

  if (currentUser.role !== 'admin') {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] text-center p-8">
        <ShieldAlert className="w-16 h-16 text-red-500 mb-4" />
        <h1 className="text-2xl font-bold text-gray-900">Acesso Negado</h1>
        <p className="text-gray-600 mt-2">Esta área é restrita para administradores.</p>
      </div>
    );
  }

  return (
    <div className="p-4 md:p-8 min-h-screen">
      <div className="max-w-5xl mx-auto space-y-6">
        <div className="flex justify-between items-start">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
              <Shield className="w-8 h-8 text-indigo-600" />
              Painel Manager
            </h1>
            <p className="text-gray-600 mt-1">Gerenciamento de usuários e permissões</p>
          </div>
          
          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 max-w-md text-sm text-yellow-800">
            <div className="flex items-center gap-2 font-semibold mb-1">
              <UserPlus className="w-4 h-4" />
              Como adicionar usuários?
            </div>
            Para criar novos logins, utilize a função "Convidar Usuário" no painel administrativo da plataforma Base44 (fora deste app).
          </div>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <UserCog className="w-5 h-5" />
              Usuários do Sistema
            </CardTitle>
            <CardDescription>
              Lista de todos os usuários com acesso ao sistema Cozinha Kaua'i
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Nome</TableHead>
                  <TableHead>Email</TableHead>
                  <TableHead>Função (Role)</TableHead>
                  <TableHead>Data Cadastro</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  <TableRow>
                    <TableCell colSpan={4} className="text-center py-8">Carregando usuários...</TableCell>
                  </TableRow>
                ) : users.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={4} className="text-center py-8">Nenhum usuário encontrado.</TableCell>
                  </TableRow>
                ) : (
                  users.map((user) => (
                    <TableRow key={user.id}>
                      <TableCell className="font-medium">{user.full_name || 'Sem nome'}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Mail className="w-3 h-3 text-gray-400" />
                          {user.email}
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant={user.role === 'admin' ? 'default' : 'secondary'}>
                          {user.role === 'admin' ? 'Manager / Admin' : 'Usuário'}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-gray-500">
                        {new Date(user.created_date).toLocaleDateString()}
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}