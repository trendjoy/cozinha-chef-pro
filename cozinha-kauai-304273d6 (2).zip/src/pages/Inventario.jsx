import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Search, Save, ClipboardList, Archive, ChefHat, Filter, Sparkles, MessageCircle, Sprout, Box } from "lucide-react";
import ModalImportarProdutos from "../components/produtos/ModalImportarProdutos";
import { toast } from "sonner";
import { useOrganization } from "@/components/auth/OrganizationProvider";
import { useSearchParams } from "react-router-dom";

export default function Inventario() {
  const { organizacao } = useOrganization();
  const [searchParams] = useSearchParams();
  const initialTab = searchParams.get("tab") || "geral";
  
  const [busca, setBusca] = useState("");
  const [activeTab, setActiveTab] = useState(initialTab);
  const [categoriaFiltro, setCategoriaFiltro] = useState("todos");
  const [contagens, setContagens] = useState({}); // { id_produto: { primario: val, secundario: val } }
  const [alteracoesPendentes, setAlteracoesPendentes] = useState(false);
  const [modalImportIA, setModalImportIA] = useState(false);

  // Atualiza a tab se a URL mudar (opcional, mas bom para navegação)
  useEffect(() => {
    const tab = searchParams.get("tab");
    if (tab && ['geral', 'hortifruti'].includes(tab)) {
      setActiveTab(tab);
    }
  }, [searchParams]);

  const queryClient = useQueryClient();

  const { data: produtos = [], isLoading } = useQuery({
    queryKey: ['produtos-inventario', organizacao?.id],
    queryFn: () => {
      if (!organizacao?.id) return [];
      return base44.entities.Produto.filter({ organizacao_id: organizacao.id }, undefined, 1000);
    },
    enabled: !!organizacao?.id,
  });

  // Inicializa o estado de contagens com os valores atuais do banco quando os produtos carregam
  useEffect(() => {
    if (produtos.length > 0 && Object.keys(contagens).length === 0) {
      const inicial = {};
      produtos.forEach(p => {
        inicial[p.id] = {
          primario: p.estoque_primario || 0,
          secundario: p.estoque_atual || 0
        };
      });
      setContagens(inicial);
    }
  }, [produtos]);

  const { data: categoriasData = [] } = useQuery({
    queryKey: ['categorias-produto', organizacao?.id],
    queryFn: () => {
      if (!organizacao?.id) return [];
      return base44.entities.CategoriaProduto.filter({ organizacao_id: organizacao.id }, 'nome');
    },
    enabled: !!organizacao?.id,
  });

  // Use categorias do banco ou extraídas dos produtos se a lista estiver vazia (fallback)
  const categoriasDisponiveis = categoriasData.length > 0 
      ? categoriasData.map(c => c.nome)
      : [...new Set(produtos.map(p => p.categoria || "Outros"))];

  const categorias = ["todos", ...categoriasDisponiveis.sort()];

  const handleChange = (id, tipo, valor) => {
    setContagens(prev => ({
      ...prev,
      [id]: {
        ...prev[id],
        [tipo]: parseFloat(valor) || 0
      }
    }));
    setAlteracoesPendentes(true);
  };

  const mutation = useMutation({
    mutationFn: async () => {
      const updates = [];
      const historicos = [];
      const timestamp = new Date().toISOString();

      for (const produto of produtos) {
        const contagem = contagens[produto.id];
        if (!contagem) continue;

        // Verifica se houve mudança
        const mudouPrimario = contagem.primario !== (produto.estoque_primario || 0);
        const mudouSecundario = contagem.secundario !== (produto.estoque_atual || 0);

        if (mudouPrimario || mudouSecundario) {
          // Update Produto
          updates.push(
            base44.entities.Produto.update(produto.id, {
              estoque_primario: contagem.primario,
              estoque_atual: contagem.secundario
            })
          );

          // Gera histórico para Primário (Depósito)
          if (mudouPrimario) {
            historicos.push(
              base44.entities.HistoricoEstoque.create({
                organizacao_id: organizacao.id,
                tipo_item: "produto",
                item_id: produto.id,
                item_nome: produto.nome,
                movimento: "ajuste",
                quantidade: Math.abs(contagem.primario - (produto.estoque_primario || 0)),
                estoque_anterior: produto.estoque_primario || 0,
                estoque_novo: contagem.primario,
                motivo: "ajuste",
                observacao: "Inventário Depósito",
                responsavel: "Inventário",
                data_movimento: timestamp
              })
            );
          }

          // Gera histórico para Secundário (Cozinha)
          if (mudouSecundario) {
            historicos.push(
              base44.entities.HistoricoEstoque.create({
                organizacao_id: organizacao.id,
                tipo_item: "produto",
                item_id: produto.id,
                item_nome: produto.nome,
                movimento: "ajuste",
                quantidade: Math.abs(contagem.secundario - (produto.estoque_atual || 0)),
                estoque_anterior: produto.estoque_atual || 0,
                estoque_novo: contagem.secundario,
                motivo: "ajuste",
                observacao: "Inventário Cozinha",
                responsavel: "Inventário",
                data_movimento: timestamp
              })
            );
          }
        }
      }

      await Promise.all([...updates, ...historicos]);
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['produtos-inventario']);
      setAlteracoesPendentes(false);
      toast.success("Inventário atualizado com sucesso!");
    },
    onError: () => {
      toast.error("Erro ao salvar inventário.");
    }
  });

  const filteredProducts = produtos.filter(p => {
    const matchBusca = (p.nome || "").toLowerCase().includes(busca.toLowerCase()) || 
                       (p.codigo || "").toLowerCase().includes(busca.toLowerCase());
    
    let matchCat = true;

    if (activeTab === 'hortifruti') {
      const hortifrutiCats = ['Vegetais', 'Frutas', 'Hortaliças', 'Hortifruti', 'Legumes'];
      matchCat = hortifrutiCats.includes(p.categoria);
    } else {
      // Tab 'geral' -> obedece o dropdown
      matchCat = categoriaFiltro === "todos" || p.categoria === categoriaFiltro;
    }

    return matchBusca && matchCat;
  }).sort((a, b) => (a.nome || "").localeCompare(b.nome || ""));

  return (
    <div className="p-4 md:p-8 min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto space-y-6">
        
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
              <ClipboardList className="w-8 h-8 text-orange-600" />
              Inventário de Estoque
            </h1>
            <p className="text-gray-600 mt-1">Contagem física de Depósito (Primário) e Cozinha (Secundário)</p>
          </div>
          
          <div className="flex gap-2">
            <Button 
              onClick={() => mutation.mutate()} 
              disabled={!alteracoesPendentes || mutation.isPending}
              className={`gap-2 ${alteracoesPendentes ? 'bg-green-600 hover:bg-green-700 animate-pulse' : 'bg-gray-400'}`}
            >
              <Save className="w-4 h-4" />
              {mutation.isPending ? "Salvando..." : "Salvar Contagem"}
            </Button>

            <a
              href={base44.agents.getWhatsAppConnectURL('estoquista')}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center gap-2 px-4 py-2 text-sm font-medium transition-colors bg-green-500 text-white hover:bg-green-600 rounded-md h-10"
            >
               <MessageCircle className="w-4 h-4" />
               <span className="hidden md:inline">Conectar WhatsApp</span>
            </a>

            <Button
              variant="outline"
              onClick={() => setModalImportIA(true)}
              className="gap-2 bg-orange-100 text-orange-800 hover:bg-orange-200 border-orange-300"
            >
              <Sparkles className="w-4 h-4" />
              Importar (IA)
            </Button>
          </div>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2 lg:w-[400px]">
            <TabsTrigger value="geral" className="gap-2">
              <Box className="w-4 h-4" />
              Geral
            </TabsTrigger>
            <TabsTrigger value="hortifruti" className="gap-2 data-[state=active]:bg-green-100 data-[state=active]:text-green-800">
              <Sprout className="w-4 h-4" />
              Hortifruti
            </TabsTrigger>
          </TabsList>

          {/* Conteúdo Unificado mas filtrado pelo filteredProducts */}
          <div className="mt-4">
            <Card className="border-orange-200 shadow-sm">
              <CardHeader className="pb-3 bg-orange-50/30 border-b border-orange-100">
                <div className="flex flex-col md:flex-row gap-4">
                  <div className="flex-1 relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                    <Input 
                      placeholder="Buscar por nome ou código..." 
                      value={busca}
                      onChange={(e) => setBusca(e.target.value)}
                      className="pl-10 bg-white"
                    />
                  </div>
                  
                  {activeTab === 'geral' && (
                    <div className="w-full md:w-64 flex items-center gap-2">
                      <Filter className="w-4 h-4 text-gray-500" />
                      <Select value={categoriaFiltro} onValueChange={setCategoriaFiltro}>
                        <SelectTrigger className="bg-white">
                          <SelectValue placeholder="Filtrar Categoria" />
                        </SelectTrigger>
                        <SelectContent>
                          {categorias.map(c => (
                            <SelectItem key={c} value={c} className="capitalize">{c}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  )}
                  
                  {activeTab === 'hortifruti' && (
                     <div className="px-3 py-2 bg-green-50 text-green-700 text-sm rounded-md border border-green-100 font-medium">
                        Modo Hortifruti Ativo
                     </div>
                  )}
                </div>
              </CardHeader>
              <CardContent className="p-0">
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow className="bg-gray-50">
                        <TableHead className="w-[100px]">Código</TableHead>
                        <TableHead>Produto / Insumo</TableHead>
                        <TableHead className="w-[100px]">Un</TableHead>
                        <TableHead className="w-[150px] bg-blue-50 text-blue-700 text-center border-l border-blue-100">
                          <div className="flex flex-col items-center">
                            <Archive className="w-4 h-4 mb-1" />
                            Depósito
                          </div>
                        </TableHead>
                        <TableHead className="w-[150px] bg-orange-50 text-orange-700 text-center border-l border-orange-100">
                          <div className="flex flex-col items-center">
                            <ChefHat className="w-4 h-4 mb-1" />
                            Cozinha/Loja
                          </div>
                        </TableHead>
                        <TableHead className="w-[100px] text-right bg-gray-100">Total</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {isLoading ? (
                        <TableRow>
                          <TableCell colSpan={6} className="text-center py-8 text-gray-500">Carregando itens...</TableCell>
                        </TableRow>
                      ) : filteredProducts.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={6} className="text-center py-8 text-gray-500">Nenhum produto encontrado.</TableCell>
                        </TableRow>
                      ) : (
                        filteredProducts.map((produto) => {
                          const contagem = contagens[produto.id] || { primario: 0, secundario: 0 };
                          return (
                            <TableRow key={produto.id} className="hover:bg-gray-50">
                              <TableCell className="font-mono text-xs text-gray-500">{produto.codigo || '-'}</TableCell>
                              <TableCell>
                                <div className="font-medium">{produto.nome}</div>
                                <div className="text-xs text-gray-400">{produto.categoria}</div>
                              </TableCell>
                              <TableCell>
                                <Badge variant="outline" className="text-xs">{produto.unidade}</Badge>
                              </TableCell>
                              <TableCell className="bg-blue-50/30 border-l border-blue-100 p-2">
                                <Input 
                                  type="number" 
                                  min="0"
                                  step="0.01"
                                  value={contagem.primario}
                                  onChange={(e) => handleChange(produto.id, 'primario', e.target.value)}
                                  className="h-8 text-center bg-white border-blue-200 focus:border-blue-400"
                                />
                              </TableCell>
                              <TableCell className="bg-orange-50/30 border-l border-orange-100 p-2">
                                <Input 
                                  type="number" 
                                  min="0"
                                  step="0.01"
                                  value={contagem.secundario}
                                  onChange={(e) => handleChange(produto.id, 'secundario', e.target.value)}
                                  className="h-8 text-center bg-white border-orange-200 focus:border-orange-400"
                                />
                              </TableCell>
                              <TableCell className="text-right font-bold bg-gray-50/50">
                                {(contagem.primario + contagem.secundario).toFixed(2)}
                              </TableCell>
                            </TableRow>
                          );
                        })
                      )}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </div>
        </Tabs>

        {modalImportIA && (
          <ModalImportarProdutos
            onClose={() => setModalImportIA(false)}
            onSuccess={() => {
              queryClient.invalidateQueries(['produtos-inventario']);
              setModalImportIA(false);
            }}
          />
        )}
      </div>
    </div>
  );
}