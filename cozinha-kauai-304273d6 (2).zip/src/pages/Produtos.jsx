import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Plus, Search, Upload, Warehouse, ChefHat, Download, Sprout, ClipboardList } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

import TabelaProdutos from "../components/produtos/TabelaProdutos";
import ModalProduto from "../components/produtos/ModalProduto";
import ModalImportCSV from "../components/produtos/ModalImportCSV";
import ModalImportarProdutos from "../components/produtos/ModalImportarProdutos";
import ModalGerenciarCategorias from "../components/produtos/ModalGerenciarCategorias";
import ModalEntrada from "../components/produtos/ModalEntrada";
import ModalImportarNota from "../components/produtos/ModalImportarNota";
import HistoricoEntradas from "../components/produtos/HistoricoEntradas";
import { FileUp, Sparkles, Settings2, PackagePlus, Camera, History } from "lucide-react";
import { useOrganization } from "@/components/auth/OrganizationProvider";

export default function Produtos() {
  const { organizacao } = useOrganization();
  const [busca, setBusca] = useState("");
  const [modalAberto, setModalAberto] = useState(false);
  const [modalImport, setModalImport] = useState(false);
  const [modalImportIA, setModalImportIA] = useState(false);
  const [modalCategorias, setModalCategorias] = useState(false);
  const [modalEntrada, setModalEntrada] = useState(false);
  const [modalNota, setModalNota] = useState(false);
  const [produtoEdit, setProdutoEdit] = useState(null);

  const queryClient = useQueryClient();

  const { data: produtos = [], isLoading } = useQuery({
    queryKey: ['produtos', organizacao?.id],
    queryFn: async () => {
        if (!organizacao?.id) return [];
        const res = await base44.entities.Produto.filter({ organizacao_id: organizacao.id }, undefined, 1000);
        return Array.isArray(res) ? res : [];
    },
    enabled: !!organizacao?.id,
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.Produto.create({ ...data, organizacao_id: organizacao.id }),
    onSuccess: () => {
      queryClient.invalidateQueries(['produtos']);
      setModalAberto(false);
      setProdutoEdit(null);
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Produto.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries(['produtos']);
      setModalAberto(false);
      setProdutoEdit(null);
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Produto.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries(['produtos']);
    },
  });

  const bulkDeleteMutation = useMutation({
    mutationFn: async (ids) => {
      await Promise.all(ids.map(id => base44.entities.Produto.delete(id)));
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['produtos']);
    },
  });

  const handleSave = (data) => {
    const codigo = data.codigo || (data.nome || 'produto')
      .toLowerCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-+|-+$/g, '')
      .toUpperCase();

    const payload = { ...data, codigo };

    if (produtoEdit) {
      updateMutation.mutate({ id: produtoEdit.id, data: payload });
    } else {
      createMutation.mutate(payload);
    }
  };

  const handleEdit = (produto) => {
    setProdutoEdit(produto);
    setModalAberto(true);
  };

  const handleDelete = (id) => {
    if (confirm('Tem certeza que deseja excluir este produto?')) {
      deleteMutation.mutate(id);
    }
  };

  const handleBulkDelete = (ids) => {
    if (confirm(`Tem certeza que deseja excluir ${ids.length} produtos?`)) {
      bulkDeleteMutation.mutate(ids);
    }
  };

  const handleExport = (tipo) => {
    const safeProdutos = Array.isArray(produtos) ? produtos : [];
    if (!safeProdutos || safeProdutos.length === 0) {
      alert("Sem dados para exportar.");
      return;
    }

    let filename = 'estoque.csv';
    let dadosExport = safeProdutos;

    if (tipo === 'primario') {
      filename = 'estoque_primario.csv';
    } else if (tipo === 'secundario') {
      filename = 'estoque_secundario.csv';
    } else if (tipo === 'hortifruti') {
      filename = 'estoque_hortifruti.csv';
      dadosExport = safeProdutos.filter(p => ['Vegetais', 'Frutas', 'Hortaliças', 'Hortifruti'].includes(p.categoria));
    }

    if (dadosExport.length === 0) {
      alert("Sem dados nesta categoria para exportar.");
      return;
    }
    
    // Define headers and map data
    const headers = [
      "Nome",
      "Código",
      "Categoria",
      "Unidade",
      (tipo === 'primario') ? "Estoque Almoxarifado" : "Estoque Cozinha",
      "Custo Unitário",
      "Valor Total"
    ];

    const rows = dadosExport.map(p => {
      const estoque = (tipo === 'primario') ? (p.estoque_primario || 0) : (p.estoque_atual || 0);
      const custo = p.custo_unitario || 0;
      const total = estoque * custo;
      
      return [
        `"${(p.nome || "").replace(/"/g, '""')}"`,
        `"${(p.codigo || "").replace(/"/g, '""')}"`,
        `"${(p.categoria || "").replace(/"/g, '""')}"`,
        `"${(p.unidade || "")}"`,
        estoque.toString().replace('.', ','),
        custo.toFixed(2).replace('.', ','),
        total.toFixed(2).replace('.', ',')
      ].join(";");
    });

    const csvContent = "\uFEFF" + [headers.join(";"), ...rows].join("\n");
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement("a");
    const url = URL.createObjectURL(blob);
    
    link.setAttribute("href", url);
    link.setAttribute("download", filename);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const safeProdutos = Array.isArray(produtos) ? produtos : [];
  const produtosFiltrados = safeProdutos.filter(p =>
    (p.nome || '').toLowerCase().includes(busca.toLowerCase()) ||
    (p.codigo || '').toLowerCase().includes(busca.toLowerCase()) ||
    (p.categoria || '').toLowerCase().includes(busca.toLowerCase())
  );

  return (
    <div className="p-4 md:p-8 min-h-screen">
      <div className="max-w-7xl mx-auto space-y-6">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Produtos & Estoque</h1>
            <p className="text-gray-600 mt-1">Gerencie todos os insumos da cozinha</p>
          </div>
          <div className="flex gap-3">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" className="gap-2 border-blue-300 hover:bg-blue-50 text-blue-700">
                  <Download className="w-4 h-4" />
                  Exportar
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent>
                <DropdownMenuItem onClick={() => handleExport('primario')}>
                  <Warehouse className="w-4 h-4 mr-2" />
                  Exportar Almoxarifado (Primário)
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => handleExport('secundario')}>
                  <ChefHat className="w-4 h-4 mr-2" />
                  Exportar Cozinha (Secundário)
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => handleExport('hortifruti')}>
                  <Sprout className="w-4 h-4 mr-2" />
                  Exportar Hortifruti
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>

            <Button
              onClick={() => setModalEntrada(true)}
              className="gap-2 bg-green-600 hover:bg-green-700 text-white border-green-600"
            >
              <PackagePlus className="w-4 h-4" />
              Entrada Manual
            </Button>

            <Button
              onClick={() => setModalNota(true)}
              className="gap-2 bg-indigo-600 hover:bg-indigo-700 text-white border-indigo-600"
            >
              <Camera className="w-4 h-4" />
              Entrada via Nota (IA)
            </Button>

            <Button
              variant="outline"
              onClick={() => setModalCategorias(true)}
              className="gap-2 border-gray-300 hover:bg-gray-50 text-gray-700"
              title="Gerenciar Categorias"
            >
              <Settings2 className="w-4 h-4" />
              Categorias
            </Button>
            <Button
              variant="outline"
              onClick={() => setModalImport(true)}
              className="gap-2 border-orange-300 hover:bg-orange-50"
            >
              <FileUp className="w-4 h-4" />
              Importar CSV
            </Button>
            <Button
              variant="outline"
              onClick={() => setModalImportIA(true)}
              className="gap-2 bg-orange-100 text-orange-800 hover:bg-orange-200 border-orange-300"
            >
              <Sparkles className="w-4 h-4" />
              Importar (IA)
            </Button>
            <Button
              onClick={() => {
                setProdutoEdit(null);
                setModalAberto(true);
              }}
              className="gap-2 bg-gradient-to-r from-orange-500 to-amber-600 hover:from-orange-600 hover:to-amber-700"
            >
              <Plus className="w-4 h-4" />
              Novo Produto
            </Button>
          </div>
        </div>

        <div className="bg-white rounded-xl border border-orange-200/50 shadow-lg p-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
            <Input
              placeholder="Buscar por nome, código ou categoria..."
              value={busca}
              onChange={(e) => setBusca(e.target.value)}
              className="pl-10 border-orange-200 focus:border-orange-400"
            />
          </div>
        </div>

        <Tabs defaultValue="todos" className="w-full">
          <TabsList className="grid w-full grid-cols-2 md:grid-cols-4 lg:w-[600px]">
            <TabsTrigger value="todos">Visão Geral</TabsTrigger>
            <TabsTrigger value="primario" className="gap-2">
              <Warehouse className="w-4 h-4" />
              Estoque Primário
            </TabsTrigger>
            <TabsTrigger value="secundario" className="gap-2">
              <ChefHat className="w-4 h-4" />
              Estoque Secundário
            </TabsTrigger>
            <TabsTrigger value="hortifruti" className="gap-2 text-green-600 data-[state=active]:text-green-700">
              <Sprout className="w-4 h-4" />
              Hortifruti
            </TabsTrigger>
            <TabsTrigger value="entradas" className="gap-2 text-blue-600 data-[state=active]:text-blue-700">
              <History className="w-4 h-4" />
              Últimas Entradas
            </TabsTrigger>
            </TabsList>

          <TabsContent value="todos" className="mt-4">
            <TabelaProdutos
              produtos={produtosFiltrados.filter(p => p.categoria !== 'Insumos bar')}
              loading={isLoading}
              onEdit={handleEdit}
              onDelete={handleDelete}
              onBulkDelete={handleBulkDelete}
              mode="todos"
            />
          </TabsContent>
          
          <TabsContent value="primario" className="mt-4">
            <div className="mb-4 p-4 bg-blue-50 border border-blue-100 rounded-lg text-blue-800 text-sm">
              Aqui você visualiza o estoque de <strong>Almoxarifado/Central</strong>. Utilize esta aba para lançar entradas de compras.
            </div>
            <TabelaProdutos
              produtos={produtosFiltrados}
              loading={isLoading}
              onEdit={handleEdit}
              onDelete={handleDelete}
              onBulkDelete={handleBulkDelete}
              mode="primario"
            />
          </TabsContent>

          <TabsContent value="secundario" className="mt-4">
            <div className="mb-4 p-4 bg-orange-50 border border-orange-100 rounded-lg text-orange-800 text-sm">
              Aqui você visualiza o estoque da <strong>Cozinha/Produção</strong>. Este é o estoque consumido nas receitas.
            </div>
            <TabelaProdutos
              produtos={produtosFiltrados}
              loading={isLoading}
              onEdit={handleEdit}
              onDelete={handleDelete}
              onBulkDelete={handleBulkDelete}
              mode="secundario"
            />
          </TabsContent>

          <TabsContent value="hortifruti" className="mt-4">
            <div className="mb-4 p-4 bg-green-50 border border-green-100 rounded-lg text-green-800 text-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
              <div className="flex items-center gap-2">
                <Sprout className="w-5 h-5" />
                <span><strong>Hortifruti & Vegetais:</strong> Gestão exclusiva de frutas, legumes e verduras.</span>
              </div>
              <Button 
                onClick={() => window.location.href = '/Inventario?tab=hortifruti'}
                className="bg-green-600 hover:bg-green-700 text-white shadow-sm whitespace-nowrap"
                size="sm"
              >
                <ClipboardList className="w-4 h-4 mr-2" />
                Realizar Inventário (Contagem)
              </Button>
            </div>
            <TabelaProdutos
              produtos={produtosFiltrados.filter(p => ['Vegetais', 'Frutas', 'Hortaliças', 'Hortifruti'].includes(p.categoria))}
              loading={isLoading}
              onEdit={handleEdit}
              onDelete={handleDelete}
              onBulkDelete={handleBulkDelete}
              mode="todos"
            />
          </TabsContent>

          <TabsContent value="entradas" className="mt-4">
            <div className="mb-4 p-4 bg-blue-50 border border-blue-100 rounded-lg text-blue-800 text-sm">
              Histórico das últimas <strong>100 entradas de estoque</strong> (Compras, Importação de Notas, etc).
            </div>
            <HistoricoEntradas />
          </TabsContent>
          </Tabs>

        {modalAberto && (
          <ModalProduto
            produto={produtoEdit}
            onClose={() => {
              setModalAberto(false);
              setProdutoEdit(null);
            }}
            onSave={handleSave}
            saving={createMutation.isPending || updateMutation.isPending}
          />
        )}

        {modalImport && (
          <ModalImportCSV
            onClose={() => setModalImport(false)}
            onSuccess={() => {
              queryClient.invalidateQueries(['produtos']);
              setModalImport(false);
            }}
          />
        )}
        {modalImportIA && (
          <ModalImportarProdutos
            onClose={() => setModalImportIA(false)}
            onSuccess={() => {
              queryClient.invalidateQueries(['produtos']);
              setModalImportIA(false);
            }}
          />
        )}
        
        {modalCategorias && (
          <ModalGerenciarCategorias
            onClose={() => setModalCategorias(false)}
          />
        )}

        {modalEntrada && (
          <ModalEntrada
            onClose={() => setModalEntrada(false)}
          />
        )}

        {modalNota && (
          <ModalImportarNota
            onClose={() => setModalNota(false)}
          />
        )}
      </div>
    </div>
  );
}