
import React from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { TooltipProvider } from "@/components/ui/tooltip";
import { 
        LayoutDashboard, 
        Package, 
        ClipboardList, 
        FileText, 
        ShoppingCart,
        ShoppingBag,
        History,
        ChefHat,
        Tag,
        PackageMinus,
        ArrowDownCircle,
        AlertOctagon,
        ThermometerSnowflake,
        Droplets,
        ShieldCheck,
        Shield,
        PieChart,
        BookOpen,
        Utensils,
        Bot,
        Building2,
        Sparkles
        } from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarFooter,
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar";

const menuGroups = [
  {
    label: "Principal",
    items: [
      { title: "Dashboard", url: createPageUrl("Dashboard"), icon: LayoutDashboard },
      { title: "Chefe Virtual", url: createPageUrl("ChefeVirtual"), icon: Bot },
      { title: "Marketing AI", url: createPageUrl("Marketing"), icon: Sparkles },
      { title: "Escritório Central", url: createPageUrl("AdminSaaS"), icon: Building2 },
    ]
  },
  {
    label: "Central de Produção",
    items: [
      { title: "Registrar Produção", url: createPageUrl("Producao"), icon: ClipboardList },
      { title: "Requisição / Transferência", url: createPageUrl("Movimentacoes?tab=transferencia"), icon: PackageMinus },
      { title: "Baixa de Produção", url: createPageUrl("Movimentacoes?tab=retirada"), icon: ArrowDownCircle },
      { title: "Perda de Insumos", url: createPageUrl("Movimentacoes?tab=perda"), icon: AlertOctagon },
      { title: "Refeitório", url: createPageUrl("Movimentacoes?tab=refeitorio"), icon: Utensils },
    ]
  },
  {
    label: "Registros Operacionais",
    items: [
      { title: "Controle de Qualidade", url: createPageUrl("ControleQualidade"), icon: ShieldCheck },
      { title: "Fichas Técnicas", url: createPageUrl("FichasTecnicas"), icon: BookOpen },
      { title: "Inventário", url: createPageUrl("Inventario"), icon: ClipboardList },
      { title: "Etiquetas", url: createPageUrl("Etiquetas"), icon: Tag },
    ]
  },
  {
    label: "Gestão & Estoque",
    items: [
      { title: "Produtos & Estoque", url: createPageUrl("Produtos"), icon: Package },
      { title: "Preparações", url: createPageUrl("Preparacoes"), icon: FileText },
      { title: "Engenharia de Cardápio", url: createPageUrl("EngenhariaCardapio"), icon: PieChart },
      { title: "Compras", url: createPageUrl("Compras"), icon: ShoppingCart },
      { title: "Vendas", url: createPageUrl("Vendas"), icon: ShoppingBag },
      { title: "Histórico Produção", url: createPageUrl("Historico"), icon: History },
      { title: "Painel Manager", url: createPageUrl("Manager"), icon: Shield },
      { title: "Painel Contábil", url: createPageUrl("Contabil"), icon: PieChart },
    ]
  }
  ];

import InstallPWA from "@/components/common/InstallPWA";
import { OrganizationProvider, useOrganization } from "@/components/auth/OrganizationProvider";
import { isSuperAdmin } from "@/components/auth/adminControl";
import { LogOut } from "lucide-react";
import { base44 } from "@/api/base44Client";
import OrgSwitcher from "@/components/layout/OrgSwitcher";

const SidebarNavigation = () => {
  const { user, organizacao } = useOrganization();
  const location = useLocation();

  return (
    <SidebarContent className="p-3 gap-1">
      {menuGroups.map((group) => {
        const visibleItems = group.items.filter((item) => {
          if (item.title === "Escritório Central") {
             const hasUser = user && user.email;
             const hasOrg = organizacao && organizacao.id;
             if (!hasUser || !hasOrg) return false;
             // Permite acesso APENAS na conta principal (CozinhaChefPro) e se for super admin
             return isSuperAdmin(user.email) && organizacao.id === '692e71c90edccbefb225a48e';
          }
          return true;
        });

        if (visibleItems.length === 0) return null;

        return (
          <SidebarGroup key={group.label}>
            <SidebarGroupLabel className="text-xs font-semibold text-gray-500 uppercase tracking-wider px-3 py-2">
              {group.label}
            </SidebarGroupLabel>
            <SidebarGroupContent>
              <SidebarMenu>
                {visibleItems.map((item) => {
                  const currentPath = location.pathname;
                  const itemUrl = item.url;
                  
                  const isActive = currentPath === itemUrl || 
                                 (itemUrl.includes("?") && currentPath + location.search === itemUrl);

                  const Icon = item.icon;

                  return (
                    <SidebarMenuItem key={item.title}>
                      <SidebarMenuButton
                        asChild
                        className={`w-full justify-start gap-3 px-3 py-2 rounded-lg mb-1 transition-all duration-200 group ${
                          isActive
                            ? "bg-gradient-to-r from-orange-500 to-amber-600 text-white shadow-md hover:from-orange-600 hover:to-amber-700 hover:text-white"
                            : "hover:bg-orange-50 hover:text-orange-700 text-gray-700"
                        }`}
                      >
                        <Link to={itemUrl}>
                          <Icon className={`w-4 h-4 flex-shrink-0 ${isActive ? "text-white" : "text-gray-500 group-hover:text-orange-600"}`} />
                          <span className="font-medium text-sm truncate">{item.title}</span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  );
                })}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        );
      })}
    </SidebarContent>
  );
};

const OrgNameDisplay = () => {
  const { organizacao } = useOrganization();
  return organizacao?.nome ? ` - ${organizacao.nome}` : '';
};

function MainLayout({ children }) {
  const location = useLocation();
  const { user } = useOrganization();

  React.useEffect(() => {
    document.title = "CozinhaChefPro";

    // PWA Meta Tags injection
    const metaTags = [
      { name: 'theme-color', content: '#f97316' },
      { name: 'apple-mobile-web-app-capable', content: 'yes' },
      { name: 'apple-mobile-web-app-status-bar-style', content: 'default' },
      { name: 'apple-mobile-web-app-title', content: 'ChefPro' },
    ];

    metaTags.forEach(tag => {
      if (!document.querySelector(`meta[name="${tag.name}"]`)) {
        const meta = document.createElement('meta');
        meta.name = tag.name;
        meta.content = tag.content;
        document.head.appendChild(meta);
      }
    });
  }, []);

  // Verifica se é a página de setup ou landing page
  const path = location.pathname.toLowerCase();
  
  const isSetupPage = path.startsWith('/setup');
  const isPublicLink = path.startsWith('/links') || path.startsWith('/exportarlanding');
  const isLanding = path === '/landingpage' || path.startsWith('/landing');
  const isRoot = path === '/' || path === '';
  const isDashboard = path.includes('dashboard');

  // Lógica de Exibição do Menu
  // Mostra sidebar se:
  // 1. É página de Dashboard
  // 2. OU é Root ('/') e o usuário está logado (caso de redirecionamento pendente ou state mismatch)
  // 3. E NÃO é página explicitamente pública (setup, links, landing)
  
  // Se for setup, links ou landing -> SEM SIDEBAR
  if (isSetupPage || isPublicLink || isLanding) {
    return (
      <div className="min-h-screen w-full bg-gradient-to-br from-orange-50 via-amber-50 to-yellow-50">
         {children}
      </div>
    );
  }

  // Se for Root e NÃO estiver logado -> SEM SIDEBAR (Landing Page)
  if (isRoot && !user) {
    return (
      <div className="min-h-screen w-full bg-gradient-to-br from-orange-50 via-amber-50 to-yellow-50">
         {children}
      </div>
    );
  }

  // Caso contrário (Dashboard, outras páginas internas, ou Root logado) -> COM SIDEBAR
  return (
    <TooltipProvider>
      <SidebarProvider defaultOpen={true}>
        <div className="min-h-screen flex w-full bg-gradient-to-br from-orange-50 via-amber-50 to-yellow-50">
          <Sidebar className="border-r border-orange-200/50 bg-white/80 backdrop-blur-sm" collapsible="icon">
            <SidebarHeader className="border-b border-orange-200/50 p-4">
              <OrgSwitcher />
            </SidebarHeader>

            <SidebarNavigation />

            <SidebarFooter className="border-t border-orange-200/50 p-4 space-y-3">
              <Link 
                to="/LandingPage" 
                className="flex items-center gap-3 w-full px-3 py-2 text-sm font-medium text-orange-600 hover:bg-orange-50 rounded-lg transition-colors"
              >
                <LayoutDashboard className="w-4 h-4" />
                Ver Landing Page
              </Link>
              <button 
                onClick={() => base44.auth.logout()} 
                className="flex items-center gap-3 w-full px-3 py-2 text-sm font-medium text-red-600 hover:bg-red-50 rounded-lg transition-colors"
              >
                <LogOut className="w-4 h-4" />
                Sair do Sistema
              </button>
              <InstallPWA />
              <div className="bg-gradient-to-r from-orange-50 to-amber-50 rounded-lg p-3">
                <p className="text-xs text-gray-600 font-medium">Sistema v1.2</p>
                <p className="text-xs text-gray-500 mt-0.5">Gestão Profissional</p>
              </div>
            </SidebarFooter>
          </Sidebar>

          <main className="flex-1 flex flex-col min-h-screen">
            <header className="bg-white/80 backdrop-blur-sm border-b border-orange-200/50 px-6 py-4 flex items-center gap-4 lg:hidden">
              <SidebarTrigger className="hover:bg-orange-50 p-2 rounded-lg transition-colors" />
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 bg-gray-900 rounded-md flex items-center justify-center shadow-sm">
                    <ChefHat className="w-4 h-4 text-white" />
                  </div>
                  <h1 className="text-lg font-bold text-gray-900 tracking-tight">
                      Cozinha<span className="text-orange-600">ChefPro</span>
                      <span className="text-xs font-normal text-gray-500 ml-2"><OrgNameDisplay /></span>
                  </h1>
                  </div>
                  <div className="ml-auto">
                      <InstallPWA />
                  </div>
                  </header>

            <div className="flex-1 overflow-auto relative">
              <div className="hidden lg:block absolute top-4 left-4 z-50 flex items-center gap-2">
                <SidebarTrigger className="bg-white/50 hover:bg-white shadow-sm p-2 rounded-lg transition-all backdrop-blur-sm border border-orange-100" />
              </div>
              {children}
            </div>
          </main>
        </div>
      </SidebarProvider>
    </TooltipProvider>
  );
}

export default function Layout({ children }) {
  return (
    <OrganizationProvider>
      <MainLayout>{children}</MainLayout>
    </OrganizationProvider>
  );
}
