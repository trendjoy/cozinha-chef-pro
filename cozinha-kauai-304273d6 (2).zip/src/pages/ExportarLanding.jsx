import React from 'react';
import { Button } from "@/components/ui/button";
import { Copy, Download, CheckCircle2 } from "lucide-react";
import { toast } from "sonner";

// HTML Completo da Landing Page convertido para Estático
const landingHtml = `<!DOCTYPE html>
<html lang="pt-BR" class="scroll-smooth">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CozinhaChefPro - Sistema para Cozinhas Profissionais</title>
    <meta name="description" content="Sistema de gestão para cozinhas profissionais. Controle de estoque, fichas técnicas, etiquetas e muito mais.">
    
    <!-- Favicon -->
    <link rel="icon" type="image/svg+xml" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'><path d='M6 13.87A4 4 0 0 1 7.41 6a5.11 5.11 0 0 1 1.05-1.54 5 5 0 0 1 7.08 0A5.11 5.11 0 0 1 16.59 6 4 4 0 0 1 18 13.87V21H6Z'/><line x1='6' y1='17' x2='18' y2='17'/></svg>">

    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    
    <!-- Lucide Icons -->
    <script src="https://unpkg.com/lucide@latest"></script>

    <!-- AOS Animation Library -->
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>

    <style>
        body { font-family: 'Inter', sans-serif; }
        .glass-card {
            background: rgba(255, 255, 255, 0.9);
            backdrop-filter: blur(10px);
        }
    </style>
</head>
<body class="bg-white text-gray-900 overflow-x-hidden">

    <!-- Navigation -->
    <nav class="fixed w-full bg-white/90 backdrop-blur-md z-50 border-b border-orange-100/50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
            <a href="#" class="flex items-center gap-2 group">
                <div class="w-10 h-10 bg-gray-900 rounded-lg flex items-center justify-center shadow-lg group-hover:bg-orange-600 transition-colors">
                    <i data-lucide="chef-hat" class="text-white w-6 h-6"></i>
                </div>
                <span class="font-bold text-xl tracking-tight text-gray-900">
                    Cozinha<span class="text-orange-600">ChefPro</span>
                </span>
            </a>
            <div class="hidden md:flex items-center gap-8">
                <a href="#beneficios" class="text-gray-600 hover:text-orange-600 font-medium transition-colors">Benefícios</a>
                <a href="#analise" class="text-gray-600 hover:text-orange-600 font-medium transition-colors">Análise</a>
                <a href="#planos" class="text-gray-600 hover:text-orange-600 font-medium transition-colors">Planos</a>
            </div>
            <div class="flex items-center gap-4">
                <a href="https://app.cozinhachefpro.com.br/Dashboard" class="hidden md:inline-flex items-center justify-center px-4 py-2 text-sm font-semibold text-gray-700 hover:text-orange-600 hover:bg-orange-50 rounded-md transition-colors">
                    Entrar
                </a>
                <a href="https://app.cozinhachefpro.com.br/SetupOrganizacao" class="inline-flex items-center justify-center px-6 py-2.5 text-sm font-bold text-white bg-orange-600 hover:bg-orange-700 rounded-lg shadow-lg shadow-orange-200/50 hover:shadow-orange-300/50 transition-all hover:-translate-y-0.5">
                    Testar Agora
                </a>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section class="pt-32 pb-20 lg:pt-40 lg:pb-32 bg-gradient-to-br from-orange-50 via-white to-amber-50 relative overflow-hidden">
        <!-- Background Elements -->
        <div class="absolute top-0 right-0 w-1/3 h-full bg-orange-100/30 -skew-x-12 translate-x-32 pointer-events-none"></div>
        <div class="absolute bottom-0 left-0 w-64 h-64 bg-amber-200/20 rounded-full blur-3xl pointer-events-none"></div>

        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
            <div class="flex flex-col lg:flex-row items-center gap-12 lg:gap-20">
                
                <!-- Text Content -->
                <div class="flex-1 text-center lg:text-left" data-aos="fade-up">
                    <div class="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white border border-orange-200 text-orange-700 font-bold text-xs uppercase tracking-wide mb-6 shadow-sm">
                        <i data-lucide="sparkles" class="w-3.5 h-3.5"></i>
                        Sistema feito por Chef para Chefs
                    </div>
                    <h1 class="text-4xl lg:text-6xl font-extrabold tracking-tight text-gray-900 mb-6 leading-[1.15]">
                        Controle total da sua cozinha <br class="hidden lg:block"/>
                        <span class="text-transparent bg-clip-text bg-gradient-to-r from-orange-600 to-amber-600">
                            sem planilhas e sem perdas.
                        </span>
                    </h1>
                    <p class="text-lg lg:text-xl text-gray-600 mb-8 leading-relaxed max-w-2xl mx-auto lg:mx-0">
                        Estoque, validade, CMV, temperaturas, etiquetas e limpeza em um único sistema. Domine sua operação hoje.
                    </p>
                    
                    <div class="flex flex-col sm:flex-row items-center gap-4 justify-center lg:justify-start">
                        <a href="https://app.cozinhachefpro.com.br/SetupOrganizacao" class="w-full sm:w-auto inline-flex items-center justify-center h-14 px-8 text-lg font-bold text-white bg-gray-900 hover:bg-gray-800 rounded-lg shadow-xl hover:shadow-2xl transition-all">
                            Testar Agora <i data-lucide="arrow-right" class="ml-2 w-5 h-5"></i>
                        </a>
                        <a href="https://wa.me/5511999999999" target="_blank" class="w-full sm:w-auto inline-flex items-center justify-center h-14 px-8 text-lg font-semibold text-green-600 bg-white border-2 border-green-500 hover:bg-green-50 rounded-lg transition-colors">
                            <i data-lucide="message-circle" class="mr-2 w-5 h-5"></i> Falar no WhatsApp
                        </a>
                    </div>
                </div>

                <!-- Hero Image -->
                <div class="flex-1 relative w-full max-w-lg lg:max-w-none" data-aos="fade-left" data-aos-delay="200">
                    <div class="relative">
                        <div class="absolute -inset-2 bg-gradient-to-tr from-orange-500 to-amber-500 rounded-[2rem] blur-lg opacity-30"></div>
                        <img 
                            src="https://images.unsplash.com/photo-1577219491135-ce391730fb2c?q=80&w=2577&auto=format&fit=crop" 
                            alt="Chef profissional" 
                            class="relative rounded-[2rem] shadow-2xl border-4 border-white w-full object-cover aspect-[4/3]"
                        >
                        
                        <!-- Floating Cards -->
                        <div class="absolute -bottom-6 -left-6 bg-white p-4 rounded-xl shadow-xl border border-gray-100 hidden md:flex items-center gap-4 animate-bounce" style="animation-duration: 3s;">
                            <div class="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                                <i data-lucide="dollar-sign" class="w-6 h-6 text-green-600"></i>
                            </div>
                            <div>
                                <p class="text-xs text-gray-500 font-semibold uppercase">Lucro Mensal</p>
                                <p class="text-xl font-bold text-gray-900">+28%</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Social Proof -->
    <section class="py-12 bg-gray-900 text-white border-b border-gray-800">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
                <div class="flex flex-col items-center gap-3 group">
                    <i data-lucide="chef-hat" class="w-8 h-8 text-orange-500 group-hover:text-orange-400 transition-colors"></i>
                    <span class="text-sm font-medium text-gray-300">Criado por Chef Executivo</span>
                </div>
                <div class="flex flex-col items-center gap-3 group">
                    <i data-lucide="check-circle-2" class="w-8 h-8 text-orange-500 group-hover:text-orange-400 transition-colors"></i>
                    <span class="text-sm font-medium text-gray-300">Usado por Cozinhas Profissionais</span>
                </div>
                <div class="flex flex-col items-center gap-3 group">
                    <i data-lucide="shield-check" class="w-8 h-8 text-orange-500 group-hover:text-orange-400 transition-colors"></i>
                    <span class="text-sm font-medium text-gray-300">Validado em Alto Volume</span>
                </div>
                <div class="flex flex-col items-center gap-3 group">
                    <i data-lucide="star" class="w-8 h-8 text-orange-500 group-hover:text-orange-400 transition-colors"></i>
                    <span class="text-sm font-medium text-gray-300">Desenvolvido na Prática</span>
                </div>
            </div>
        </div>
    </section>

    <!-- Benefits -->
    <section id="beneficios" class="py-24 bg-white">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="text-center mb-16" data-aos="fade-up">
                <h2 class="text-3xl font-bold text-gray-900 mb-4">Resultados reais para sua cozinha</h2>
                <p class="text-lg text-gray-600 max-w-2xl mx-auto">
                    Não vendemos apenas software. Entregamos paz de espírito para quem vive na pressão.
                </p>
            </div>

            <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                <!-- Card 1 -->
                <div class="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 hover:shadow-xl hover:-translate-y-1 transition-all flex gap-4 group" data-aos="fade-up" data-aos-delay="0">
                    <div class="w-12 h-12 bg-orange-100 rounded-xl flex items-center justify-center flex-shrink-0 group-hover:bg-orange-600 transition-colors">
                        <i data-lucide="trash-2" class="w-6 h-6 text-orange-600 group-hover:text-white transition-colors"></i>
                    </div>
                    <div>
                        <h3 class="font-bold text-gray-900 text-lg mb-2">Evite perdas por vencimento</h3>
                        <p class="text-gray-600 text-sm leading-relaxed">Alertas automáticos antes dos produtos vencerem. Pare de jogar dinheiro no lixo.</p>
                    </div>
                </div>
                <!-- Card 2 -->
                <div class="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 hover:shadow-xl hover:-translate-y-1 transition-all flex gap-4 group" data-aos="fade-up" data-aos-delay="100">
                    <div class="w-12 h-12 bg-orange-100 rounded-xl flex items-center justify-center flex-shrink-0 group-hover:bg-orange-600 transition-colors">
                        <i data-lucide="trending-up" class="w-6 h-6 text-orange-600 group-hover:text-white transition-colors"></i>
                    </div>
                    <div>
                        <h3 class="font-bold text-gray-900 text-lg mb-2">Tenha controle real do CMV</h3>
                        <p class="text-gray-600 text-sm leading-relaxed">Saiba exatamente quanto custa cada prato e onde está sua margem de lucro.</p>
                    </div>
                </div>
                <!-- Card 3 -->
                <div class="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 hover:shadow-xl hover:-translate-y-1 transition-all flex gap-4 group" data-aos="fade-up" data-aos-delay="200">
                    <div class="w-12 h-12 bg-orange-100 rounded-xl flex items-center justify-center flex-shrink-0 group-hover:bg-orange-600 transition-colors">
                        <i data-lucide="clipboard-list" class="w-6 h-6 text-orange-600 group-hover:text-white transition-colors"></i>
                    </div>
                    <div>
                        <h3 class="font-bold text-gray-900 text-lg mb-2">Padronize sua cozinha</h3>
                        <p class="text-gray-600 text-sm leading-relaxed">Fichas técnicas acessíveis para toda a equipe. O mesmo sabor, sempre.</p>
                    </div>
                </div>
                <!-- Card 4 -->
                <div class="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 hover:shadow-xl hover:-translate-y-1 transition-all flex gap-4 group" data-aos="fade-up" data-aos-delay="300">
                    <div class="w-12 h-12 bg-orange-100 rounded-xl flex items-center justify-center flex-shrink-0 group-hover:bg-orange-600 transition-colors">
                        <i data-lucide="shield-check" class="w-6 h-6 text-orange-600 group-hover:text-white transition-colors"></i>
                    </div>
                    <div>
                        <h3 class="font-bold text-gray-900 text-lg mb-2">Evite multas da vigilância</h3>
                        <p class="text-gray-600 text-sm leading-relaxed">Controle de temperatura, limpeza e etiquetas em dia. Durma tranquilo.</p>
                    </div>
                </div>
                 <!-- Card 5 -->
                 <div class="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 hover:shadow-xl hover:-translate-y-1 transition-all flex gap-4 group" data-aos="fade-up" data-aos-delay="400">
                    <div class="w-12 h-12 bg-orange-100 rounded-xl flex items-center justify-center flex-shrink-0 group-hover:bg-orange-600 transition-colors">
                        <i data-lucide="smartphone" class="w-6 h-6 text-orange-600 group-hover:text-white transition-colors"></i>
                    </div>
                    <div>
                        <h3 class="font-bold text-gray-900 text-lg mb-2">Tenha dados em tempo real</h3>
                        <p class="text-gray-600 text-sm leading-relaxed">Acesse do celular, tablet ou computador. Sua cozinha na palma da mão.</p>
                    </div>
                </div>
                 <!-- Card 6 -->
                 <div class="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 hover:shadow-xl hover:-translate-y-1 transition-all flex gap-4 group" data-aos="fade-up" data-aos-delay="500">
                    <div class="w-12 h-12 bg-orange-100 rounded-xl flex items-center justify-center flex-shrink-0 group-hover:bg-orange-600 transition-colors">
                        <i data-lucide="check-circle-2" class="w-6 h-6 text-orange-600 group-hover:text-white transition-colors"></i>
                    </div>
                    <div>
                        <h3 class="font-bold text-gray-900 text-lg mb-2">Fim do papel e planilhas</h3>
                        <p class="text-gray-600 text-sm leading-relaxed">Centralize tudo em um lugar só. Mais organização, menos dor de cabeça.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Pricing Section -->
    <section id="planos" class="py-24 bg-gray-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="max-w-lg mx-auto" data-aos="zoom-in">
                <div class="bg-gray-900 rounded-[2rem] p-8 md:p-12 shadow-2xl border border-gray-800 text-center relative overflow-hidden hover:shadow-orange-900/20 transition-shadow duration-500">
                    <div class="absolute top-0 right-0 bg-gradient-to-bl from-orange-500 to-red-600 text-white text-xs font-bold px-4 py-2 rounded-bl-xl uppercase tracking-wider shadow-lg">
                        Oferta Especial
                    </div>
                    
                    <h2 class="text-2xl font-bold text-white mb-2">Plano Único CozinhaChefPro</h2>
                    <p class="text-gray-400 mb-8">Tudo o que você precisa, sem pegadinhas.</p>
                    
                    <div class="flex items-center justify-center text-white mb-2">
                        <span class="text-2xl text-gray-500 mr-2 font-light line-through">R$ 199</span>
                        <span class="text-6xl font-extrabold tracking-tighter">R$ 99</span>
                        <span class="text-xl text-gray-400 self-end mb-2 ml-1">/mês</span>
                    </div>
                    
                    <div class="h-px w-full bg-gray-800 my-8"></div>

                    <ul class="text-left space-y-4 mb-10 text-gray-300">
                        <li class="flex items-center gap-3">
                            <div class="w-5 h-5 rounded-full bg-green-900/50 flex items-center justify-center flex-shrink-0">
                                <i data-lucide="check" class="w-3.5 h-3.5 text-green-500"></i>
                            </div>
                            Acesso completo ao sistema
                        </li>
                        <li class="flex items-center gap-3">
                            <div class="w-5 h-5 rounded-full bg-green-900/50 flex items-center justify-center flex-shrink-0">
                                <i data-lucide="check" class="w-3.5 h-3.5 text-green-500"></i>
                            </div>
                            Todos os módulos liberados
                        </li>
                        <li class="flex items-center gap-3">
                            <div class="w-5 h-5 rounded-full bg-green-900/50 flex items-center justify-center flex-shrink-0">
                                <i data-lucide="check" class="w-3.5 h-3.5 text-green-500"></i>
                            </div>
                            Suporte direto via WhatsApp
                        </li>
                        <li class="flex items-center gap-3">
                            <div class="w-5 h-5 rounded-full bg-green-900/50 flex items-center justify-center flex-shrink-0">
                                <i data-lucide="check" class="w-3.5 h-3.5 text-green-500"></i>
                            </div>
                            Sem contrato de fidelidade
                        </li>
                    </ul>

                    <a href="https://app.cozinhachefpro.com.br/SetupOrganizacao" class="w-full inline-flex items-center justify-center bg-orange-600 hover:bg-orange-700 text-white h-14 text-lg font-bold shadow-lg hover:scale-105 transition-transform rounded-xl">
                        Quero começar agora
                    </a>
                    <p class="text-xs text-gray-500 mt-4">
                        Teste grátis por 7 dias. Cancele quando quiser.
                    </p>
                </div>
            </div>
        </div>
    </section>

    <!-- FAQ Section -->
    <section class="py-24 bg-white">
        <div class="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="text-center mb-12" data-aos="fade-up">
                <h2 class="text-3xl font-bold text-gray-900">Perguntas Frequentes</h2>
            </div>
            
            <div class="bg-white rounded-2xl shadow-sm border border-gray-200 divide-y divide-gray-200" data-aos="fade-up">
                <!-- FAQ Item 1 -->
                <details class="group p-6 cursor-pointer">
                    <summary class="flex justify-between items-center font-semibold text-gray-900 list-none">
                        Funciona no celular?
                        <span class="transition group-open:rotate-180">
                            <i data-lucide="chevron-down" class="w-5 h-5 text-gray-500"></i>
                        </span>
                    </summary>
                    <p class="text-gray-600 mt-4 leading-relaxed">
                        Sim! O sistema é 100% otimizado para celulares e tablets, além do computador. Você pode acessar de qualquer lugar.
                    </p>
                </details>

                <!-- FAQ Item 2 -->
                <details class="group p-6 cursor-pointer">
                    <summary class="flex justify-between items-center font-semibold text-gray-900 list-none">
                        Posso cancelar quando quiser?
                        <span class="transition group-open:rotate-180">
                            <i data-lucide="chevron-down" class="w-5 h-5 text-gray-500"></i>
                        </span>
                    </summary>
                    <p class="text-gray-600 mt-4 leading-relaxed">
                        Com certeza. Não temos contrato de fidelidade. Você usa enquanto fizer sentido para o seu negócio.
                    </p>
                </details>

                <!-- FAQ Item 3 -->
                <details class="group p-6 cursor-pointer">
                    <summary class="flex justify-between items-center font-semibold text-gray-900 list-none">
                        Serve para restaurante pequeno?
                        <span class="transition group-open:rotate-180">
                            <i data-lucide="chevron-down" class="w-5 h-5 text-gray-500"></i>
                        </span>
                    </summary>
                    <p class="text-gray-600 mt-4 leading-relaxed">
                        Perfeitamente. O sistema foi desenhado para ser simples e eficiente, ideal tanto para quem está começando quanto para grandes operações.
                    </p>
                </details>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="bg-gray-950 text-gray-400 py-12 border-t border-gray-900">
        <div class="max-w-7xl mx-auto px-4 text-center">
            <div class="flex items-center justify-center gap-2 text-white mb-8">
                <i data-lucide="chef-hat" class="w-6 h-6"></i>
                <span class="font-bold text-xl">CozinhaChefPro</span>
            </div>
            <div class="flex justify-center gap-6 mb-8 text-sm">
                <a href="#" class="hover:text-white transition-colors">Termos de Uso</a>
                <a href="#" class="hover:text-white transition-colors">Privacidade</a>
                <a href="#" class="hover:text-white transition-colors">Suporte</a>
            </div>
            <p class="text-sm text-gray-600">
                © 2024 CozinhaChefPro. Feito com 🔥 e código.
            </p>
        </div>
    </footer>

    <script>
        // Inicializa ícones
        lucide.createIcons();
        // Inicializa animações
        AOS.init({
            duration: 800,
            once: true,
            offset: 100
        });
    </script>
</body>
</html>`;

export default function ExportarLanding() {
  const copyToClipboard = () => {
    navigator.clipboard.writeText(landingHtml);
    toast.success("Código HTML copiado com sucesso!");
  };

  const downloadHtml = () => {
    const element = document.createElement("a");
    const file = new Blob([landingHtml], {type: 'text/html'});
    element.href = URL.createObjectURL(file);
    element.download = "index.html";
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
    toast.success("Arquivo index.html baixado!");
  };

  return (
    <div className="min-h-screen bg-gray-50 p-8">
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="flex flex-col md:flex-row justify-between items-center gap-4 bg-white p-6 rounded-xl shadow-sm border border-gray-200">
          <div>
            <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
                <CheckCircle2 className="text-green-500" /> Exportar Landing Page
            </h1>
            <p className="text-gray-600 mt-1">Baixe o arquivo <strong>index.html</strong> e faça upload na sua hospedagem (public_html).</p>
          </div>
          <div className="flex gap-3">
            <Button onClick={copyToClipboard} variant="outline" className="gap-2">
                <Copy className="w-4 h-4" />
                Copiar Código
            </Button>
            <Button onClick={downloadHtml} className="bg-orange-600 hover:bg-orange-700 text-white gap-2">
                <Download className="w-4 h-4" />
                Baixar index.html
            </Button>
          </div>
        </div>

        <div className="relative rounded-xl overflow-hidden border border-gray-200 shadow-lg">
            <div className="bg-gray-900 px-4 py-2 text-gray-400 text-xs font-mono flex items-center gap-2">
                <div className="flex gap-1.5">
                    <div className="w-3 h-3 rounded-full bg-red-500"></div>
                    <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
                    <div className="w-3 h-3 rounded-full bg-green-500"></div>
                </div>
                <span className="ml-2 opacity-50">index.html</span>
            </div>
          <textarea 
            readOnly 
            value={landingHtml} 
            className="w-full h-[500px] p-4 font-mono text-sm bg-gray-950 text-gray-300 resize-none focus:outline-none"
          />
        </div>
      </div>
    </div>
  );
}