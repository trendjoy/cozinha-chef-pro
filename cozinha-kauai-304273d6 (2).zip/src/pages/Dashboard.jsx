import React from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
        Package, 
        AlertTriangle, 
        TrendingUp, 
        ClipboardList,
        DollarSign,
        Tag,
        ArrowDownCircle,
        AlertOctagon,
        ThermometerSnowflake,
        Droplets,
        ClipboardCheck,
        Sparkles,
        Utensils
        } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { format, subDays, isAfter, isBefore, addDays } from "date-fns";
import { Warehouse } from "lucide-react";
import { useOrganization } from "@/components/auth/OrganizationProvider";
      import { 
        BarChart, 
        Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer
} from "recharts";

import StatsCard from "../components/dashboard/StatsCard";
import ProducaoRecente from "../components/dashboard/ProducaoRecente";
import EstoqueCritico from "../components/dashboard/EstoqueCritico";

export default function Dashboard() {
  const { organizacao } = useOrganization();

  const { data: produtos = [], isLoading: loadingProdutos } = useQuery({
    queryKey: ['produtos', organizacao?.id],
    queryFn: () => {
      if (!organizacao?.id) return [];
      return base44.entities.Produto.filter({ organizacao_id: organizacao.id });
    },
    enabled: !!organizacao?.id,
  });

  const { data: producoes = [], isLoading: loadingProducoes } = useQuery({
    queryKey: ['producoes', organizacao?.id],
    queryFn: () => {
      if (!organizacao?.id) return [];
      return base44.entities.Producao.filter({ organizacao_id: organizacao.id }, '-created_date');
    },
    enabled: !!organizacao?.id,
  });

  const { data: preparacoes = [] } = useQuery({
    queryKey: ['preparacoes', organizacao?.id],
    queryFn: () => {
      if (!organizacao?.id) return [];
      return base44.entities.Preparacao.filter({ organizacao_id: organizacao.id });
    },
    enabled: !!organizacao?.id,
  });

  const { data: historico = [] } = useQuery({
    queryKey: ['historico-estoque', organizacao?.id],
    queryFn: () => {
      if (!organizacao?.id) return [];
      return base44.entities.HistoricoEstoque.filter({ organizacao_id: organizacao.id }, '-created_date', 2000);
    },
    enabled: !!organizacao?.id,
  });

  const produtosAbaixoEstoque = produtos.filter(
    p => p.estoque_atual < p.par_stock && p.par_stock > 0
  );

  const producoesHoje = producoes.filter(
    p => p.data_producao === format(new Date(), 'yyyy-MM-dd')
  );

  const itensVencendo = producoes.filter(p => {
    if (!p.data_validade) return false;
    const validade = new Date(p.data_validade);
    const hoje = new Date();
    const doisDias = addDays(hoje, 2);
    return isAfter(validade, hoje) && isBefore(validade, doisDias);
  });

  const custoEstoqueProdutos = produtos.reduce(
    (sum, p) => sum + ((p.estoque_atual || 0) * (p.custo_unitario || 0)), 
    0
  );

  const custoEstoquePreparacoes = preparacoes.reduce(
    (sum, p) => sum + ((p.estoque_atual || 0) * (p.custo_unitario || 0)), 
    0
  );

  const custoEstoqueSecundario = custoEstoqueProdutos + custoEstoquePreparacoes;

  const custoEstoquePrimario = produtos.reduce(
    (sum, p) => sum + ((p.estoque_primario || 0) * (p.custo_unitario || 0)), 
    0
  );

  const mesAtual = new Date().getMonth();
  const anoAtual = new Date().getFullYear();

  const custoRefeitorioMes = historico
    .filter(h => {
      const data = new Date(h.created_date);
      return h.motivo === 'refeitorio' && data.getMonth() === mesAtual && data.getFullYear() === anoAtual;
    })
    .reduce((sum, h) => sum + (h.custo_total || 0), 0);

  const dadosSemanais = Array.from({ length: 7 }, (_, i) => {
    const data = format(subDays(new Date(), 6 - i), 'yyyy-MM-dd');
    const qtd = producoes.filter(p => p.data_producao === data).length;
    return {
      dia: format(subDays(new Date(), 6 - i), 'EEE'),
      producoes: qtd
    };
  });

  return (
    <div className="p-4 md:p-8 min-h-screen">
      <div className="max-w-7xl mx-auto space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 flex flex-col md:flex-row md:items-center gap-2">
            <span>Dashboard</span>
            {organizacao?.nome && (
              <>
                <span className="hidden md:inline text-gray-300">|</span>
                <span className="text-orange-600">{organizacao.nome}</span>
              </>
            )}
          </h1>
          <p className="text-gray-600 mt-1">Visão geral da produção e estoque</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
          <StatsCard
            title="Produções Hoje"
            value={producoesHoje.length}
            icon={ClipboardList}
            bgColor="bg-blue-500"
            loading={loadingProducoes}
          />
          <StatsCard
            title="Itens Vencendo"
            value={itensVencendo.length}
            icon={AlertTriangle}
            bgColor="bg-yellow-500"
            loading={loadingProducoes}
          />
          <StatsCard
            title="Estoque Baixo"
            value={produtosAbaixoEstoque.length}
            icon={Package}
            bgColor="bg-red-500"
            loading={loadingProdutos}
          />
          <StatsCard
            title="Vl. Almoxarifado"
            value={`R$ ${custoEstoquePrimario.toFixed(2)}`}
            icon={Warehouse}
            bgColor="bg-indigo-500"
            loading={loadingProdutos}
          />
          <StatsCard
            title="Vl. Cozinha"
            value={`R$ ${custoEstoqueSecundario.toFixed(2)}`}
            icon={DollarSign}
            bgColor="bg-green-500"
            loading={loadingProdutos}
          />
          <StatsCard
            title="Custo Refeitório (Mês)"
            value={`R$ ${custoRefeitorioMes.toFixed(2)}`}
            icon={Utensils}
            bgColor="bg-indigo-500"
            loading={loadingProducoes} // Usando loadingProducoes como proxy para historico
          />
          </div>

        {/* Acesso Rápido Mobile */}
        {/* Menu de Acesso Rápido Operacional */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
            <Link to={createPageUrl("Produtos")}>
                <Card className="hover:bg-purple-50 transition-colors cursor-pointer border-purple-200/50 shadow-sm hover:shadow-md">
                    <CardContent className="p-4 flex flex-col items-center text-center gap-2">
                        <div className="p-3 bg-purple-100 rounded-full text-purple-600">
                            <Sparkles className="w-6 h-6" />
                        </div>
                        <span className="font-semibold text-gray-700">Importar (IA)</span>
                    </CardContent>
                </Card>
            </Link>
            <Link to={createPageUrl("Movimentacoes?tab=retirada")}>
                <Card className="hover:bg-orange-50 transition-colors cursor-pointer border-orange-200/50 shadow-sm hover:shadow-md">
                    <CardContent className="p-4 flex flex-col items-center text-center gap-2">
                        <div className="p-3 bg-orange-100 rounded-full text-orange-600">
                            <ArrowDownCircle className="w-6 h-6" />
                        </div>
                        <span className="font-semibold text-gray-700">Baixa Produção</span>
                    </CardContent>
                </Card>
            </Link>
            <Link to={createPageUrl("Movimentacoes?tab=perda")}>
                <Card className="hover:bg-red-50 transition-colors cursor-pointer border-red-200/50 shadow-sm hover:shadow-md">
                    <CardContent className="p-4 flex flex-col items-center text-center gap-2">
                        <div className="p-3 bg-red-100 rounded-full text-red-600">
                            <AlertOctagon className="w-6 h-6" />
                        </div>
                        <span className="font-semibold text-gray-700">Registrar Perda</span>
                    </CardContent>
                </Card>
            </Link>
            <Link to={createPageUrl("Movimentacoes?tab=temperatura")}>
                <Card className="hover:bg-blue-50 transition-colors cursor-pointer border-blue-200/50 shadow-sm hover:shadow-md">
                    <CardContent className="p-4 flex flex-col items-center text-center gap-2">
                        <div className="p-3 bg-blue-100 rounded-full text-blue-600">
                            <ThermometerSnowflake className="w-6 h-6" />
                        </div>
                        <span className="font-semibold text-gray-700">Temperatura</span>
                    </CardContent>
                </Card>
            </Link>
            <Link to={createPageUrl("Movimentacoes?tab=manutencao")}>
                <Card className="hover:bg-green-50 transition-colors cursor-pointer border-green-200/50 shadow-sm hover:shadow-md">
                    <CardContent className="p-4 flex flex-col items-center text-center gap-2">
                        <div className="p-3 bg-green-100 rounded-full text-green-600">
                            <Droplets className="w-6 h-6" />
                        </div>
                        <span className="font-semibold text-gray-700">Manutenção</span>
                    </CardContent>
                </Card>
            </Link>
        </div>

        <div className="md:hidden grid grid-cols-1 gap-4">
            <Link to={createPageUrl("Etiquetas")}>
                <Button className="w-full h-14 text-lg font-semibold bg-white border border-orange-200 text-orange-700 hover:bg-orange-50 shadow-sm">
                    <Tag className="w-5 h-5 mr-2" />
                    Gerar Etiquetas
                </Button>
            </Link>
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <Card className="border-orange-200/50 shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-orange-600" />
                  Produção dos Últimos 7 Dias
                </CardTitle>
              </CardHeader>
              <CardContent>
                {loadingProducoes ? (
                  <Skeleton className="h-64 w-full" />
                ) : (
                  <ResponsiveContainer width="100%" height={250}>
                    <BarChart data={dadosSemanais}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#fed7aa" />
                      <XAxis dataKey="dia" stroke="#9a3412" />
                      <YAxis stroke="#9a3412" />
                      <Tooltip 
                        contentStyle={{ 
                          backgroundColor: '#fff', 
                          border: '1px solid #fed7aa',
                          borderRadius: '8px'
                        }} 
                      />
                      <Bar dataKey="producoes" fill="#f97316" radius={[8, 8, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                )}
              </CardContent>
            </Card>

            <ProducaoRecente producoes={producoes.slice(0, 10)} loading={loadingProducoes} />
          </div>

          <div className="space-y-6">
            <EstoqueCritico produtos={produtosAbaixoEstoque} loading={loadingProdutos} />
            
            {itensVencendo.length > 0 && (
              <Card className="border-yellow-200 bg-yellow-50/50 shadow-lg">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-yellow-800">
                    <AlertTriangle className="w-5 h-5" />
                    Itens Vencendo
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {itensVencendo.slice(0, 5).map((item) => (
                      <div key={item.id} className="flex justify-between items-start p-3 bg-white rounded-lg border border-yellow-200">
                        <div>
                          <p className="font-medium text-gray-900 text-sm">
                            {item.preparacao_nome}
                          </p>
                          <p className="text-xs text-gray-600 mt-1">
                            Lote: {item.lote}
                          </p>
                        </div>
                        <div className="text-right">
                          <p className="text-xs text-yellow-700 font-medium">
                            {format(new Date(item.data_validade), 'dd/MM/yyyy')}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}