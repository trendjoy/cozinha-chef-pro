import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Skeleton } from "@/components/ui/skeleton";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Bot, ChefHat, Sparkles, Clock, AlertTriangle, ArrowRight, Utensils } from "lucide-react";
import { format, addDays, isAfter, isBefore } from "date-fns";
import { toast } from "sonner";
import ReactMarkdown from "react-markdown";
import { useOrganization } from "@/components/auth/OrganizationProvider";

export default function ChefeVirtual() {
  const [selectedItems, setSelectedItems] = useState([]);
  const [suggestion, setSuggestion] = useState(null);
  const [loadingIA, setLoadingIA] = useState(false);
  const { organizacao } = useOrganization();

  // Buscar produções para ver o que está vencendo
  const { data: producoes = [], isLoading } = useQuery({
    queryKey: ['producoes', organizacao?.id],
    queryFn: () => {
      if (!organizacao?.id) return [];
      return base44.entities.Producao.filter({ organizacao_id: organizacao.id }, '-data_validade', 100);
    },
    enabled: !!organizacao?.id,
  });

  // Filtrar itens vencendo nos próximos 5 dias
  const itensVencendo = producoes.filter(p => {
    if (!p.data_validade) return false;
    const validade = new Date(p.data_validade);
    const hoje = new Date();
    const limite = addDays(hoje, 5); // Próximos 5 dias
    // Vence no futuro próximo e ainda não venceu (ou venceu hoje)
    return isBefore(validade, limite) && isAfter(validade, addDays(hoje, -1));
  });

  const toggleItem = (id) => {
    setSelectedItems(prev => 
      prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]
    );
  };

  const handleGenerateSuggestion = async () => {
    if (selectedItems.length === 0) {
      toast.error("Selecione pelo menos um item para o Chefe analisar.");
      return;
    }

    setLoadingIA(true);
    setSuggestion(null);

    try {
      const itensSelecionados = itensVencendo
        .filter(i => selectedItems.includes(i.id))
        .map(i => `${i.preparacao_nome} (${i.quantidade_produzida} ${i.unidade}, vence em ${format(new Date(i.data_validade), 'dd/MM')})`)
        .join(", ");

      const prompt = `
        Atue como um Chef de Cozinha Criativo e experiente em evitar desperdícios.
        Tenho os seguintes ingredientes/preparações que estão próximos do vencimento:
        ${itensSelecionados}

        Crie uma sugestão de "Prato do Dia" ou "Promoção Relâmpago" para utilizar esses itens.
        
        A resposta deve ser um objeto JSON com a seguinte estrutura:
        {
          "nome_prato": "Nome criativo do prato",
          "descricao_venda": "Texto curto e persuasivo para os garçons venderem o prato",
          "sugestao_preco": "Sugestão de preço baseada em valor percebido (apenas número ou texto curto)",
          "modo_preparo": "Resumo rápido de como montar/finalizar o prato usando os ingredientes",
          "dicas_chef": "Uma dica extra para deixar o prato especial"
        }
      `;

      const response = await base44.integrations.Core.InvokeLLM({
        prompt: prompt,
        response_json_schema: {
          type: "object",
          properties: {
            nome_prato: { type: "string" },
            descricao_venda: { type: "string" },
            sugestao_preco: { type: "string" },
            modo_preparo: { type: "string" },
            dicas_chef: { type: "string" }
          }
        }
      });

      setSuggestion(response);
      toast.success("Sugestão criada com sucesso!");

    } catch (error) {
      console.error(error);
      toast.error("O Chefe está ocupado agora. Tente novamente.");
    } finally {
      setLoadingIA(false);
    }
  };

  return (
    <div className="p-4 md:p-8 min-h-screen bg-gray-50/50">
      <div className="max-w-6xl mx-auto space-y-8">
        
        <div className="flex items-center gap-4">
          <div className="bg-gradient-to-br from-indigo-600 to-purple-600 p-3 rounded-xl shadow-lg">
            <Bot className="w-8 h-8 text-white" />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Chefe Virtual</h1>
            <p className="text-gray-600">IA para combater o desperdício e criar oportunidades</p>
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Coluna da Esquerda: Seleção de Itens */}
          <div className="lg:col-span-1 space-y-4">
            <Card className="border-orange-200 shadow-md h-full">
              <CardHeader className="bg-orange-50/50 pb-4">
                <CardTitle className="flex items-center gap-2 text-orange-800">
                  <AlertTriangle className="w-5 h-5" />
                  Itens Vencendo (5 dias)
                </CardTitle>
                <CardDescription>
                  Selecione os itens que deseja utilizar
                </CardDescription>
              </CardHeader>
              <CardContent className="p-0">
                <ScrollArea className="h-[500px] p-4">
                  {isLoading ? (
                    <div className="space-y-2">
                      <Skeleton className="h-12 w-full" />
                      <Skeleton className="h-12 w-full" />
                      <Skeleton className="h-12 w-full" />
                    </div>
                  ) : itensVencendo.length === 0 ? (
                    <div className="text-center py-8 text-gray-500">
                      <CheckCircle2 className="w-12 h-12 mx-auto mb-2 text-green-500" />
                      <p>Tudo certo! Nenhum item vencendo em breve.</p>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {itensVencendo.map((item) => (
                        <div 
                          key={item.id}
                          className={`flex items-start gap-3 p-3 rounded-lg border cursor-pointer transition-all ${
                            selectedItems.includes(item.id) 
                              ? "bg-orange-50 border-orange-300 shadow-sm" 
                              : "bg-white border-gray-100 hover:border-orange-200"
                          }`}
                          onClick={() => toggleItem(item.id)}
                        >
                          <Checkbox 
                            checked={selectedItems.includes(item.id)}
                            onCheckedChange={() => toggleItem(item.id)}
                          />
                          <div className="flex-1">
                            <p className="font-medium text-gray-900 text-sm">{item.preparacao_nome}</p>
                            <div className="flex justify-between items-center mt-1">
                              <span className="text-xs text-gray-500">Lote: {item.lote}</span>
                              <Badge variant="outline" className="text-[10px] border-red-200 text-red-700 bg-red-50">
                                {format(new Date(item.data_validade), 'dd/MM')}
                              </Badge>
                            </div>
                            <p className="text-xs text-gray-500 mt-1">
                              Qtd: {item.quantidade_produzida} {item.unidade}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </ScrollArea>
                <div className="p-4 border-t border-orange-100 bg-orange-50/30">
                  <Button 
                    className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white shadow-md group"
                    onClick={handleGenerateSuggestion}
                    disabled={loadingIA || selectedItems.length === 0}
                  >
                    {loadingIA ? (
                      <>
                        <Sparkles className="w-4 h-4 mr-2 animate-spin" />
                        O Chef está pensando...
                      </>
                    ) : (
                      <>
                        <ChefHat className="w-4 h-4 mr-2" />
                        Gerar Sugestão com IA
                        <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
                      </>
                    )}
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Coluna da Direita: Resultado */}
          <div className="lg:col-span-2">
            {suggestion ? (
              <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-700">
                <Card className="border-indigo-100 shadow-xl overflow-hidden bg-white">
                  <div className="h-2 bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500" />
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div>
                        <Badge className="mb-2 bg-indigo-100 text-indigo-700 border-indigo-200 hover:bg-indigo-100">
                          Sugestão do Chef
                        </Badge>
                        <CardTitle className="text-3xl font-bold text-gray-900">{suggestion.nome_prato}</CardTitle>
                      </div>
                      <div className="text-right">
                        <span className="text-sm text-gray-500 uppercase tracking-wider font-semibold">Preço Sugerido</span>
                        <p className="text-2xl font-bold text-green-600">{suggestion.sugestao_preco}</p>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="bg-indigo-50 p-4 rounded-xl border border-indigo-100">
                      <h3 className="flex items-center gap-2 font-semibold text-indigo-900 mb-2">
                        <Sparkles className="w-4 h-4" />
                        Argumento de Venda (Pitch)
                      </h3>
                      <p className="text-indigo-800 italic text-lg leading-relaxed">
                        "{suggestion.descricao_venda}"
                      </p>
                    </div>

                    <div className="grid md:grid-cols-2 gap-6">
                      <div>
                        <h3 className="flex items-center gap-2 font-semibold text-gray-900 mb-3">
                          <Utensils className="w-4 h-4 text-orange-500" />
                          Montagem / Preparo
                        </h3>
                        <div className="text-gray-600 text-sm leading-relaxed whitespace-pre-wrap">
                          {suggestion.modo_preparo}
                        </div>
                      </div>
                      
                      <div>
                        <h3 className="flex items-center gap-2 font-semibold text-gray-900 mb-3">
                          <Clock className="w-4 h-4 text-blue-500" />
                          Toque do Chef
                        </h3>
                        <div className="bg-yellow-50 p-3 rounded-lg border border-yellow-100 text-yellow-800 text-sm">
                          {suggestion.dicas_chef}
                        </div>
                      </div>
                    </div>

                    <Separator />
                    
                    <div className="flex justify-end gap-3">
                      <Button variant="outline" onClick={() => {
                        setSuggestion(null);
                        setSelectedItems([]);
                      }}>
                        Limpar e Começar Novo
                      </Button>
                      <Button className="bg-indigo-600 hover:bg-indigo-700" onClick={() => window.print()}>
                        Imprimir Sugestão
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </div>
            ) : (
              <div className="h-full flex flex-col items-center justify-center p-12 text-center border-2 border-dashed border-gray-200 rounded-xl bg-gray-50/50">
                <div className="w-20 h-20 bg-indigo-100 rounded-full flex items-center justify-center mb-6">
                  <ChefHat className="w-10 h-10 text-indigo-500" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">O Chef Virtual está aguardando</h3>
                <p className="text-gray-500 max-w-md">
                  Selecione os itens que estão vencendo na lista ao lado e clique em "Gerar Sugestão" para receber uma ideia criativa de venda.
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}