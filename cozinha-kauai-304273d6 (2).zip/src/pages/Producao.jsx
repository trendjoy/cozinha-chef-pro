import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { CalendarIcon, Printer, CheckCircle, ClipboardList, Target, Download, Save } from "lucide-react";
import { format, addDays } from "date-fns";
import { toast } from "sonner";

import BuscaPreparacao from "../components/producao/BuscaPreparacao";
import EtiquetaPreview from "../components/producao/EtiquetaPreview";
import { useOrganization } from "@/components/auth/OrganizationProvider";

export default function Producao() {
  const { organizacao } = useOrganization();
  // Estado Registrar Produção
  const [preparacaoSelecionada, setPreparacaoSelecionada] = useState(null);
  const [quantidade, setQuantidade] = useState("");
  const [armazenamento, setArmazenamento] = useState("RESFRIADO");
  const [dataProducao, setDataProducao] = useState(new Date());
  const [dataValidade, setDataValidade] = useState(null);
  const [responsavel, setResponsavel] = useState("");
  const [sucesso, setSucesso] = useState(false);
  const [etiquetaData, setEtiquetaData] = useState(null);

  // Estado Planejamento (Par Stock)
  const [parStockChanges, setParStockChanges] = useState({}); // { id: valor }

  const queryClient = useQueryClient();

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: async () => {
      try {
        return await base44.auth.me();
      } catch {
        return null;
      }
    },
  });

  const { data: preparacoes = [], isLoading: loadingPreparacoes } = useQuery({
    queryKey: ['preparacoes', organizacao?.id],
    queryFn: () => {
      if (!organizacao?.id) return [];
      return base44.entities.Preparacao.filter({ organizacao_id: organizacao.id });
    },
    enabled: !!organizacao?.id,
  });

  // --- Registrar Produção Mutations ---
  const createProducaoMutation = useMutation({
    mutationFn: async (data) => {
      await base44.entities.Producao.create({ ...data, organizacao_id: organizacao.id });

      const novaQtd = (preparacaoSelecionada.estoque_atual || 0) + data.quantidade_produzida;
      await base44.entities.Preparacao.update(preparacaoSelecionada.id, {
        estoque_atual: novaQtd
      });

      await base44.entities.HistoricoEstoque.create({
        organizacao_id: organizacao.id,
        tipo_item: "preparacao",
        item_id: preparacaoSelecionada.id,
        item_nome: preparacaoSelecionada.nome,
        movimento: "producao",
        quantidade: data.quantidade_produzida,
        estoque_anterior: preparacaoSelecionada.estoque_atual || 0,
        estoque_novo: novaQtd,
        motivo: "producao",
        responsavel: data.responsavel,
        data_movimento: new Date().toISOString()
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['producoes']);
      queryClient.invalidateQueries(['preparacoes']);
      setSucesso(true);
      setTimeout(() => setSucesso(false), 3000);
    },
  });

  // --- Planejamento Mutations ---
  const updateParStockMutation = useMutation({
    mutationFn: async () => {
      const promises = Object.entries(parStockChanges).map(([id, valor]) => 
        base44.entities.Preparacao.update(id, { par_stock: parseFloat(valor) || 0 })
      );
      await Promise.all(promises);
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['preparacoes']);
      setParStockChanges({});
      toast.success("Par Stock atualizado com sucesso!");
    },
    onError: () => {
      toast.error("Erro ao atualizar Par Stock");
    }
  });

  // --- Handlers Registrar Produção ---
  const handlePreparacaoSelect = (preparacao) => {
    setPreparacaoSelecionada(preparacao);
    atualizarValidade(preparacao, armazenamento, dataProducao);
  };

  const atualizarValidade = (preparacao, tipoArmazenamento, dataProd) => {
    if (!preparacao) return;
    
    let dias = 3; 
    if (tipoArmazenamento === 'CONGELADO') {
      dias = preparacao.validade_congelado_dias || 30;
    } else {
      dias = preparacao.validade_dias || 3;
    }
    
    setDataValidade(addDays(dataProd, dias));
  };

  const gerarLote = () => {
    const dataStr = format(dataProducao, 'yyyy-MM-dd');
    const random = Math.floor(Math.random() * 9999).toString().padStart(4, '0');
    return `${dataStr}-${random}`;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const lote = gerarLote();
    const responsavelFinal = responsavel || user?.full_name || 'Sistema';

    const producaoData = {
      preparacao_id: preparacaoSelecionada.id,
      preparacao_nome: preparacaoSelecionada.nome,
      quantidade_produzida: parseFloat(quantidade),
      unidade: preparacaoSelecionada.unidade_saida,
      data_producao: format(dataProducao, 'yyyy-MM-dd'),
      data_validade: dataValidade ? format(dataValidade, 'yyyy-MM-dd') : null,
      lote,
      responsavel: responsavelFinal,
      praca: preparacaoSelecionada.praca,
    };

    setEtiquetaData({
      nome: preparacaoSelecionada.nome,
      quantidade: `${quantidade} ${preparacaoSelecionada.unidade_saida}`,
      data: format(dataProducao, 'dd/MM/yyyy'),
      validade: dataValidade ? format(dataValidade, 'dd/MM/yyyy') : 'N/A',
      lote,
      responsavel: responsavelFinal,
    });

    await createProducaoMutation.mutateAsync(producaoData);

    setPreparacaoSelecionada(null);
    setQuantidade("");
    setResponsavel("");
    setDataValidade(null);
  };

  // --- Handlers Planejamento ---
  const handleParStockChange = (id, value) => {
    setParStockChanges(prev => ({ ...prev, [id]: value }));
  };

  const handleExportPlanning = () => {
    const itemsToProduce = preparacoes.filter(p => 
      (p.estoque_atual || 0) < (p.par_stock || 0)
    ).map(p => {
      const estoque = p.estoque_atual || 0;
      const par = p.par_stock || 0;
      const produzir = par - estoque;
      return {
        nome: p.nome,
        categoria: p.categoria,
        unidade: p.unidade_saida,
        estoque_atual: estoque,
        par_stock: par,
        produzir: produzir > 0 ? produzir : 0
      };
    });

    if (itemsToProduce.length === 0) {
      toast.info("Nenhum item abaixo do Par Stock.");
      return;
    }

    const csvContent = [
      "Nome;Categoria;Unidade;Estoque Atual;Par Stock;Sugerido Produzir",
      ...itemsToProduce.map(i => 
        `"${i.nome}";"${i.categoria}";"${i.unidade}";${i.estoque_atual};${i.par_stock};${i.produzir}`
      )
    ].join("\n");

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", "planejamento_producao.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Filter preparations for planning table (sort by needed production descending)
  const preparacoesPlanejamento = [...preparacoes].sort((a, b) => {
    const diffA = (a.par_stock || 0) - (a.estoque_atual || 0);
    const diffB = (b.par_stock || 0) - (b.estoque_atual || 0);
    return diffB - diffA; // Most needed first
  });

  const temAlteracoesParStock = Object.keys(parStockChanges).length > 0;

  return (
    <div className="p-4 md:p-8 min-h-screen">
      <div className="max-w-6xl mx-auto space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
            <ClipboardList className="w-8 h-8 text-orange-600" />
            Central de Produção
          </h1>
          <p className="text-gray-600 mt-1">Gerencie sua produção e planejamento</p>
        </div>

        {sucesso && (
          <Alert className="border-green-500 bg-green-50">
            <CheckCircle className="h-4 w-4 text-green-600" />
            <AlertDescription className="text-green-800">
              Produção registrada com sucesso!
            </AlertDescription>
          </Alert>
        )}

        <Tabs defaultValue="registrar" className="w-full">
          <TabsList className="grid w-full grid-cols-2 max-w-[400px]">
            <TabsTrigger value="registrar">Registrar Produção</TabsTrigger>
            <TabsTrigger value="planejamento">Planejamento (Par Stock)</TabsTrigger>
          </TabsList>

          <TabsContent value="registrar">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-6">
              <Card className="border-orange-200/50 shadow-lg h-fit">
                <CardHeader className="bg-gradient-to-r from-orange-50 to-amber-50">
                  <CardTitle>Dados da Produção</CardTitle>
                </CardHeader>
                <CardContent className="pt-6">
                  <form onSubmit={handleSubmit} className="space-y-6">
                    <BuscaPreparacao
                      onSelect={handlePreparacaoSelect}
                      selecionado={preparacaoSelecionada}
                    />

                    {preparacaoSelecionada && (
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 p-4 bg-orange-50/50 rounded-lg">
                        <div className="col-span-2 md:col-span-1">
                          <Label>Quantidade Produzida *</Label>
                          <Input
                            type="number"
                            step="0.01"
                            value={quantidade}
                            onChange={(e) => setQuantidade(e.target.value)}
                            placeholder={`Ex: 10 ${preparacaoSelecionada.unidade_saida}`}
                            required
                            className="border-orange-200 focus:border-orange-400"
                          />
                        </div>

                        <div className="col-span-2 md:col-span-1">
                          <Label>Armazenamento</Label>
                          <Select 
                            value={armazenamento} 
                            onValueChange={(v) => {
                              setArmazenamento(v);
                              atualizarValidade(preparacaoSelecionada, v, dataProducao);
                            }}
                          >
                            <SelectTrigger className="border-orange-200">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="RESFRIADO">RESFRIADO (3 Dias)</SelectItem>
                              <SelectItem value="CONGELADO">CONGELADO (30 Dias)</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>

                        <div className="col-span-2 md:col-span-1">
                          <Label>Data de Produção</Label>
                          <Popover>
                            <PopoverTrigger asChild>
                              <Button
                                variant="outline"
                                className="w-full justify-start text-left border-orange-200"
                              >
                                <CalendarIcon className="mr-2 h-4 w-4" />
                                {format(dataProducao, 'dd/MM/yyyy')}
                              </Button>
                            </PopoverTrigger>
                            <PopoverContent className="w-auto p-0">
                              <Calendar
                                mode="single"
                                selected={dataProducao}
                                onSelect={(date) => {
                                  setDataProducao(date);
                                  atualizarValidade(preparacaoSelecionada, armazenamento, date);
                                }}
                              />
                            </PopoverContent>
                          </Popover>
                        </div>

                        <div className="col-span-2 md:col-span-1">
                          <Label>Data de Validade</Label>
                          <Popover>
                            <PopoverTrigger asChild>
                              <Button
                                variant="outline"
                                className="w-full justify-start text-left border-orange-200"
                              >
                                <CalendarIcon className="mr-2 h-4 w-4" />
                                {dataValidade ? format(dataValidade, 'dd/MM/yyyy') : 'Selecionar'}
                              </Button>
                            </PopoverTrigger>
                            <PopoverContent className="w-auto p-0">
                              <Calendar
                                mode="single"
                                selected={dataValidade}
                                onSelect={setDataValidade}
                              />
                            </PopoverContent>
                          </Popover>
                        </div>

                        <div className="col-span-2">
                          <Label>Responsável</Label>
                          <Input
                            value={responsavel}
                            onChange={(e) => setResponsavel(e.target.value)}
                            placeholder={user?.full_name || "Nome do responsável"}
                            className="border-orange-200 focus:border-orange-400"
                          />
                        </div>
                      </div>
                    )}

                    <div className="flex justify-end gap-3">
                      <Button
                        type="submit"
                        disabled={!preparacaoSelecionada || !quantidade || createProducaoMutation.isPending}
                        className="bg-gradient-to-r from-orange-500 to-amber-600 hover:from-orange-600 hover:to-amber-700 w-full md:w-auto"
                      >
                        {createProducaoMutation.isPending ? 'Registrando...' : 'Registrar Produção'}
                      </Button>
                    </div>
                  </form>
                </CardContent>
              </Card>

              <div className="space-y-6">
                {etiquetaData ? (
                  <Card className="border-orange-200/50 shadow-lg h-fit sticky top-4">
                    <CardHeader className="bg-gradient-to-r from-orange-50 to-amber-50">
                      <CardTitle className="flex items-center gap-2">
                        <Printer className="w-5 h-5 text-orange-600" />
                        Etiqueta Gerada
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="pt-6">
                      <EtiquetaPreview data={etiquetaData} />
                    </CardContent>
                  </Card>
                ) : (
                  <div className="hidden lg:flex h-64 items-center justify-center border-2 border-dashed border-gray-200 rounded-xl bg-gray-50 text-gray-400 flex-col gap-2">
                    <Printer className="w-8 h-8" />
                    <span className="text-sm">A etiqueta aparecerá aqui após o registro</span>
                  </div>
                )}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="planejamento">
            <Card className="border-orange-200/50 shadow-lg mt-6">
              <CardHeader className="bg-gradient-to-r from-orange-50 to-amber-50 flex flex-row items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    <Target className="w-5 h-5 text-orange-600" />
                    Planejamento de Produção
                  </CardTitle>
                  <p className="text-sm text-gray-500 mt-1">Defina o Par Stock (Estoque Mínimo) para calcular o que precisa ser produzido.</p>
                </div>
                <div className="flex gap-2">
                   <Button
                    variant="outline"
                    onClick={handleExportPlanning}
                    className="gap-2 border-orange-300 hover:bg-orange-100"
                  >
                    <Download className="w-4 h-4" />
                    Exportar Lista
                  </Button>
                  <Button 
                    onClick={() => updateParStockMutation.mutate()}
                    disabled={!temAlteracoesParStock || updateParStockMutation.isPending}
                    className={`${temAlteracoesParStock ? 'bg-green-600 hover:bg-green-700' : 'bg-gray-300'} gap-2 transition-colors`}
                  >
                    <Save className="w-4 h-4" />
                    {updateParStockMutation.isPending ? "Salvando..." : "Salvar Par Stock"}
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="p-0">
                <div className="overflow-x-auto max-h-[600px]">
                  <Table>
                    <TableHeader className="sticky top-0 bg-white shadow-sm z-10">
                      <TableRow>
                        <TableHead>Preparação</TableHead>
                        <TableHead>Categoria</TableHead>
                        <TableHead className="text-center">Unidade</TableHead>
                        <TableHead className="text-center">Estoque Atual</TableHead>
                        <TableHead className="text-center w-[120px]">Par Stock</TableHead>
                        <TableHead className="text-center">Produzir</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {loadingPreparacoes ? (
                        <TableRow>
                          <TableCell colSpan={6} className="text-center py-8">Carregando...</TableCell>
                        </TableRow>
                      ) : preparacoesPlanejamento.map((prep) => {
                        const parStock = parStockChanges[prep.id] !== undefined 
                          ? parStockChanges[prep.id] 
                          : (prep.par_stock || 0);
                        
                        const estoque = prep.estoque_atual || 0;
                        const diff = parseFloat(parStock) - estoque;
                        const precisaProduzir = diff > 0;

                        return (
                          <TableRow key={prep.id} className={precisaProduzir ? "bg-red-50 hover:bg-red-100" : "hover:bg-gray-50"}>
                            <TableCell className="font-medium">{prep.nome}</TableCell>
                            <TableCell>{prep.categoria}</TableCell>
                            <TableCell className="text-center text-xs text-gray-500">{prep.unidade_saida}</TableCell>
                            <TableCell className="text-center">{estoque.toFixed(2)}</TableCell>
                            <TableCell className="text-center">
                              <Input 
                                type="number"
                                min="0"
                                step="0.01"
                                value={parStock}
                                onChange={(e) => handleParStockChange(prep.id, e.target.value)}
                                className="h-8 w-20 mx-auto text-center border-orange-200 focus:border-orange-400"
                              />
                            </TableCell>
                            <TableCell className="text-center">
                              {precisaProduzir ? (
                                <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
                                  {diff.toFixed(2)}
                                </span>
                              ) : (
                                <span className="text-green-600 text-xs font-medium">OK</span>
                              )}
                            </TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}