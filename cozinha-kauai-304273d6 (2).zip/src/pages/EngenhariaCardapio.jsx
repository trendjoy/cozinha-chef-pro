import React, { useState, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { useOrganization } from "@/components/auth/OrganizationProvider";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Loader2, Target, Filter, Download, TrendingUp, AlertCircle, ArrowRight } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import MatrizBCG from "../components/engenharia/MatrizBCG";
import { format, subDays } from "date-fns";

export default function EngenhariaCardapio() {
  const { organizacao } = useOrganization();
  const [periodo, setPeriodo] = useState("30"); // dias
  const [busca, setBusca] = useState("");

  // 1. Buscar Vendas
  const { data: vendas = [], isLoading: loadingVendas } = useQuery({
    queryKey: ['vendas', organizacao?.id],
    queryFn: () => base44.entities.Venda.list('-data_venda', 1000), // Pegar últimas 1000 vendas para análise
    enabled: !!organizacao?.id
  });

  // 2. Buscar Preparações (para custo)
  const { data: preparacoes = [], isLoading: loadingPrep } = useQuery({
    queryKey: ['preparacoes', organizacao?.id],
    queryFn: () => base44.entities.Preparacao.list(),
    enabled: !!organizacao?.id
  });

  // 3. Processar Dados
  const dadosAnalise = useMemo(() => {
    if (vendas.length === 0 || preparacoes.length === 0) return [];

    // Filtrar por período
    const dataCorte = subDays(new Date(), parseInt(periodo));
    const vendasFiltradas = vendas.filter(v => new Date(v.data_venda) >= dataCorte);

    // Agrupar vendas por produto
    const agrupado = {};

    vendasFiltradas.forEach(venda => {
      const nome = venda.nome_produto;
      if (!agrupado[nome]) {
        agrupado[nome] = {
          nome,
          quantidade_vendida: 0,
          valor_total_venda: 0,
          count: 0
        };
      }
      agrupado[nome].quantidade_vendida += venda.quantidade;
      agrupado[nome].valor_total_venda += venda.valor_total;
      agrupado[nome].count += 1;
    });

    // Cruzar com preparações e calcular métricas
    const resultado = Object.values(agrupado).map(item => {
        // Tenta encontrar a preparação pelo nome (fuzzy match simples seria ideal, mas vamos de exato/includes por enquanto)
        // Normalizando strings para melhorar o match
        const prep = preparacoes.find(p => 
            p.nome.toLowerCase().trim() === item.nome.toLowerCase().trim() || 
            item.nome.toLowerCase().includes(p.nome.toLowerCase())
        );

        const preco_medio_venda = item.valor_total_venda / item.quantidade_vendida;
        const custo_unitario = prep ? prep.custo_unitario : (preco_medio_venda * 0.35); // Fallback: assume CMV de 35% se não achar ficha técnica
        const margem_unitaria = preco_medio_venda - custo_unitario;

        return {
            nome: item.nome,
            quantidade_vendida: item.quantidade_vendida,
            preco_venda: preco_medio_venda,
            custo_unitario: custo_unitario,
            margem_unitaria: margem_unitaria,
            margem_total: margem_unitaria * item.quantidade_vendida,
            tem_ficha: !!prep
        };
    });

    // Filtrar itens com vendas irrelevantes para não poluir (opcional, ex: < 5 vendas)
    return resultado.filter(i => i.quantidade_vendida > 0).sort((a, b) => b.quantidade_vendida - a.quantidade_vendida);

  }, [vendas, preparacoes, periodo]);

  // Dados filtrados pela busca
  const dadosExibidos = dadosAnalise.filter(d => d.nome.toLowerCase().includes(busca.toLowerCase()));

  if (loadingVendas || loadingPrep) {
    return (
      <div className="h-screen flex flex-col items-center justify-center bg-orange-50/50">
        <Loader2 className="w-10 h-10 text-orange-600 animate-spin mb-4" />
        <p className="text-gray-600 font-medium">Calculando rentabilidade do cardápio...</p>
      </div>
    );
  }

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
            <Target className="w-8 h-8 text-orange-600" />
            Engenharia de Cardápio
          </h1>
          <p className="text-gray-600 mt-1">
            Matriz de Popularidade x Lucratividade para otimização do seu menu.
          </p>
        </div>
        <div className="flex gap-2 items-center">
            <Select value={periodo} onValueChange={setPeriodo}>
                <SelectTrigger className="w-[180px] bg-white">
                    <SelectValue placeholder="Período" />
                </SelectTrigger>
                <SelectContent>
                    <SelectItem value="7">Últimos 7 dias</SelectItem>
                    <SelectItem value="30">Últimos 30 dias</SelectItem>
                    <SelectItem value="90">Últimos 90 dias</SelectItem>
                </SelectContent>
            </Select>
            <Button variant="outline" className="gap-2">
                <Download className="w-4 h-4" /> Exportar
            </Button>
        </div>
      </div>

      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 flex flex-col md:flex-row justify-between items-center gap-4">
        <div className="flex items-start gap-3">
            <div className="p-2 bg-blue-100 rounded-full text-blue-600 mt-1">
                <Target className="w-5 h-5" />
            </div>
            <div>
                <h3 className="font-semibold text-blue-900">Quer analisar seu cardápio completo?</h3>
                <p className="text-sm text-blue-700">
                    Para que a matriz funcione corretamente, você precisa cadastrar seus pratos e fichas técnicas.
                    Você pode importar seu cardápio via Excel ou Foto.
                </p>
            </div>
        </div>
        <Link to={createPageUrl("Preparacoes")}>
            <Button className="bg-blue-600 hover:bg-blue-700 text-white gap-2 whitespace-nowrap">
                Cadastrar / Importar Cardápio <ArrowRight className="w-4 h-4" />
            </Button>
        </Link>
      </div>

      {dadosAnalise.some(d => !d.tem_ficha) && (
        <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 flex items-start gap-3 text-amber-800 text-sm">
            <AlertCircle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
            <div>
                <p className="font-semibold">Atenção: Alguns produtos vendidos não têm Ficha Técnica vinculada.</p>
                <p>Para esses itens, o sistema estimou um Custo (CMV) de 35%. Para maior precisão, cadastre as preparações com o mesmo nome do produto de venda.</p>
            </div>
        </div>
      )}

      <Tabs defaultValue="matriz" className="w-full">
        <TabsList className="grid w-full grid-cols-2 max-w-[400px]">
            <TabsTrigger value="matriz">Matriz de Análise</TabsTrigger>
            <TabsTrigger value="detalhado">Dados Detalhados</TabsTrigger>
        </TabsList>

        <TabsContent value="matriz" className="mt-6">
            <MatrizBCG dados={dadosAnalise} />
        </TabsContent>

        <TabsContent value="detalhado" className="mt-6">
            <Card>
                <CardHeader>
                    <div className="flex justify-between items-center">
                        <CardTitle>Desempenho por Prato</CardTitle>
                        <div className="relative w-64">
                            <Filter className="absolute left-2 top-2.5 h-4 w-4 text-gray-400" />
                            <Input 
                                placeholder="Buscar prato..." 
                                className="pl-8"
                                value={busca}
                                onChange={e => setBusca(e.target.value)}
                            />
                        </div>
                    </div>
                </CardHeader>
                <CardContent>
                    <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead>Prato / Item</TableHead>
                                <TableHead className="text-right">Vendas (Qtd)</TableHead>
                                <TableHead className="text-right">Preço Médio</TableHead>
                                <TableHead className="text-right">Custo (CMV)</TableHead>
                                <TableHead className="text-right">Margem R$</TableHead>
                                <TableHead className="text-center">Ficha Técnica</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {dadosExibidos.map((item, idx) => (
                                <TableRow key={idx}>
                                    <TableCell className="font-medium">{item.nome}</TableCell>
                                    <TableCell className="text-right">{item.quantidade_vendida}</TableCell>
                                    <TableCell className="text-right">R$ {item.preco_venda.toFixed(2)}</TableCell>
                                    <TableCell className="text-right text-red-600">R$ {item.custo_unitario.toFixed(2)}</TableCell>
                                    <TableCell className="text-right font-bold text-green-600">R$ {item.margem_unitaria.toFixed(2)}</TableCell>
                                    <TableCell className="text-center">
                                        {item.tem_ficha ? (
                                            <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">Vinculado</Badge>
                                        ) : (
                                            <Badge variant="outline" className="bg-amber-50 text-amber-700 border-amber-200">Estimado</Badge>
                                        )}
                                    </TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                </CardContent>
            </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}