import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  DollarSign, 
  TrendingDown, 
  TrendingUp, 
  PieChart, 
  ShieldAlert,
  CalendarRange
} from "lucide-react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart as RechartsPieChart,
  Pie,
  Cell
} from "recharts";
import { format, subDays, startOfMonth, endOfMonth, parseISO } from "date-fns";
import { useOrganization } from "@/components/auth/OrganizationProvider";

export default function Contabil() {
  const [currentUser, setCurrentUser] = useState(null);
  const { organizacao } = useOrganization();
  
  React.useEffect(() => {
    base44.auth.me().then(setCurrentUser).catch(() => {});
  }, []);

  // Fetch data
  const { data: historico = [] } = useQuery({
    queryKey: ['historico-contabil', organizacao?.id],
    queryFn: () => {
      if (!organizacao?.id) return [];
      return base44.entities.HistoricoEstoque.filter({ organizacao_id: organizacao.id }, undefined, 2000);
    },
    enabled: !!currentUser && currentUser.role === 'admin' && !!organizacao?.id,
  });

  const { data: produtos = [] } = useQuery({
    queryKey: ['produtos-contabil', organizacao?.id],
    queryFn: () => {
      if (!organizacao?.id) return [];
      return base44.entities.Produto.filter({ organizacao_id: organizacao.id });
    },
    enabled: !!currentUser && currentUser.role === 'admin' && !!organizacao?.id,
  });

  const { data: preparacoes = [] } = useQuery({
    queryKey: ['preparacoes-contabil', organizacao?.id],
    queryFn: () => {
      if (!organizacao?.id) return [];
      return base44.entities.Preparacao.filter({ organizacao_id: organizacao.id });
    },
    enabled: !!currentUser && currentUser.role === 'admin' && !!organizacao?.id,
  });

  if (!currentUser) return <div className="p-8">Carregando...</div>;

  if (currentUser.role !== 'admin') {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] text-center p-8">
        <ShieldAlert className="w-16 h-16 text-red-500 mb-4" />
        <h1 className="text-2xl font-bold text-gray-900">Acesso Negado</h1>
        <p className="text-gray-600 mt-2">O Painel Contábil é restrito para Managers.</p>
      </div>
    );
  }

  // Calculations
  const custoProdutos = produtos.reduce((acc, p) => acc + ((p.estoque_atual || 0) * (p.custo_unitario || 0)), 0);
  const custoPreparacoes = preparacoes.reduce((acc, p) => acc + ((p.estoque_atual || 0) * (p.custo_unitario || 0)), 0);
  
  const totalEstoqueValor = custoProdutos + custoPreparacoes;
  const totalEstoqueAlmoxarifado = produtos.reduce((acc, p) => acc + ((p.estoque_primario || 0) * (p.custo_unitario || 0)), 0);

  // Filter movements for last 30 days
  const trintaDiasAtras = subDays(new Date(), 30);
  const movimentosRecentes = historico.filter(h => new Date(h.data_movimento) >= trintaDiasAtras);

  const custoSaidas = movimentosRecentes
    .filter(h => h.movimento === 'saida' || h.movimento === 'consumo')
    .reduce((acc, h) => acc + (h.custo_total || 0), 0);

  const custoPerdas = movimentosRecentes
    .filter(h => h.movimento === 'perda')
    .reduce((acc, h) => acc + (h.custo_total || 0), 0);

  const custoRefeitorio = movimentosRecentes
    .filter(h => h.motivo === 'refeitorio')
    .reduce((acc, h) => acc + (h.custo_total || 0), 0);

  // Chart Data: Cost by Reason (Last 30 days)
  const custosPorMotivo = movimentosRecentes.reduce((acc, h) => {
    if (!h.custo_total) return acc;
    const motivo = h.motivo || 'outros';
    acc[motivo] = (acc[motivo] || 0) + h.custo_total;
    return acc;
  }, {});

  const dataMotivos = Object.entries(custosPorMotivo).map(([name, value]) => ({
    name: name.charAt(0).toUpperCase() + name.slice(1),
    value: parseFloat(value.toFixed(2))
  }));

  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8', '#82ca9d'];

  return (
    <div className="p-4 md:p-8 min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
            <PieChart className="w-8 h-8 text-emerald-600" />
            Painel Contábil
          </h1>
          <p className="text-gray-600 mt-1">Visão financeira e custos (Acesso Manager)</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <Card className="border-emerald-200 shadow-sm">
            <CardContent className="p-6">
              <div className="flex justify-between items-start">
                <div>
                  <p className="text-sm font-medium text-gray-500">Valor Estoque Cozinha</p>
                  <h3 className="text-2xl font-bold text-gray-900 mt-1">R$ {totalEstoqueValor.toFixed(2)}</h3>
                </div>
                <div className="p-2 bg-emerald-100 rounded-lg text-emerald-600">
                  <DollarSign className="w-5 h-5" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-blue-200 shadow-sm">
            <CardContent className="p-6">
              <div className="flex justify-between items-start">
                <div>
                  <p className="text-sm font-medium text-gray-500">Valor Almoxarifado</p>
                  <h3 className="text-2xl font-bold text-gray-900 mt-1">R$ {totalEstoqueAlmoxarifado.toFixed(2)}</h3>
                </div>
                <div className="p-2 bg-blue-100 rounded-lg text-blue-600">
                  <DollarSign className="w-5 h-5" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-red-200 shadow-sm">
            <CardContent className="p-6">
              <div className="flex justify-between items-start">
                <div>
                  <p className="text-sm font-medium text-gray-500">Perdas (30 dias)</p>
                  <h3 className="text-2xl font-bold text-red-600 mt-1">R$ {custoPerdas.toFixed(2)}</h3>
                </div>
                <div className="p-2 bg-red-100 rounded-lg text-red-600">
                  <TrendingDown className="w-5 h-5" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-indigo-200 shadow-sm">
            <CardContent className="p-6">
              <div className="flex justify-between items-start">
                <div>
                  <p className="text-sm font-medium text-gray-500">Refeitório (30 dias)</p>
                  <h3 className="text-2xl font-bold text-indigo-600 mt-1">R$ {custoRefeitorio.toFixed(2)}</h3>
                </div>
                <div className="p-2 bg-indigo-100 rounded-lg text-indigo-600">
                  <TrendingUp className="w-5 h-5" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid lg:grid-cols-2 gap-6">
          <Card className="shadow-md">
            <CardHeader>
              <CardTitle>Custos por Motivo (30 dias)</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <RechartsPieChart>
                    <Pie
                      data={dataMotivos}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                      outerRadius={100}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {dataMotivos.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(value) => `R$ ${value}`} />
                  </RechartsPieChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          <Card className="shadow-md">
            <CardHeader>
              <CardTitle>Detalhamento Financeiro</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex justify-between items-center p-3 bg-white border rounded-lg">
                  <span className="text-gray-600">Custo Total Saídas/Consumo</span>
                  <span className="font-bold text-gray-900">R$ {custoSaidas.toFixed(2)}</span>
                </div>
                <div className="flex justify-between items-center p-3 bg-white border rounded-lg">
                  <span className="text-gray-600">Custo Refeitório</span>
                  <span className="font-bold text-indigo-600">R$ {custoRefeitorio.toFixed(2)}</span>
                </div>
                <div className="flex justify-between items-center p-3 bg-red-50 border border-red-100 rounded-lg">
                  <span className="text-red-800">Custo Perdas/Avarias</span>
                  <span className="font-bold text-red-700">R$ {custoPerdas.toFixed(2)}</span>
                </div>
                
                <div className="pt-4 border-t mt-4">
                  <p className="text-xs text-gray-500 text-center">
                    Dados baseados nas movimentações dos últimos 30 dias.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}