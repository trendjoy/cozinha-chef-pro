import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Building2, UserPlus, Search, Loader2, Trash2, ShieldAlert, LogIn, LayoutDashboard, Users, BarChart3, Wallet, PauseCircle, PlayCircle } from "lucide-react";
import { useOrganization } from "@/components/auth/OrganizationProvider";
import { toast } from "sonner";
import { format } from "date-fns";
import { isSuperAdmin } from "@/components/auth/adminControl";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import FinanceiroSaaS from "../components/admin/FinanceiroSaaS";

export default function AdminSaaS() {
  const { user, switchOrganization, membro } = useOrganization();
  const [busca, setBusca] = useState("");

  // Protect the page
  if (user && !isSuperAdmin(user.email)) {
     return (
         <div className="min-h-screen flex flex-col items-center justify-center bg-gray-50 p-4 text-center">
             <ShieldAlert className="w-16 h-16 text-red-500 mb-4" />
             <h1 className="text-2xl font-bold text-gray-900">Acesso Restrito</h1>
             <p className="text-gray-600 max-w-md mt-2">
                Esta área é restrita ao Escritório Central (Owner). 
                Se você é o proprietário, adicione seu email <strong>({user.email})</strong> ao arquivo <code>components/auth/adminControl.js</code>.
             </p>
             <div className="flex gap-4 mt-6">
               <Button variant="outline" onClick={() => window.history.back()}>
                  Voltar
               </Button>
               <Button className="bg-indigo-600 hover:bg-indigo-700 text-white" onClick={() => base44.auth.logout()}>
                  <LogIn className="w-4 h-4 mr-2" />
                  Entrar com outra conta
               </Button>
             </div>
             </div>
             );
             }
  const [modalOpen, setModalOpen] = useState(false);
  const [novaOrg, setNovaOrg] = useState({ 
    nome: "", 
    razao_social: "",
    responsavel_nome: "",
    cnpj: "", // Documento
    endereco: "",
    dono_email: "", 
    valor_mensal: "", 
    dia_vencimento: 10 
  });
  
  const queryClient = useQueryClient();

  // Buscar todas as organizações
  const { data: organizacoes = [], isLoading } = useQuery({
    queryKey: ['todas-organizacoes'],
    queryFn: () => base44.entities.Organizacao.list('-created_date'),
  });

  // Mutation para criar nova cozinha
  const createMutation = useMutation({
    mutationFn: async (data) => {
      // 1. Criar a Organização
      const org = await base44.entities.Organizacao.create({
        nome: data.nome,
        razao_social: data.razao_social,
        responsavel_nome: data.responsavel_nome,
        cnpj: data.cnpj,
        endereco: data.endereco,
        dono_email: data.dono_email,
        plano: 'pro',
        status: 'ativo',
        valor_mensal: parseFloat(data.valor_mensal) || 0,
        dia_vencimento: parseInt(data.dia_vencimento) || 10
      });

      // 2. Vincular o dono (cria o acesso dele)
      await base44.entities.MembroEquipe.create({
        organizacao_id: org.id,
        email_usuario: data.dono_email,
        cargo: 'admin',
        status: 'ativo'
      });

      // 3. Vincular o Admin SaaS (eu mesmo) para poder acessar
      if (user?.email && user.email !== data.dono_email) {
         await base44.entities.MembroEquipe.create({
            organizacao_id: org.id,
            email_usuario: user.email,
            cargo: 'admin',
            status: 'ativo'
         });
      }

      return org;
    },
    onSuccess: () => {
    queryClient.invalidateQueries(['todas-organizacoes']);
    setModalOpen(false);
    setNovaOrg({ 
      nome: "", 
      razao_social: "",
      responsavel_nome: "",
      cnpj: "",
      endereco: "",
      dono_email: "", 
      valor_mensal: "", 
      dia_vencimento: 10 
    });
    toast.success("Cozinha criada e acesso liberado para o email!");
    },
    onError: (err) => {
      console.error(err);
      toast.error("Erro ao criar cozinha.");
    }
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!novaOrg.nome || !novaOrg.dono_email) return;
    createMutation.mutate(novaOrg);
  };

  const updateStatusMutation = useMutation({
    mutationFn: ({ id, status }) => base44.entities.Organizacao.update(id, { status }),
    onSuccess: () => {
      queryClient.invalidateQueries(['todas-organizacoes']);
      toast.success("Status atualizado com sucesso!");
    },
    onError: () => toast.error("Erro ao atualizar status.")
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Organizacao.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries(['todas-organizacoes']);
      toast.success("Cozinha excluída permanentemente.");
    },
    onError: () => toast.error("Erro ao excluir cozinha.")
  });

  const handleToggleStatus = (org) => {
    const newStatus = org.status === 'ativo' ? 'suspenso' : 'ativo';
    updateStatusMutation.mutate({ id: org.id, status: newStatus });
  };

  const handleDelete = (org) => {
    if (window.confirm(`Tem certeza que deseja EXCLUIR PERMANENTEMENTE a cozinha "${org.nome}"? Essa ação não pode ser desfeita.`)) {
      deleteMutation.mutate(org.id);
    }
  };

  const filteredOrgs = organizacoes.filter(org => 
    org.nome.toLowerCase().includes(busca.toLowerCase()) ||
    org.dono_email.toLowerCase().includes(busca.toLowerCase())
  );

  return (
    <div className="p-4 md:p-8 min-h-screen bg-gray-50">
      <div className="max-w-6xl mx-auto space-y-6">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-2">
              <Building2 className="w-8 h-8 text-indigo-600" />
              Escritório Central
            </h1>
            <p className="text-gray-600 mt-1">Painel do Proprietário: Gerencie todas as suas cozinhas</p>
          </div>

          <Dialog open={modalOpen} onOpenChange={setModalOpen}>
            <DialogTrigger asChild>
              <Button className="bg-indigo-600 hover:bg-indigo-700 text-white gap-2">
                <UserPlus className="w-4 h-4" />
                Nova Cozinha (Cliente)
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Cadastrar Nova Cozinha</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4 mt-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Nome Fantasia</Label>
                    <Input 
                      placeholder="Ex: Burger King Filial 1"
                      value={novaOrg.nome}
                      onChange={e => setNovaOrg({...novaOrg, nome: e.target.value})}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Razão Social / Empresa</Label>
                    <Input 
                      placeholder="Nome da Empresa Ltda"
                      value={novaOrg.razao_social}
                      onChange={e => setNovaOrg({...novaOrg, razao_social: e.target.value})}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Nome do Responsável</Label>
                    <Input 
                      placeholder="Nome Completo"
                      value={novaOrg.responsavel_nome}
                      onChange={e => setNovaOrg({...novaOrg, responsavel_nome: e.target.value})}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Documento (CPF/CNPJ)</Label>
                    <Input 
                      placeholder="00.000.000/0000-00"
                      value={novaOrg.cnpj}
                      onChange={e => setNovaOrg({...novaOrg, cnpj: e.target.value})}
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Endereço Completo</Label>
                  <Input 
                    placeholder="Rua, Número, Bairro, Cidade - UF"
                    value={novaOrg.endereco}
                    onChange={e => setNovaOrg({...novaOrg, endereco: e.target.value})}
                  />
                </div>

                <div className="space-y-2">
                  <Label>Email do Dono (Login)</Label>
                  <Input 
                    type="email"
                    placeholder="cliente@email.com"
                    value={novaOrg.dono_email}
                    onChange={e => setNovaOrg({...novaOrg, dono_email: e.target.value})}
                    required
                  />
                  <p className="text-xs text-gray-500">
                    Este email terá permissão de Admin no sistema.
                    <span className="block text-red-600 font-medium mt-1">
                      ATENÇÃO: Como o app é Privado, o usuário NÃO consegue se cadastrar sozinho. 
                      Você precisa enviar um convite oficial pelo painel da Base44 (Menu Users {'>'} Invite User) para este email.
                    </span>
                  </p>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Mensalidade (R$)</Label>
                    <Input 
                      type="number"
                      placeholder="0.00"
                      value={novaOrg.valor_mensal}
                      onChange={e => setNovaOrg({...novaOrg, valor_mensal: e.target.value})}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Dia Vencimento</Label>
                    <Input 
                      type="number"
                      min="1" max="31"
                      placeholder="10"
                      value={novaOrg.dia_vencimento}
                      onChange={e => setNovaOrg({...novaOrg, dia_vencimento: e.target.value})}
                    />
                  </div>
                </div>
                <DialogFooter>
                  <Button type="button" variant="outline" onClick={() => setModalOpen(false)}>Cancelar</Button>
                  <Button type="submit" disabled={createMutation.isPending} className="bg-indigo-600 text-white">
                    {createMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : "Criar Acesso"}
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
            </Dialog>
            </div>

            <Tabs defaultValue="cozinhas" className="w-full">
              <TabsList className="grid w-full grid-cols-2 max-w-[400px] mb-6">
                <TabsTrigger value="cozinhas" className="gap-2">
                  <Building2 className="w-4 h-4" />
                  Cozinhas
                </TabsTrigger>
                <TabsTrigger value="financeiro" className="gap-2">
                  <Wallet className="w-4 h-4" />
                  Financeiro
                </TabsTrigger>
              </TabsList>

              <TabsContent value="cozinhas" className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card className="bg-indigo-50 border-indigo-100">
            <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-indigo-600 flex items-center gap-2">
              <Building2 className="w-4 h-4" /> Total de Cozinhas
            </CardTitle>
            </CardHeader>
            <CardContent>
            <div className="text-2xl font-bold text-indigo-900">{organizacoes.length}</div>
            </CardContent>
            </Card>
            <Card className="bg-green-50 border-green-100">
            <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-green-600 flex items-center gap-2">
              <LayoutDashboard className="w-4 h-4" /> Cozinhas Ativas
            </CardTitle>
            </CardHeader>
            <CardContent>
            <div className="text-2xl font-bold text-green-900">
              {organizacoes.filter(o => o.status === 'ativo').length}
            </div>
            </CardContent>
            </Card>
            <Card className="bg-amber-50 border-amber-100">
            <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-amber-600 flex items-center gap-2">
              <ShieldAlert className="w-4 h-4" /> Plano Enterprise
            </CardTitle>
            </CardHeader>
            <CardContent>
            <div className="text-2xl font-bold text-amber-900">
              {organizacoes.filter(o => o.plano === 'enterprise').length}
            </div>
            </CardContent>
            </Card>
            </div>

            <Card>
            <CardHeader>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
              <Input 
                placeholder="Buscar cozinha ou email..." 
                className="pl-9"
                value={busca}
                onChange={e => setBusca(e.target.value)}
              />
            </div>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Cozinha</TableHead>
                  <TableHead>Dono / Email</TableHead>
                  <TableHead>Plano</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Criado em</TableHead>
                  <TableHead>Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center py-8">Carregando...</TableCell>
                  </TableRow>
                ) : filteredOrgs.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center py-8 text-gray-500">Nenhuma cozinha encontrada.</TableCell>
                  </TableRow>
                ) : (
                  filteredOrgs.map((org) => (
                    <TableRow key={org.id}>
                      <TableCell className="font-medium">
                        <div className="flex items-center gap-2">
                          <Building2 className="w-4 h-4 text-gray-400" />
                          {org.nome}
                        </div>
                      </TableCell>
                      <TableCell>{org.dono_email}</TableCell>
                      <TableCell>
                        <Badge variant="outline" className="uppercase">{org.plano}</Badge>
                      </TableCell>
                      <TableCell>
                        <Badge className={org.status === 'ativo' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}>
                          {org.status}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-gray-500 text-sm">
                        {org.created_date ? format(new Date(org.created_date), 'dd/MM/yyyy') : '-'}
                      </TableCell>
                      <TableCell>
                         <div className="flex items-center gap-2">
                           {membro?.organizacao_id === org.id ? (
                               <Badge className="bg-indigo-100 text-indigo-700 border-indigo-200">Atual</Badge>
                           ) : (
                               <Button 
                                  size="sm" 
                                  variant="outline" 
                                  className="gap-2"
                                  onClick={() => switchOrganization(org.id)}
                               >
                                  <LogIn className="w-3 h-3" />
                                  Acessar
                               </Button>
                           )}

                           <div className="w-px h-4 bg-gray-200 mx-1"></div>

                           <Button
                              size="icon"
                              variant="ghost"
                              className={org.status === 'ativo' ? "text-amber-600 hover:bg-amber-50 h-8 w-8" : "text-green-600 hover:bg-green-50 h-8 w-8"}
                              onClick={() => handleToggleStatus(org)}
                              title={org.status === 'ativo' ? "Pausar (Inadimplência)" : "Reativar"}
                           >
                              {org.status === 'ativo' ? <PauseCircle className="w-4 h-4" /> : <PlayCircle className="w-4 h-4" />}
                           </Button>

                           <Button
                              size="icon"
                              variant="ghost"
                              className="text-red-600 hover:bg-red-50 h-8 w-8"
                              onClick={() => handleDelete(org)}
                              title="Excluir Permanentemente"
                           >
                              <Trash2 className="w-4 h-4" />
                           </Button>
                         </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
            </CardContent>
            </Card>
            </TabsContent>

            <TabsContent value="financeiro">
            <FinanceiroSaaS />
            </TabsContent>
            </Tabs>
            </div>
            </div>
            );
            }