import React from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { isSuperAdmin } from "@/components/auth/adminControl";
import { toast } from "sonner";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  ArrowDownCircle, 
  AlertOctagon, 
  ClipboardCheck, 
  ThermometerSnowflake, 
  Droplets,
  Download,
  Utensils,
  Pencil,
  X
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { format } from "date-fns";

import FormRetiradaProducao from "../components/estoque/FormRetiradaProducao";
import FormPerdaInsumo from "../components/estoque/FormPerdaInsumo";
import FormTemperatura from "../components/qualidade/FormTemperatura";
import FormManutencao from "../components/qualidade/FormManutencao";
import FormRefeitorio from "../components/estoque/FormRefeitorio";
import FormTransferencia from "../components/estoque/FormTransferencia";
import { useOrganization } from "@/components/auth/OrganizationProvider";

const getStatusTemperatura = (equipamento, temp) => {
  const nome = (equipamento || "").toLowerCase();
  let min = 0, max = 4; // Default: 0°C a +4°C (Apoio, Proteínas, Guarnições, Pizza 1/2, Açougue, Câmara Resfriada)

  // Regras específicas baseadas na lista do usuário
  if (nome.includes('congelad')) { // 02 – Congelada, Câmara Congelada
    min = -18; max = -12;
  } else if (nome.includes('pista fria')) { // 04 – Pista Fria
    min = 2; max = 8;
  } else if (nome.includes('hortifrutti')) { // Câmara de Hortifrutti
    min = 4; max = 8;
  } else if (nome.includes('pizza vertical')) { // 09 – Pizza Vertical
    min = 0; max = 5;
  } else if (nome.includes('confeitaria')) { // 11 – Confeitaria
    min = 2; max = 6;
  }
  
  const fora = temp < min || temp > max;
  return { 
    variant: fora ? "destructive" : "outline",
    className: fora ? "" : "bg-green-50 text-green-700 border-green-200",
    faixa: `${min} a ${max}°C`
  };
};

export default function Movimentacoes() {
  const { organizacao, user } = useOrganization();
  const searchParams = new URLSearchParams(window.location.search);
  const defaultTab = searchParams.get("tab") || "retirada";
  const [activeTab, setActiveTab] = React.useState(defaultTab);
  const [editingTemp, setEditingTemp] = React.useState(null);
  const queryClient = useQueryClient();

  const updateTempMutation = useMutation({
    mutationFn: async (data) => {
      await base44.entities.RegistroTemperatura.update(data.id, {
        temperatura: parseFloat(data.temperatura),
        acao_corretiva: data.acao_corretiva
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['registros-temperatura']);
      toast.success("Temperatura atualizada com sucesso!");
      setEditingTemp(null);
    },
    onError: () => {
      toast.error("Erro ao atualizar temperatura.");
    }
  });

  const handleSaveEdit = () => {
    if (!editingTemp) return;
    updateTempMutation.mutate(editingTemp);
  };

  const handleExport = async () => {
    let data = [];
    let filename = "";
    
    if (!organizacao?.id) {
        alert("Organização não encontrada.");
        return;
    }

    try {
      if (activeTab === "retirada" || activeTab === "perda" || activeTab === "refeitorio" || activeTab === "transferencia") {
        const allData = await base44.entities.HistoricoEstoque.filter({ organizacao_id: organizacao.id }, '-created_date', 1000);
        
        if (activeTab === "refeitorio") {
            data = allData.filter(h => h.motivo === "refeitorio");
        } else if (activeTab === "transferencia") {
            data = allData.filter(h => h.motivo === "ajuste" && (h.observacao || "").includes("Transferência"));
            if (data.length === 0) data = allData;
        } else {
            data = allData;
        }
        filename = `historico_${activeTab}.csv`;
      } else if (activeTab === "temperatura") {
        data = await base44.entities.RegistroTemperatura.filter({ organizacao_id: organizacao.id }, '-created_date', 1000);
        filename = "registros_temperatura.csv";
      } else if (activeTab === "manutencao") {
        data = await base44.entities.RegistroManutencao.filter({ organizacao_id: organizacao.id }, '-created_date', 1000);
        filename = "registros_manutencao.csv";
      }

      if (!data || data.length === 0) {
        alert("Sem dados para exportar.");
        return;
      }

      // Generate CSV
      const headers = Object.keys(data[0]).join(";");
      const rows = data.map(row => 
        Object.values(row).map(value => {
          const stringValue = String(value || "");
          return `"${stringValue.replace(/"/g, '""')}"`;
        }).join(";")
      );

      const csvContent = "\uFEFF" + [headers, ...rows].join("\n");
      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const link = document.createElement("a");
      const url = URL.createObjectURL(blob);
      
      link.setAttribute("href", url);
      link.setAttribute("download", filename);
      link.style.visibility = 'hidden';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (error) {
      console.error("Erro ao exportar:", error);
      alert("Erro ao exportar dados. Tente novamente.");
    }
  };

  // Histórico de movimentações recentes
  const { data: historico = [] } = useQuery({
    queryKey: ['historico-estoque', organizacao?.id],
    queryFn: () => {
        if (!organizacao?.id) return [];
        return base44.entities.HistoricoEstoque.filter({ organizacao_id: organizacao.id }, '-created_date', 20);
    },
    enabled: !!organizacao?.id,
  });

  const { data: temps = [] } = useQuery({
    queryKey: ['registros-temperatura', organizacao?.id],
    queryFn: () => {
        if (!organizacao?.id) return [];
        return base44.entities.RegistroTemperatura.filter({ organizacao_id: organizacao.id }, '-created_date', 20);
    },
    enabled: !!organizacao?.id,
  });

  const { data: manutencoes = [] } = useQuery({
    queryKey: ['registros-manutencao', organizacao?.id],
    queryFn: () => {
        if (!organizacao?.id) return [];
        return base44.entities.RegistroManutencao.filter({ organizacao_id: organizacao.id }, '-created_date', 20);
    },
    enabled: !!organizacao?.id,
  });

  return (
    <div className="p-4 md:p-8 min-h-screen">
      <div className="max-w-6xl mx-auto space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
            <ClipboardCheck className="w-8 h-8 text-orange-600" />
            Registros Operacionais
          </h1>
          <p className="text-gray-600 mt-1">
            Central de registros: Estoque, Temperaturas e Manutenção
          </p>
        </div>

        <div className="flex justify-end">
          <Button onClick={handleExport} variant="outline" className="gap-2">
            <Download className="w-4 h-4" />
            Exportar CSV
          </Button>
        </div>

        <Tabs defaultValue={defaultTab} className="w-full" onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-2 md:grid-cols-5 mb-8 h-auto p-1">
            <TabsTrigger value="retirada" className="gap-2 py-3">
              <ArrowDownCircle className="w-4 h-4" />
              Baixa Produção
            </TabsTrigger>
            <TabsTrigger value="transferencia" className="gap-2 py-3 text-purple-600 data-[state=active]:text-purple-700">
              <ArrowDownCircle className="w-4 h-4 rotate-180" />
              Requisição
            </TabsTrigger>
            <TabsTrigger value="perda" className="gap-2 py-3 text-red-600 data-[state=active]:text-red-700">
              <AlertOctagon className="w-4 h-4" />
              Perda Insumo
            </TabsTrigger>
            <TabsTrigger value="temperatura" className="gap-2 py-3 text-blue-600 data-[state=active]:text-blue-700">
              <ThermometerSnowflake className="w-4 h-4" />
              Temperatura
            </TabsTrigger>
            <TabsTrigger value="manutencao" className="gap-2 py-3 text-green-600 data-[state=active]:text-green-700">
              <Droplets className="w-4 h-4" />
              Fritadeiras/Limpeza
            </TabsTrigger>
            <TabsTrigger value="refeitorio" className="gap-2 py-3 text-indigo-600 data-[state=active]:text-indigo-700">
              <Utensils className="w-4 h-4" />
              Refeitório
            </TabsTrigger>
          </TabsList>

          <div className="grid lg:grid-cols-3 gap-6">
            {/* Coluna Esquerda: Formulários */}
            <div className="lg:col-span-1">
              <TabsContent value="retirada" className="mt-0">
                <Card className="border-orange-200 shadow-md">
                  <CardContent className="p-0">
                    <FormRetiradaProducao />
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="transferencia" className="mt-0">
                <Card className="border-purple-200 shadow-md">
                  <CardContent className="p-0">
                    <FormTransferencia />
                  </CardContent>
                </Card>
              </TabsContent>
              
              <TabsContent value="perda" className="mt-0">
                <Card className="border-red-200 shadow-md">
                  <CardContent className="p-0">
                    <FormPerdaInsumo />
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="temperatura" className="mt-0">
                <Card className="border-blue-200 shadow-md">
                  <CardContent className="p-0">
                    <FormTemperatura />
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="manutencao" className="mt-0">
                <Card className="border-green-200 shadow-md">
                  <CardContent className="p-0">
                    <FormManutencao />
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="refeitorio" className="mt-0">
                <Card className="border-indigo-200 shadow-md">
                  <CardContent className="p-0">
                    <FormRefeitorio />
                  </CardContent>
                </Card>
              </TabsContent>
            </div>

            {/* Coluna Direita: Histórico Unificado */}
            <div className="lg:col-span-2">
              {/* Histórico Estoque (Baixa e Perda) */}
              <TabsContent value="retirada" className="mt-0 h-full">
                <HistoricoEstoqueList historico={historico} />
              </TabsContent>
              <TabsContent value="transferencia" className="mt-0 h-full">
                <HistoricoEstoqueList historico={historico} filterMotivo="transferencia" />
              </TabsContent>
              <TabsContent value="perda" className="mt-0 h-full">
                <HistoricoEstoqueList historico={historico} />
              </TabsContent>
              <TabsContent value="refeitorio" className="mt-0 h-full">
                <HistoricoEstoqueList historico={historico} filterMotivo="refeitorio" />
              </TabsContent>

              {/* Histórico Temperatura */}
              <TabsContent value="temperatura" className="mt-0 h-full">
                <Card className="border-gray-200 shadow-sm h-full">
                  <CardHeader>
                    <CardTitle>Registros de Temperatura</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {temps.length === 0 ? (
                        <p className="text-gray-500 text-center py-8">Nenhum registro encontrado.</p>
                      ) : (
                        temps.map((t) => (
                          <div key={t.id} className="flex items-start justify-between p-4 bg-gray-50 rounded-lg border border-gray-100">
                            <div>
                              <div className="flex items-center gap-2">
                                <h4 className="font-semibold text-gray-900">{t.equipamento}</h4>
                                {(() => {
                                  const status = getStatusTemperatura(t.equipamento, t.temperatura);
                                  return (
                                    <Badge variant={status.variant} className={status.className}>
                                      {t.temperatura}°C
                                    </Badge>
                                  );
                                })()}
                              </div>
                              <p className="text-sm text-gray-500 mt-1">
                                {t.periodo} • Resp: {t.responsavel} • Meta: {getStatusTemperatura(t.equipamento, t.temperatura).faixa}
                              </p>
                              {t.acao_corretiva && (
                                <p className="text-sm text-red-600 mt-2 bg-red-50 p-2 rounded border border-red-100">
                                  ⚠️ {t.acao_corretiva}
                                </p>
                              )}
                            </div>
                            <div className="flex flex-col items-end gap-2">
                              <div className="text-xs text-gray-400 text-right">
                                {format(new Date(t.created_date), "dd/MM HH:mm")}
                              </div>
                              {isSuperAdmin(user?.email) && (
                                <Button 
                                  variant="ghost" 
                                  size="sm" 
                                  className="h-6 w-6 p-0"
                                  onClick={() => setEditingTemp(t)}
                                >
                                  <Pencil className="w-3 h-3 text-gray-500 hover:text-blue-600" />
                                </Button>
                              )}
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Histórico Manutenção */}
              <TabsContent value="manutencao" className="mt-0 h-full">
                <Card className="border-gray-200 shadow-sm h-full">
                  <CardHeader>
                    <CardTitle>Manutenção & Fritadeiras</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {manutencoes.length === 0 ? (
                        <p className="text-gray-500 text-center py-8">Nenhum registro encontrado.</p>
                      ) : (
                        manutencoes.map((m) => (
                          <div key={m.id} className="flex items-start justify-between p-4 bg-gray-50 rounded-lg border border-gray-100">
                            <div>
                              <div className="flex items-center gap-2">
                                <Badge className={
                                  m.tipo === 'Troca de Óleo' ? 'bg-amber-500' : 'bg-green-600'
                                }>
                                  {m.tipo}
                                </Badge>
                                <span className="font-semibold text-gray-900">{m.item}</span>
                              </div>
                              <p className="text-sm text-gray-500 mt-1">
                                Resp: {m.responsavel}
                              </p>
                              {m.observacoes && (
                                <p className="text-sm text-gray-600 mt-2 bg-white p-2 rounded border border-gray-200 italic">
                                  "{m.observacoes}"
                                </p>
                              )}
                            </div>
                            <div className="text-xs text-gray-400 text-right">
                              {format(new Date(m.created_date), "dd/MM/yyyy")}
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </div>
          </div>
        </Tabs>

        {editingTemp && (
          <Dialog open={!!editingTemp} onOpenChange={() => setEditingTemp(null)}>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Editar Temperatura (Admin)</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 py-2">
                <div className="space-y-2">
                  <Label>Equipamento</Label>
                  <Input value={editingTemp.equipamento} disabled className="bg-gray-100" />
                </div>
                <div className="space-y-2">
                  <Label>Temperatura (°C)</Label>
                  <Input 
                    type="number" 
                    step="0.1"
                    value={editingTemp.temperatura} 
                    onChange={(e) => setEditingTemp({...editingTemp, temperatura: e.target.value})}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Ação Corretiva / Observação</Label>
                  <Input 
                    value={editingTemp.acao_corretiva || ''} 
                    onChange={(e) => setEditingTemp({...editingTemp, acao_corretiva: e.target.value})}
                    placeholder="Justificativa da correção..."
                  />
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setEditingTemp(null)}>Cancelar</Button>
                <Button onClick={handleSaveEdit} disabled={updateTempMutation.isPending}>
                  {updateTempMutation.isPending ? 'Salvando...' : 'Salvar Alteração'}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        )}
      </div>
    </div>
  );
}

function HistoricoEstoqueList({ historico, filterMotivo }) {
  const filteredHistorico = filterMotivo 
    ? historico.filter(h => h.motivo === filterMotivo)
    : historico;

  const custoTotal = filteredHistorico.reduce((acc, h) => acc + (h.custo_total || 0), 0);

  return (
    <Card className="border-gray-200 shadow-sm h-full">
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle>Histórico de Estoque</CardTitle>
        {filterMotivo && (
          <Badge className="bg-indigo-100 text-indigo-800">
             Total Lista: R$ {custoTotal.toFixed(2)}
          </Badge>
        )}
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {filteredHistorico.length === 0 ? (
            <p className="text-gray-500 text-center py-8">Nenhuma movimentação recente.</p>
          ) : (
            filteredHistorico.map((h) => (
              <div key={h.id} className="flex items-start justify-between p-4 bg-gray-50 rounded-lg border border-gray-100">
                <div>
                  <div className="flex items-center gap-2">
                    <Badge variant={
                      h.movimento === 'perda' ? 'destructive' : 
                      h.motivo === 'transferencia' ? 'default' :
                      h.movimento === 'entrada' ? 'success' : 
                      'secondary'
                    } className={h.motivo === 'transferencia' ? 'bg-purple-100 text-purple-800 hover:bg-purple-200' : h.movimento === 'entrada' ? 'bg-green-100 text-green-800 hover:bg-green-200' : ''}>
                      {h.motivo === 'transferencia' ? 'TRANSF.' : 
                       h.movimento === 'perda' ? 'PERDA' : 
                       h.movimento === 'entrada' ? 'ENTRADA' : 'SAÍDA'}
                    </Badge>
                    <Badge variant="outline" className="uppercase text-[10px]">
                      {h.tipo_item || 'produto'}
                    </Badge>
                    <span className="font-semibold text-gray-900">{h.item_nome}</span>
                  </div>
                  <div className="mt-2 text-sm">
                    <span className="font-medium text-gray-900">
                      {h.quantidade} un/kg
                    </span>
                    {h.custo_total > 0 && (
                      <span className="ml-2 text-green-700 font-semibold">
                         (R$ {h.custo_total.toFixed(2)})
                      </span>
                    )}
                    <span className="text-gray-500 mx-2">•</span>
                    <span className="text-gray-600 capitalize">{h.motivo}</span>
                    {h.centro_custo_destino && (
                      <Badge variant="outline" className="ml-2 bg-blue-50 text-blue-700 border-blue-200">
                         Destino: {h.centro_custo_destino}
                      </Badge>
                    )}
                    {h.observacao && (
                      <span className="text-gray-500 ml-2 italic">- {h.observacao}</span>
                    )}
                  </div>
                  <p className="text-xs text-gray-500 mt-1">Resp: {h.responsavel}</p>
                </div>
                <div className="text-xs text-gray-400 text-right">
                  {format(new Date(h.data_movimento), "dd/MM HH:mm")}
                </div>
              </div>
            ))
          )}
        </div>
      </CardContent>
    </Card>
  );
}