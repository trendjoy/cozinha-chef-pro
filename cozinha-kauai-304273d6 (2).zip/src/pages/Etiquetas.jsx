import React, { useState, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Printer, Eye, Tag, Share2, FileText, Download } from "lucide-react";
import { format, addDays } from "date-fns";
import BluetoothPrinter from "../components/etiquetas/BluetoothPrinter";
import { useOrganization } from "@/components/auth/OrganizationProvider";

export default function Etiquetas() {
  const { organizacao } = useOrganization();
  const [produto, setProduto] = useState("");
  const [armazenamento, setArmazenamento] = useState("RESFRIADO");
  const [responsavel, setResponsavel] = useState("");
  const [observacoes, setObservacoes] = useState("");
  const [quantidade, setQuantidade] = useState(1);
  const [showPreview, setShowPreview] = useState(false);
  
  const etiquetaRef = useRef(null);

  const { data: preparacoes = [] } = useQuery({
    queryKey: ['preparacoes', organizacao?.id],
    queryFn: () => {
      if (!organizacao?.id) return [];
      return base44.entities.Preparacao.filter({ organizacao_id: organizacao.id });
    },
    enabled: !!organizacao?.id,
  });

  const preparacaoSelecionada = preparacoes.find(p => p.nome === produto);
  
  const hoje = new Date();
  const dataProducao = format(hoje, 'dd/MM/yyyy');
  
  let diasValidade = 3; // Default
  if (preparacaoSelecionada) {
    if (armazenamento === "CONGELADO" && preparacaoSelecionada.validade_congelado_dias) {
      diasValidade = preparacaoSelecionada.validade_congelado_dias;
    } else if (preparacaoSelecionada.validade_dias) {
      diasValidade = preparacaoSelecionada.validade_dias;
    }
  }

  const dataValidade = format(addDays(hoje, diasValidade), 'dd/MM/yyyy');
  
  const gerarLote = () => {
    const dataStr = format(hoje, 'yyyyMMdd');
    const random = Math.floor(Math.random() * 999).toString().padStart(3, '0');
    return `${dataStr}-${random}`;
  };

  const lote = gerarLote();

  const handlePrevisualizar = () => {
    setShowPreview(true);
  };

  const handleImprimir = () => {
    const conteudo = gerarHTMLEtiqueta();
    const blob = new Blob([conteudo], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    window.open(url, '_blank');
  };

  const handleCompartilhar = async () => {
    const conteudo = gerarHTMLEtiqueta();
    const blob = new Blob([conteudo], { type: 'text/html' });
    const file = new File([blob], `etiqueta-${produto || 'produto'}.html`, { type: 'text/html' });
    
    if (navigator.share && navigator.canShare({ files: [file] })) {
      try {
        await navigator.share({
          files: [file],
          title: `Etiqueta - ${produto}`,
        });
      } catch (err) {
        // Fallback: download
        handleDownload();
      }
    } else {
      handleDownload();
    }
  };

  const handleDownload = () => {
    const conteudo = gerarHTMLEtiqueta();
    const blob = new Blob([conteudo], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `etiqueta-${produto || 'produto'}.html`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handlePrintSystem = (isPdf = false) => {
    const conteudo = gerarHTMLEtiqueta();
    
    // Tenta abrir em nova aba para evitar bloqueio de popup
    const printWindow = window.open('', '_blank');
    
    if (!printWindow) {
      alert("Por favor, permita popups para este site para imprimir.");
      return;
    }

    printWindow.document.open();
    printWindow.document.write(conteudo);
    
    // Script robusto para impressão
    printWindow.document.write(`
      <script>
        window.onload = function() {
          setTimeout(() => {
            window.print();
            // Não fecha automaticamente para evitar problemas em alguns navegadores
            // O usuário pode fechar a aba após imprimir/salvar
          }, 500);
        };
      </script>
    `);
    
    printWindow.document.close();
  };

  const gerarHTMLEtiqueta = () => {
    return `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Etiqueta - ${produto}</title>
  <style>
    @page {
      size: 58mm auto;
      margin: 0;
    }
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
    body {
      font-family: Arial, sans-serif;
      width: 58mm;
      padding: 2mm;
      font-size: 9pt;
    }
    .etiqueta {
      border: 1px solid #000;
      padding: 2mm;
      page-break-after: always;
      margin-bottom: 2mm;
    }
    .etiqueta:last-child {
      page-break-after: auto;
    }
    .header {
      text-align: center;
      font-weight: bold;
      font-size: 10pt;
      border-bottom: 1px dashed #000;
      padding-bottom: 2mm;
      margin-bottom: 2mm;
    }
    .produto {
      font-weight: bold;
      font-size: 11pt;
      text-align: center;
      margin: 2mm 0;
      text-transform: uppercase;
    }
    .linha {
      display: flex;
      justify-content: space-between;
      margin: 1mm 0;
      font-size: 8pt;
    }
    .linha-label {
      font-weight: bold;
    }
    .armazenamento {
      text-align: center;
      font-weight: bold;
      font-size: 9pt;
      border: 1px solid #000;
      padding: 1mm;
      margin: 2mm 0;
      background: ${armazenamento === 'CONGELADO' ? '#e0e0e0' : '#fff'};
    }
    .obs {
      font-size: 7pt;
      font-style: italic;
      margin-top: 2mm;
      border-top: 1px dashed #000;
      padding-top: 1mm;
    }
    .lote {
      font-size: 7pt;
      text-align: center;
      margin-top: 2mm;
    }
    @media print {
      body { -webkit-print-color-adjust: exact; }
    }
  </style>
</head>
<body>
${Array(quantidade).fill('').map(() => `
  <div class="etiqueta">
    <div class="header">CozinhaChefPro</div>
    <div class="produto">${produto || 'PRODUTO'}</div>
    <div class="armazenamento">${armazenamento}</div>
    <div class="linha">
      <span class="linha-label">PRODUÇÃO:</span>
      <span>${dataProducao}</span>
    </div>
    <div class="linha">
      <span class="linha-label">VALIDADE:</span>
      <span>${dataValidade}</span>
    </div>
    <div class="linha">
      <span class="linha-label">RESP:</span>
      <span>${responsavel || '-'}</span>
    </div>
    ${observacoes ? `<div class="obs">OBS: ${observacoes}</div>` : ''}
    <div class="lote">LOTE: ${lote}</div>
  </div>
`).join('')}
</body>
</html>`;
  };

  return (
    <div className="p-4 md:p-8 min-h-screen">
      <div className="max-w-4xl mx-auto space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
            <Tag className="w-8 h-8 text-orange-600" />
            CozinhaChefPro — Etiquetas <span className="text-xs bg-orange-100 text-orange-800 px-2 py-1 rounded-full">v1.2</span>
          </h1>
          <p className="text-gray-600 mt-1">Impressão para térmica 58mm</p>
        </div>

        <div className="grid lg:grid-cols-2 gap-6">
          <Card className="border-orange-200/50 shadow-lg">
            <CardHeader className="bg-gradient-to-r from-orange-50 to-amber-50">
              <CardTitle>Dados da Etiqueta</CardTitle>
            </CardHeader>
            <CardContent className="pt-6 space-y-4">
              <div>
                <Label>Produto:</Label>
                <Select value={produto} onValueChange={setProduto}>
                  <SelectTrigger className="border-orange-200">
                    <SelectValue placeholder="Selecione o produto" />
                  </SelectTrigger>
                  <SelectContent>
                    {preparacoes.map(p => (
                      <SelectItem key={p.id} value={p.nome}>{p.nome}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label>Armazenamento:</Label>
                <Select value={armazenamento} onValueChange={setArmazenamento}>
                  <SelectTrigger className="border-orange-200">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="RESFRIADO">RESFRIADO</SelectItem>
                    <SelectItem value="CONGELADO">CONGELADO</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label>Responsável:</Label>
                <Input
                  value={responsavel}
                  onChange={(e) => setResponsavel(e.target.value)}
                  placeholder="Nome do responsável"
                  className="border-orange-200 focus:border-orange-400"
                />
              </div>

              <div>
                <Label>Observações (opcional):</Label>
                <Input
                  value={observacoes}
                  onChange={(e) => setObservacoes(e.target.value)}
                  placeholder="Ex: Sem glúten"
                  className="border-orange-200 focus:border-orange-400"
                />
              </div>

              <div>
                <Label>Quantidade de etiquetas:</Label>
                <Input
                  type="number"
                  min="1"
                  max="50"
                  value={quantidade}
                  onChange={(e) => setQuantidade(parseInt(e.target.value) || 1)}
                  className="border-orange-200 focus:border-orange-400 w-24"
                />
              </div>

              <div className="grid grid-cols-1 gap-4 pt-4">
                <Button
                  size="lg"
                  onClick={() => handlePrintSystem(true)}
                  disabled={!produto}
                  className="w-full h-14 text-lg gap-3 bg-red-600 hover:bg-red-700 text-white shadow-md"
                >
                  <FileText className="w-6 h-6" />
                  BAIXAR PDF / IMPRIMIR
                </Button>
                
                <div className="bg-yellow-50 p-3 rounded-lg border border-yellow-100 text-xs text-yellow-800 text-center">
                  <span className="font-bold block mb-1">⚠️ Instrução Importante:</span>
                  Ao clicar acima, a janela de impressão abrirá. <br/>
                  Altere o "Destino" ou "Impressora" para <strong>"Salvar como PDF"</strong>.
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <Button
                    variant="outline"
                    onClick={handleDownload}
                    disabled={!produto}
                    className="w-full gap-2"
                  >
                    <Download className="w-4 h-4" />
                    Baixar HTML
                  </Button>

                  <Button
                    variant="outline"
                    onClick={handleCompartilhar}
                    disabled={!produto}
                    className="w-full gap-2"
                  >
                    <Share2 className="w-4 h-4" />
                    Compartilhar
                  </Button>
                </div>
                
                <div className="pt-4 border-t border-orange-100">
                    <BluetoothPrinter 
                        data={{
                            produto,
                            armazenamento,
                            dataProducao,
                            dataValidade,
                            responsavel,
                            observacoes,
                            lote
                        }}
                        quantidade={quantidade}
                    />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-orange-200/50 shadow-lg">
            <CardHeader className="bg-gradient-to-r from-orange-50 to-amber-50">
              <CardTitle className="flex items-center gap-2">
                <Eye className="w-5 h-5 text-orange-600" />
                Pré-visualização
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-6">
              <div className="flex justify-center">
                <div 
                  ref={etiquetaRef}
                  className="bg-white border-2 border-gray-800 p-3 font-mono text-xs"
                  style={{ width: '58mm', minHeight: '80mm' }}
                >
                  <div className="text-center font-bold border-b border-dashed border-gray-800 pb-2 mb-2">
                    CozinhaChefPro
                  </div>
                  
                  <div className="text-center font-bold text-sm uppercase my-2">
                    {produto || 'SELECIONE UM PRODUTO'}
                  </div>
                  
                  <div 
                    className={`text-center font-bold border border-gray-800 py-1 my-2 ${
                      armazenamento === 'CONGELADO' ? 'bg-gray-200' : 'bg-white'
                    }`}
                  >
                    {armazenamento}
                  </div>
                  
                  <div className="flex justify-between my-1">
                    <span className="font-bold">PRODUÇÃO:</span>
                    <span>{dataProducao}</span>
                  </div>
                  
                  <div className="flex justify-between my-1">
                    <span className="font-bold">VALIDADE:</span>
                    <span>{dataValidade}</span>
                  </div>
                  
                  <div className="flex justify-between my-1">
                    <span className="font-bold">RESP:</span>
                    <span>{responsavel || '-'}</span>
                  </div>
                  
                  {observacoes && (
                    <div className="border-t border-dashed border-gray-800 pt-1 mt-2 italic text-[10px]">
                      OBS: {observacoes}
                    </div>
                  )}
                  
                  <div className="text-center text-[10px] mt-2 pt-1 border-t border-gray-300">
                    LOTE: {lote}
                  </div>
                </div>
              </div>
              
              {quantidade > 1 && (
                <p className="text-center text-sm text-gray-500 mt-4">
                  Serão impressas {quantidade} etiquetas
                </p>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}