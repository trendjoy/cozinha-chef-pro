import React from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { 
  ChefHat, 
  Globe, 
  MessageCircle, 
  Instagram, 
  Facebook, 
  Linkedin, 
  Youtube,
  ArrowRight,
  Sparkles
} from "lucide-react";
import { motion } from "framer-motion";

export default function LinksBio() {
  const links = [
    {
      title: "Testar Grátis (7 dias)",
      url: createPageUrl("SetupOrganizacao"),
      icon: Sparkles,
      variant: "primary", // destaque
      description: "Comece a controlar sua cozinha agora"
    },
    {
      title: "Site Oficial",
      url: "/", // Landing Page
      icon: Globe,
      variant: "outline",
      description: "Conheça todas as funcionalidades"
    },
    {
      title: "Falar no WhatsApp",
      url: "https://wa.me/5511999999999", // Substituir pelo número real
      icon: MessageCircle,
      variant: "outline",
      description: "Tire dúvidas com nosso time"
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-amber-50 to-orange-100 flex flex-col items-center py-12 px-4">
      
      {/* Profile Header */}
      <motion.div 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center mb-8"
      >
        <div className="w-32 h-32 bg-white rounded-full flex items-center justify-center shadow-xl mx-auto mb-4 border-4 border-white overflow-hidden">
          <img 
            src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/690b33fa7c04b9c3304273d6/4f330ba3b_Capturadetela2025-12-02224105.png" 
            alt="Logo CozinhaChefPro" 
            className="w-full h-full object-cover object-left"
          />
        </div>
        <h1 className="text-2xl font-bold text-gray-900 flex items-center justify-center gap-2">
          Cozinha<span className="text-orange-600">ChefPro</span>
          <div className="bg-blue-500 rounded-full p-0.5">
            <svg className="w-3 h-3 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="3">
              <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
            </svg>
          </div>
        </h1>
        <p className="text-gray-600 mt-2 text-sm max-w-xs mx-auto">
          Sistema de gestão feito por Chef para Chefs. Controle de estoque, CMV e ficha técnica.
        </p>
      </motion.div>

      {/* Links Section */}
      <div className="w-full max-w-md space-y-4">
        {links.map((link, index) => (
          <motion.a
            key={index}
            href={link.url.startsWith("http") ? link.url : link.url}
            target={link.url.startsWith("http") ? "_blank" : "_self"}
            rel="noopener noreferrer"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.1 }}
            className="block group"
          >
            <div className={`
              relative overflow-hidden rounded-xl p-4 flex items-center gap-4 transition-all duration-300
              ${link.variant === 'primary' 
                ? 'bg-gradient-to-r from-orange-600 to-red-600 text-white shadow-lg shadow-orange-200 hover:shadow-orange-300 hover:scale-[1.02]' 
                : 'bg-white text-gray-800 hover:bg-orange-50 border border-gray-200 shadow-sm hover:border-orange-200 hover:scale-[1.02]'}
            `}>
              <div className={`
                p-2 rounded-lg flex-shrink-0
                ${link.variant === 'primary' ? 'bg-white/20' : 'bg-orange-100 text-orange-600'}
              `}>
                <link.icon className="w-6 h-6" />
              </div>
              
              <div className="flex-1 text-left">
                <h3 className="font-bold text-lg leading-tight">{link.title}</h3>
                {link.description && (
                  <p className={`text-xs mt-0.5 ${link.variant === 'primary' ? 'text-orange-100' : 'text-gray-500'}`}>
                    {link.description}
                  </p>
                )}
              </div>

              <div className={`
                opacity-0 group-hover:opacity-100 transition-opacity
                ${link.variant === 'primary' ? 'text-white' : 'text-orange-500'}
              `}>
                <ArrowRight className="w-5 h-5" />
              </div>
            </div>
          </motion.a>
        ))}
      </div>

      {/* Social Footer */}
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.5 }}
        className="mt-12 flex gap-6"
      >
        {[
            { icon: Instagram, href: "https://instagram.com/cozinhachefpro" },
            { icon: Facebook, href: "https://facebook.com" },
            { icon: Linkedin, href: "https://linkedin.com" },
            { icon: Youtube, href: "https://youtube.com" }
        ].map((social, i) => (
            <a 
                key={i}
                href={social.href}
                target="_blank" 
                rel="noopener noreferrer"
                className="p-2 rounded-full bg-white text-gray-400 hover:text-orange-600 hover:bg-orange-50 shadow-sm transition-all hover:-translate-y-1"
            >
                <social.icon className="w-6 h-6" />
            </a>
        ))}
      </motion.div>

      <div className="mt-8 text-center">
        <p className="text-xs text-gray-400 font-medium">© 2025 CozinhaChefPro</p>
      </div>

    </div>
  );
}