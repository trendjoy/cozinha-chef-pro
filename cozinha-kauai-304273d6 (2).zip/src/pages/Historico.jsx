import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { History, Search, Download, Calendar, Filter } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { format } from "date-fns";
import { useOrganization } from "@/components/auth/OrganizationProvider";

export default function Historico() {
  const [busca, setBusca] = useState("");
  const [filtroData, setFiltroData] = useState("all");
  const { organizacao } = useOrganization();

  const { data: producoes = [], isLoading } = useQuery({
    queryKey: ['producoes', organizacao?.id],
    queryFn: () => {
      if (!organizacao?.id) return [];
      return base44.entities.Producao.filter({ organizacao_id: organizacao.id }, '-created_date');
    },
    enabled: !!organizacao?.id,
  });

  const producoesFiltradas = producoes.filter(p => {
    const matchBusca = 
      p.preparacao_nome?.toLowerCase().includes(busca.toLowerCase()) ||
      p.lote?.toLowerCase().includes(busca.toLowerCase()) ||
      p.responsavel?.toLowerCase().includes(busca.toLowerCase());

    let matchData = true;
    if (filtroData !== "all") {
      const hoje = new Date();
      const dataProducao = new Date(p.data_producao);
      
      if (filtroData === "hoje") {
        matchData = format(dataProducao, 'yyyy-MM-dd') === format(hoje, 'yyyy-MM-dd');
      } else if (filtroData === "semana") {
        const semanaAtras = new Date();
        semanaAtras.setDate(semanaAtras.getDate() - 7);
        matchData = dataProducao >= semanaAtras;
      } else if (filtroData === "mes") {
        matchData = dataProducao.getMonth() === hoje.getMonth() && 
                    dataProducao.getFullYear() === hoje.getFullYear();
      }
    }

    return matchBusca && matchData;
  });

  const handleExportCSV = () => {
    const headers = ['Data', 'Preparação', 'Quantidade', 'Validade', 'Lote', 'Responsável', 'Praça'];
    const rows = producoesFiltradas.map(p => [
      p.data_producao,
      p.preparacao_nome,
      `${p.quantidade_produzida} ${p.unidade}`,
      p.data_validade || 'N/A',
      p.lote,
      p.responsavel,
      p.praca
    ]);

    const csv = [
      headers.join(','),
      ...rows.map(row => row.map(cell => `"${cell}"`).join(','))
    ].join('\n');

    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `historico-producao-${format(new Date(), 'yyyy-MM-dd')}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="p-4 md:p-8 min-h-screen">
      <div className="max-w-7xl mx-auto space-y-6">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
              <History className="w-8 h-8 text-orange-600" />
              Histórico de Produção
            </h1>
            <p className="text-gray-600 mt-1">Consulte todas as produções registradas</p>
          </div>
          <Button
            onClick={handleExportCSV}
            disabled={producoesFiltradas.length === 0}
            className="gap-2 bg-gradient-to-r from-orange-500 to-amber-600 hover:from-orange-600 hover:to-amber-700"
          >
            <Download className="w-4 h-4" />
            Exportar CSV
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Card className="border-orange-200/50 shadow-lg">
            <CardContent className="p-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                <Input
                  placeholder="Buscar por preparação, lote ou responsável..."
                  value={busca}
                  onChange={(e) => setBusca(e.target.value)}
                  className="pl-10 border-orange-200 focus:border-orange-400"
                />
              </div>
            </CardContent>
          </Card>

          <Card className="border-orange-200/50 shadow-lg">
            <CardContent className="p-4">
              <div className="flex items-center gap-2">
                <Calendar className="w-5 h-5 text-orange-600" />
                <Select value={filtroData} onValueChange={setFiltroData}>
                  <SelectTrigger className="border-orange-200">
                    <SelectValue placeholder="Período" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos os períodos</SelectItem>
                    <SelectItem value="hoje">Hoje</SelectItem>
                    <SelectItem value="semana">Última semana</SelectItem>
                    <SelectItem value="mes">Este mês</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>
        </div>

        <Card className="border-orange-200/50 shadow-lg">
          <CardHeader className="bg-gradient-to-r from-orange-50 to-amber-50">
            <CardTitle>
              {producoesFiltradas.length} produç{producoesFiltradas.length === 1 ? 'ão' : 'ões'} encontrada{producoesFiltradas.length === 1 ? '' : 's'}
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            {producoesFiltradas.length === 0 ? (
              <div className="p-12 text-center">
                <Filter className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <p className="text-lg font-medium text-gray-900">
                  Nenhuma produção encontrada
                </p>
                <p className="text-gray-500 mt-1">
                  Tente ajustar os filtros de busca
                </p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-orange-50">
                      <TableHead>Data</TableHead>
                      <TableHead>Preparação</TableHead>
                      <TableHead>Quantidade</TableHead>
                      <TableHead>Validade</TableHead>
                      <TableHead>Lote</TableHead>
                      <TableHead>Responsável</TableHead>
                      <TableHead>Praça</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {producoesFiltradas.map((prod) => (
                      <TableRow key={prod.id} className="hover:bg-orange-50/50">
                        <TableCell className="font-medium">
                          {format(new Date(prod.data_producao), 'dd/MM/yyyy')}
                        </TableCell>
                        <TableCell className="font-semibold text-gray-900">
                          {prod.preparacao_nome}
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                            {prod.quantidade_produzida} {prod.unidade}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          {prod.data_validade 
                            ? format(new Date(prod.data_validade), 'dd/MM/yyyy')
                            : '-'
                          }
                        </TableCell>
                        <TableCell>
                          <code className="text-xs bg-gray-100 px-2 py-1 rounded">
                            {prod.lote}
                          </code>
                        </TableCell>
                        <TableCell>{prod.responsavel}</TableCell>
                        <TableCell>
                          <Badge variant="outline" className="bg-purple-50 text-purple-700 border-purple-200">
                            {prod.praca}
                          </Badge>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}