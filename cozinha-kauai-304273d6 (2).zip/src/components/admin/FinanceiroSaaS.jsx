import React, { useState, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { 
  DollarSign, 
  TrendingUp, 
  AlertCircle, 
  Calendar, 
  CheckCircle2, 
  Search, 
  Plus, 
  FileText,
  Download,
  Filter
} from "lucide-react";
import { format, parseISO, isBefore, startOfMonth, endOfMonth, isSameMonth } from "date-fns";
import { toast } from "sonner";

export default function FinanceiroSaaS() {
  const [busca, setBusca] = useState("");
  const [mesFiltro, setMesFiltro] = useState(new Date().toISOString().slice(0, 7)); // YYYY-MM
  const [statusFiltro, setStatusFiltro] = useState("todos");
  const [modalFaturaOpen, setModalFaturaOpen] = useState(false);
  const [novaFatura, setNovaFatura] = useState({
    organizacao_id: "",
    valor: "",
    data_vencimento: format(new Date(), "yyyy-MM-dd"),
    descricao: ""
  });

  const queryClient = useQueryClient();

  // Buscas
  const { data: faturas = [], isLoading: loadingFaturas } = useQuery({
    queryKey: ['faturas'],
    queryFn: () => base44.entities.Fatura.list('-data_vencimento', 1000),
  });

  const { data: organizacoes = [] } = useQuery({
    queryKey: ['todas-organizacoes'],
    queryFn: () => base44.entities.Organizacao.list('nome'),
  });

  // Mutations
  const createFaturaMutation = useMutation({
    mutationFn: async (data) => {
      const org = organizacoes.find(o => o.id === data.organizacao_id);
      await base44.entities.Fatura.create({
        ...data,
        nome_organizacao: org?.nome || "Desconhecido",
        valor: parseFloat(data.valor),
        status: "pendente"
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['faturas']);
      setModalFaturaOpen(false);
      setNovaFatura({ ...novaFatura, valor: "", descricao: "" });
      toast.success("Fatura gerada com sucesso!");
    }
  });

  const updateStatusMutation = useMutation({
    mutationFn: async ({ id, status, data_pagamento }) => {
      await base44.entities.Fatura.update(id, { 
        status, 
        data_pagamento: data_pagamento || null 
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['faturas']);
      toast.success("Status atualizado!");
    }
  });

  // Gerar em Lote (Mensalidade)
  const gerarMensalidadesMutation = useMutation({
    mutationFn: async () => {
      const ativos = organizacoes.filter(o => o.status === 'ativo' && o.valor_mensal > 0);
      const hoje = new Date();
      const mesAno = format(hoje, 'MM/yyyy');
      
      const promises = ativos.map(org => {
        // Verifica se já existe fatura para este mês (simplificado)
        const jaExiste = faturas.some(f => 
          f.organizacao_id === org.id && 
          f.descricao.includes(mesAno)
        );

        if (jaExiste) return Promise.resolve();

        // Calcula vencimento
        const diaVenc = org.dia_vencimento || 10;
        let dataVenc = new Date(hoje.getFullYear(), hoje.getMonth(), diaVenc);
        if (isBefore(dataVenc, hoje)) {
            // Se o dia já passou, joga pro próximo mês ou mantém (regra de negócio)
            // Vamos manter no mês corrente para emissão
        }

        return base44.entities.Fatura.create({
          organizacao_id: org.id,
          nome_organizacao: org.nome,
          valor: org.valor_mensal,
          data_vencimento: format(dataVenc, 'yyyy-MM-dd'),
          descricao: `Mensalidade ${mesAno}`,
          status: "pendente"
        });
      });

      await Promise.all(promises);
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['faturas']);
      toast.success("Mensalidades geradas para cozinhas ativas!");
    }
  });

  // Cálculos e Filtros
  const filteredFaturas = useMemo(() => {
    return faturas.filter(f => {
      const matchBusca = (f.nome_organizacao || "").toLowerCase().includes(busca.toLowerCase());
      const matchStatus = statusFiltro === "todos" || f.status === statusFiltro;
      const matchMes = f.data_vencimento?.startsWith(mesFiltro);
      return matchBusca && matchStatus && matchMes;
    });
  }, [faturas, busca, statusFiltro, mesFiltro]);

  const stats = useMemo(() => {
    const currentMonthFaturas = faturas.filter(f => f.data_vencimento?.startsWith(mesFiltro));
    
    const previsto = currentMonthFaturas.reduce((acc, f) => acc + (f.status !== 'cancelado' ? f.valor : 0), 0);
    const realizado = currentMonthFaturas.reduce((acc, f) => acc + (f.status === 'pago' ? f.valor : 0), 0);
    const vencido = faturas.filter(f => f.status === 'atrasado' || (f.status === 'pendente' && isBefore(new Date(f.data_vencimento), new Date()))).reduce((acc, f) => acc + f.valor, 0);
    const inadimplentes = new Set(faturas.filter(f => f.status === 'atrasado').map(f => f.organizacao_id)).size;

    return { previsto, realizado, vencido, inadimplentes };
  }, [faturas, mesFiltro]);

  const handleStatusChange = (id, novoStatus) => {
    const dataPagamento = novoStatus === 'pago' ? new Date().toISOString().split('T')[0] : null;
    updateStatusMutation.mutate({ id, status: novoStatus, data_pagamento: dataPagamento });
  };

  return (
    <div className="space-y-6">
      {/* Cards de Resumo */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-white border-l-4 border-blue-500 shadow-sm">
          <CardContent className="p-4">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-sm font-medium text-gray-500">Receita Prevista ({mesFiltro})</p>
                <h3 className="text-2xl font-bold text-gray-900 mt-1">R$ {stats.previsto.toFixed(2)}</h3>
              </div>
              <div className="p-2 bg-blue-50 rounded-lg">
                <Calendar className="w-5 h-5 text-blue-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-white border-l-4 border-green-500 shadow-sm">
          <CardContent className="p-4">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-sm font-medium text-gray-500">Receita Realizada</p>
                <h3 className="text-2xl font-bold text-green-700 mt-1">R$ {stats.realizado.toFixed(2)}</h3>
              </div>
              <div className="p-2 bg-green-50 rounded-lg">
                <DollarSign className="w-5 h-5 text-green-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-white border-l-4 border-red-500 shadow-sm">
          <CardContent className="p-4">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-sm font-medium text-gray-500">Total Vencido (Geral)</p>
                <h3 className="text-2xl font-bold text-red-600 mt-1">R$ {stats.vencido.toFixed(2)}</h3>
              </div>
              <div className="p-2 bg-red-50 rounded-lg">
                <AlertCircle className="w-5 h-5 text-red-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-white border-l-4 border-orange-500 shadow-sm">
          <CardContent className="p-4">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-sm font-medium text-gray-500">Clientes Inadimplentes</p>
                <h3 className="text-2xl font-bold text-orange-600 mt-1">{stats.inadimplentes}</h3>
              </div>
              <div className="p-2 bg-orange-50 rounded-lg">
                <TrendingUp className="w-5 h-5 text-orange-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filtros e Ações */}
      <div className="flex flex-col md:flex-row gap-4 items-center justify-between bg-white p-4 rounded-lg border shadow-sm">
        <div className="flex gap-2 items-center w-full md:w-auto">
          <div className="relative w-full md:w-64">
            <Search className="absolute left-2 top-2.5 h-4 w-4 text-gray-400" />
            <Input 
              placeholder="Buscar cliente..." 
              value={busca}
              onChange={(e) => setBusca(e.target.value)}
              className="pl-8"
            />
          </div>
          <Input 
            type="month" 
            value={mesFiltro}
            onChange={(e) => setMesFiltro(e.target.value)}
            className="w-40"
          />
          <Select value={statusFiltro} onValueChange={setStatusFiltro}>
            <SelectTrigger className="w-40">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="todos">Todos</SelectItem>
              <SelectItem value="pendente">Pendente</SelectItem>
              <SelectItem value="pago">Pago</SelectItem>
              <SelectItem value="atrasado">Atrasado</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="flex gap-2 w-full md:w-auto justify-end">
          <Button 
            variant="outline" 
            className="gap-2"
            onClick={() => gerarMensalidadesMutation.mutate()}
            disabled={gerarMensalidadesMutation.isPending}
          >
            <FileText className="w-4 h-4" />
            Gerar Mensalidades (Lote)
          </Button>
          
          <Dialog open={modalFaturaOpen} onOpenChange={setModalFaturaOpen}>
            <DialogTrigger asChild>
              <Button className="bg-indigo-600 hover:bg-indigo-700 text-white gap-2">
                <Plus className="w-4 h-4" />
                Nova Fatura
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Lançar Nova Fatura Avulsa</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 py-2">
                <div className="space-y-2">
                  <Label>Cliente / Cozinha</Label>
                  <Select 
                    value={novaFatura.organizacao_id} 
                    onValueChange={(v) => setNovaFatura({...novaFatura, organizacao_id: v})}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione..." />
                    </SelectTrigger>
                    <SelectContent>
                      {organizacoes.map(org => (
                        <SelectItem key={org.id} value={org.id}>{org.nome}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Valor (R$)</Label>
                    <Input 
                      type="number" 
                      step="0.01"
                      value={novaFatura.valor}
                      onChange={(e) => setNovaFatura({...novaFatura, valor: e.target.value})}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Vencimento</Label>
                    <Input 
                      type="date" 
                      value={novaFatura.data_vencimento}
                      onChange={(e) => setNovaFatura({...novaFatura, data_vencimento: e.target.value})}
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Descrição</Label>
                  <Input 
                    placeholder="Ex: Taxa de Instalação"
                    value={novaFatura.descricao}
                    onChange={(e) => setNovaFatura({...novaFatura, descricao: e.target.value})}
                  />
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setModalFaturaOpen(false)}>Cancelar</Button>
                <Button onClick={() => createFaturaMutation.mutate(novaFatura)} disabled={createFaturaMutation.isPending}>
                  Lançar Fatura
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Tabela de Faturas */}
      <Card className="shadow-sm border-gray-200">
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow className="bg-gray-50">
                <TableHead>Vencimento</TableHead>
                <TableHead>Cliente</TableHead>
                <TableHead>Descrição</TableHead>
                <TableHead>Valor</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Pagamento</TableHead>
                <TableHead className="text-right">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {loadingFaturas ? (
                <TableRow>
                  <TableCell colSpan={7} className="text-center py-8">Carregando financeiro...</TableCell>
                </TableRow>
              ) : filteredFaturas.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={7} className="text-center py-8 text-gray-500">Nenhuma fatura encontrada.</TableCell>
                </TableRow>
              ) : (
                filteredFaturas.map((fatura) => {
                  // Verifica atraso dinamicamente se pendente
                  const isAtrasado = fatura.status === 'pendente' && isBefore(new Date(fatura.data_vencimento), new Date());
                  const statusDisplay = isAtrasado ? 'atrasado' : fatura.status;

                  return (
                    <TableRow key={fatura.id} className="hover:bg-gray-50">
                      <TableCell className="font-medium text-gray-700">
                        {format(parseISO(fatura.data_vencimento), "dd/MM/yyyy")}
                      </TableCell>
                      <TableCell className="font-medium text-indigo-900">
                        {fatura.nome_organizacao}
                      </TableCell>
                      <TableCell className="text-gray-500">{fatura.descricao}</TableCell>
                      <TableCell className="font-bold text-gray-900">
                        R$ {fatura.valor.toFixed(2)}
                      </TableCell>
                      <TableCell>
                        <Badge className={`uppercase ${
                          statusDisplay === 'pago' ? 'bg-green-100 text-green-800 hover:bg-green-200' :
                          statusDisplay === 'atrasado' ? 'bg-red-100 text-red-800 hover:bg-red-200' :
                          statusDisplay === 'cancelado' ? 'bg-gray-100 text-gray-800' :
                          'bg-yellow-100 text-yellow-800 hover:bg-yellow-200'
                        }`}>
                          {statusDisplay}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-sm text-gray-500">
                        {fatura.data_pagamento ? format(parseISO(fatura.data_pagamento), "dd/MM/yyyy") : "-"}
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          {fatura.status !== 'pago' && fatura.status !== 'cancelado' && (
                            <Button 
                              size="sm" 
                              className="bg-green-600 hover:bg-green-700 text-white h-8 text-xs"
                              onClick={() => handleStatusChange(fatura.id, 'pago')}
                            >
                              Receber
                            </Button>
                          )}
                          {fatura.status === 'pago' && (
                            <Button 
                              size="sm" 
                              variant="outline"
                              className="h-8 text-xs text-gray-500"
                              onClick={() => handleStatusChange(fatura.id, 'pendente')}
                            >
                              Desfazer
                            </Button>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  );
                })
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}