import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Save, X, Calculator, Plus, Trash2, Search } from "lucide-react";

const categorias = ["Entradas", "Principais", "Acompanhamentos", "Sobremesas", "Bebidas", "Bases", "Molhos", "Outros"];
const unidades = ["kg", "g", "L", "ml", "un", "porção", "cx", "pct"];
const pracas = ["CozinhaChefPro", "Delivery", "Eventos", "Geral"];

export default function ModalPreparacao({ preparacao, onClose, onSave, saving }) {
  const [activeTab, setActiveTab] = useState("dados");
  const [buscaIngrediente, setBuscaIngrediente] = useState("");
  const [formData, setFormData] = useState({
    nome: "",
    categoria: "Outros",
    praca: "Geral",
    unidade_saida: "porção",
    rendimento: 1,
    custo_unitario: 0,
    preco_venda: 0,
    validade_dias: 3,
    validade_congelado_dias: 30,
    observacoes: "",
    preparo_previo: "",
    modo_preparo: "",
    finalizacao: "",
    ingredientes: [],
    foto: ""
  });

  // Buscar produtos para seleção de ingredientes
  const { data: produtos = [] } = useQuery({
    queryKey: ['produtos-modal'],
    queryFn: () => base44.entities.Produto.list(),
  });

  useEffect(() => {
    if (preparacao) {
      setFormData({
        ...preparacao,
        ingredientes: preparacao.ingredientes || []
      });
    }
  }, [preparacao]);

  // Recalcular custos sempre que ingredientes ou rendimento mudarem
  useEffect(() => {
    const totalCustoIngredientes = formData.ingredientes.reduce((acc, item) => acc + (item.custo_total || 0), 0);
    const rendimento = parseFloat(formData.rendimento) || 1;
    
    // Se tiver ingredientes, o custo unitário é calculado pela soma deles dividido pelo rendimento
    if (formData.ingredientes.length > 0) {
      setFormData(prev => ({
        ...prev,
        custo_unitario: Number((totalCustoIngredientes / rendimento).toFixed(2))
      }));
    }
  }, [formData.ingredientes, formData.rendimento]);

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const addIngrediente = (produto) => {
    // Verifica se já existe
    if (formData.ingredientes.some(i => i.produto_id === produto.id)) {
      alert("Este produto já está na lista de ingredientes.");
      return;
    }

    const novoIngrediente = {
      produto_id: produto.id,
      nome: produto.nome,
      unidade: produto.unidade,
      quantidade: 0,
      fator_correcao: 1,
      fator_coccao: 1,
      custo_unitario_base: produto.custo_unitario || 0, // Guardar custo base para recálculo
      custo_total: 0
    };

    setFormData(prev => ({
      ...prev,
      ingredientes: [...prev.ingredientes, novoIngrediente]
    }));
    setBuscaIngrediente("");
  };

  const updateIngrediente = (index, field, value) => {
    const novosIngredientes = [...formData.ingredientes];
    novosIngredientes[index] = { ...novosIngredientes[index], [field]: value };
    
    // Recalcular custo total deste ingrediente
    const qtd = parseFloat(novosIngredientes[index].quantidade) || 0;
    const custoBase = novosIngredientes[index].custo_unitario_base || 0;
    
    // Custo total = Quantidade * Custo Unitário do Produto
    novosIngredientes[index].custo_total = Number((qtd * custoBase).toFixed(4));

    setFormData(prev => ({ ...prev, ingredientes: novosIngredientes }));
  };

  const removeIngrediente = (index) => {
    setFormData(prev => ({
      ...prev,
      ingredientes: prev.ingredientes.filter((_, i) => i !== index)
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSave(formData);
  };

  const produtosFiltrados = produtos
    .filter(p => p.nome.toLowerCase().includes(buscaIngrediente.toLowerCase()))
    .slice(0, 5);

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[900px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold text-gray-900">
            {preparacao ? `Editar: ${preparacao.nome}` : 'Nova Ficha Técnica'}
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="dados">Dados Gerais & Custo</TabsTrigger>
              <TabsTrigger value="ingredientes">Ingredientes ({formData.ingredientes.length})</TabsTrigger>
              <TabsTrigger value="preparo">Modo de Preparo</TabsTrigger>
            </TabsList>

            {/* TAB 1: DADOS GERAIS */}
            <TabsContent value="dados" className="space-y-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="col-span-2">
                  <Label>Nome da Preparação *</Label>
                  <Input
                    value={formData.nome}
                    onChange={(e) => handleChange('nome', e.target.value)}
                    placeholder="Ex: Risoto de Camarão"
                    required
                    className="border-orange-200"
                  />
                </div>

                <div>
                  <Label>Categoria</Label>
                  <Select value={formData.categoria} onValueChange={(v) => handleChange('categoria', v)}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {categorias.map(cat => <SelectItem key={cat} value={cat}>{cat}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label>Praça</Label>
                  <Select value={formData.praca} onValueChange={(v) => handleChange('praca', v)}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {pracas.map(p => <SelectItem key={p} value={p}>{p}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label>Rendimento (Nº Porções)</Label>
                  <Input
                    type="number"
                    step="0.01"
                    value={formData.rendimento}
                    onChange={(e) => handleChange('rendimento', parseFloat(e.target.value) || 1)}
                    className="border-orange-200"
                  />
                </div>

                <div>
                  <Label>Unidade de Saída</Label>
                  <Select value={formData.unidade_saida} onValueChange={(v) => handleChange('unidade_saida', v)}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {unidades.map(un => <SelectItem key={un} value={un}>{un}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label>URL da Foto</Label>
                  <Input
                    value={formData.foto || ''}
                    onChange={(e) => handleChange('foto', e.target.value)}
                    placeholder="https://..."
                    className="border-orange-200"
                  />
                </div>

                <div>
                  <Label>Preço de Venda (R$)</Label>
                  <Input
                    type="number"
                    step="0.01"
                    value={formData.preco_venda}
                    onChange={(e) => handleChange('preco_venda', parseFloat(e.target.value) || 0)}
                    className="border-orange-200"
                  />
                </div>

                <div className="col-span-2 bg-orange-50 p-4 rounded-lg border border-orange-100 flex justify-between items-center">
                   <div>
                     <Label className="text-orange-800">Custo Unitário (Calculado)</Label>
                     <div className="text-2xl font-bold text-orange-900">R$ {formData.custo_unitario.toFixed(2)}</div>
                   </div>
                   <div>
                     <Label className="text-orange-800">CMV Estimado</Label>
                     <div className="text-xl font-bold text-orange-900">
                       {formData.preco_venda > 0 
                         ? ((formData.custo_unitario / formData.preco_venda) * 100).toFixed(0) + '%' 
                         : '-'}
                     </div>
                   </div>
                </div>

                <div>
                  <Label>Validade Resfriado (dias)</Label>
                  <Input
                    type="number"
                    value={formData.validade_dias}
                    onChange={(e) => handleChange('validade_dias', parseInt(e.target.value) || 3)}
                  />
                </div>

                <div>
                  <Label>Validade Congelado (dias)</Label>
                  <Input
                    type="number"
                    value={formData.validade_congelado_dias}
                    onChange={(e) => handleChange('validade_congelado_dias', parseInt(e.target.value) || 30)}
                  />
                </div>
              </div>
            </TabsContent>

            {/* TAB 2: INGREDIENTES */}
            <TabsContent value="ingredientes" className="space-y-4 py-4">
              <div className="flex flex-col gap-2 bg-gray-50 p-4 rounded-lg border border-gray-200">
                <Label>Adicionar Ingrediente (Busque por nome)</Label>
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <Input
                    value={buscaIngrediente}
                    onChange={(e) => setBuscaIngrediente(e.target.value)}
                    placeholder="Digite para buscar insumos..."
                    className="pl-9"
                  />
                  {buscaIngrediente.length > 1 && (
                    <div className="absolute z-10 w-full bg-white mt-1 border border-gray-200 rounded-md shadow-lg max-h-48 overflow-auto">
                      {produtosFiltrados.length === 0 ? (
                        <div className="p-2 text-sm text-gray-500">Nenhum produto encontrado</div>
                      ) : (
                        produtosFiltrados.map(prod => (
                          <div 
                            key={prod.id}
                            className="p-2 hover:bg-orange-50 cursor-pointer text-sm flex justify-between"
                            onClick={() => addIngrediente(prod)}
                          >
                            <span>{prod.nome}</span>
                            <span className="text-gray-400 text-xs">{prod.unidade}</span>
                          </div>
                        ))
                      )}
                    </div>
                  )}
                </div>
              </div>

              <div className="border rounded-lg overflow-hidden">
                <table className="w-full text-sm text-left">
                  <thead className="bg-gray-100 text-gray-700 font-medium">
                    <tr>
                      <th className="p-2">Ingrediente</th>
                      <th className="p-2 w-24">Qtd Bruta</th>
                      <th className="p-2 w-16">Un</th>
                      <th className="p-2 w-20 text-center" title="Fator de Correção">FC</th>
                      <th className="p-2 w-20 text-center" title="Fator de Cocção">Cocção</th>
                      <th className="p-2 w-24 text-right">Custo Tot</th>
                      <th className="p-2 w-10"></th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100">
                    {formData.ingredientes.length === 0 ? (
                      <tr>
                        <td colSpan="7" className="p-8 text-center text-gray-400 italic">
                          Nenhum ingrediente adicionado.
                        </td>
                      </tr>
                    ) : (
                      formData.ingredientes.map((ing, idx) => (
                        <tr key={idx} className="hover:bg-gray-50">
                          <td className="p-2 font-medium">{ing.nome}</td>
                          <td className="p-2">
                            <Input 
                              type="number" 
                              step="0.001"
                              value={ing.quantidade}
                              onChange={(e) => updateIngrediente(idx, 'quantidade', parseFloat(e.target.value) || 0)}
                              className="h-8 w-20 text-right"
                            />
                          </td>
                          <td className="p-2 text-gray-500">{ing.unidade}</td>
                          <td className="p-2 text-center">
                            <Input 
                              type="number" 
                              step="0.01"
                              value={ing.fator_correcao}
                              onChange={(e) => updateIngrediente(idx, 'fator_correcao', parseFloat(e.target.value) || 1)}
                              className="h-8 w-16 text-center mx-auto"
                            />
                          </td>
                          <td className="p-2 text-center">
                             <Input 
                              type="number" 
                              step="0.01"
                              value={ing.fator_coccao}
                              onChange={(e) => updateIngrediente(idx, 'fator_coccao', parseFloat(e.target.value) || 1)}
                              className="h-8 w-16 text-center mx-auto"
                            />
                          </td>
                          <td className="p-2 text-right font-medium text-gray-700">
                            R$ {ing.custo_total?.toFixed(2)}
                          </td>
                          <td className="p-2 text-center">
                            <Button 
                              variant="ghost" 
                              size="icon" 
                              onClick={() => removeIngrediente(idx)}
                              className="h-8 w-8 text-red-400 hover:text-red-600 hover:bg-red-50"
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                  <tfoot className="bg-gray-50 font-bold">
                    <tr>
                      <td colSpan="5" className="p-2 text-right">Total Custo Ingredientes:</td>
                      <td className="p-2 text-right text-orange-700">
                        R$ {formData.ingredientes.reduce((acc, i) => acc + (i.custo_total || 0), 0).toFixed(2)}
                      </td>
                      <td></td>
                    </tr>
                  </tfoot>
                </table>
              </div>
            </TabsContent>

            {/* TAB 3: MODO DE PREPARO */}
            <TabsContent value="preparo" className="space-y-4 py-4">
              <div>
                <Label className="mb-2 block font-bold text-gray-700">1. Preparo Prévio (Mise en Place)</Label>
                <Textarea
                  value={formData.preparo_previo}
                  onChange={(e) => handleChange('preparo_previo', e.target.value)}
                  placeholder="Descongelamento, cortes iniciais, separação..."
                  className="min-h-[80px] border-orange-200"
                />
              </div>

              <div>
                <Label className="mb-2 block font-bold text-gray-700">2. Modo de Preparo Principal</Label>
                <Textarea
                  value={formData.modo_preparo}
                  onChange={(e) => handleChange('modo_preparo', e.target.value)}
                  placeholder="Passo a passo detalhado da receita..."
                  className="min-h-[200px] border-orange-200"
                />
              </div>

              <div>
                <Label className="mb-2 block font-bold text-gray-700">3. Finalização / Montagem</Label>
                <Textarea
                  value={formData.finalizacao}
                  onChange={(e) => handleChange('finalizacao', e.target.value)}
                  placeholder="Como servir, empratar ou finalizar..."
                  className="min-h-[80px] border-orange-200"
                />
              </div>

              <div>
                <Label className="mb-2 block font-bold text-gray-700">Observações Gerais</Label>
                <Textarea
                  value={formData.observacoes}
                  onChange={(e) => handleChange('observacoes', e.target.value)}
                  placeholder="Dicas extras, substituições, etc."
                  className="min-h-[60px] border-orange-200"
                />
              </div>
            </TabsContent>
          </Tabs>

          <DialogFooter className="gap-2 border-t pt-4">
            <Button type="button" variant="outline" onClick={onClose} disabled={saving}>
              <X className="w-4 h-4 mr-2" />
              Cancelar
            </Button>
            <Button 
              type="submit" 
              disabled={saving}
              className="bg-gradient-to-r from-orange-500 to-amber-600 hover:from-orange-600 hover:to-amber-700"
            >
              <Save className="w-4 h-4 mr-2" />
              {saving ? 'Salvando...' : 'Salvar Ficha Técnica'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}