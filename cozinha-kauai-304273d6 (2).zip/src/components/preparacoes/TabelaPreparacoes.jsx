import React from "react";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Pencil, Trash2 } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

export default function TabelaPreparacoes({ preparacoes, loading, onEdit, onDelete }) {
  if (loading) {
    return (
      <div className="bg-white rounded-xl border border-orange-200/50 shadow-lg overflow-hidden">
        <div className="p-6 space-y-3">
          {Array(6).fill(0).map((_, i) => (
            <Skeleton key={i} className="h-12 w-full" />
          ))}
        </div>
      </div>
    );
  }

  if (preparacoes.length === 0) {
    return (
      <div className="bg-white rounded-xl border border-orange-200/50 shadow-lg p-12 text-center">
        <p className="text-gray-500">Nenhuma preparação encontrada</p>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl border border-orange-200/50 shadow-lg overflow-hidden">
      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow className="bg-gradient-to-r from-orange-50 to-amber-50 border-b border-orange-200">
              <TableHead className="font-semibold">Nome</TableHead>
              <TableHead className="font-semibold">Categoria</TableHead>
              <TableHead className="font-semibold">Praça</TableHead>
              <TableHead className="font-semibold">Rendimento</TableHead>
              <TableHead className="font-semibold">Custo Unit.</TableHead>
              <TableHead className="font-semibold">Validade</TableHead>
              <TableHead className="font-semibold text-right">Ações</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {preparacoes.map((prep) => (
              <TableRow key={prep.id} className="hover:bg-orange-50/50 transition-colors">
                <TableCell className="font-medium">{prep.nome}</TableCell>
                <TableCell>
                  <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                    {prep.categoria}
                  </Badge>
                </TableCell>
                <TableCell>
                  <Badge variant="outline" className="bg-purple-50 text-purple-700 border-purple-200">
                    {prep.praca}
                  </Badge>
                </TableCell>
                <TableCell>
                  {prep.rendimento} {prep.unidade_saida}
                </TableCell>
                <TableCell>
                  R$ {prep.custo_unitario?.toFixed(2) || '0.00'}
                </TableCell>
                <TableCell>
                  {prep.validade_dias} dias
                </TableCell>
                <TableCell className="text-right">
                  <div className="flex justify-end gap-2">
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => onEdit(prep)}
                      className="hover:bg-orange-100"
                    >
                      <Pencil className="w-4 h-4 text-orange-600" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => onDelete(prep.id)}
                      className="hover:bg-red-100"
                    >
                      <Trash2 className="w-4 h-4 text-red-600" />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}