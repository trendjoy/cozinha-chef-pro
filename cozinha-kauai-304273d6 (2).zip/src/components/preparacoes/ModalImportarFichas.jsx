import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Upload, FileUp, CheckCircle2, AlertCircle, Loader2, FileText } from "lucide-react";
import { useOrganization } from "@/components/auth/OrganizationProvider";

export default function ModalImportarFichas({ onClose, onSuccess }) {
  const { organizacao } = useOrganization();
  const [file, setFile] = useState(null);
  const [loading, setLoading] = useState(false);
  const [step, setStep] = useState("upload"); // upload, processing, review, saving
  const [extractedData, setExtractedData] = useState([]);
  const [error, setError] = useState(null);

  const handleFileChange = (e) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
      setError(null);
    }
  };

  const handleProcess = async () => {
    if (!file) return;
    
    setLoading(true);
    setError(null);
    setStep("processing");

    try {
      // 1. Upload File
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      
      // 2. Define Schema for Extraction manually to ensure reliability
      const extractionSchema = {
        type: "object",
        properties: {
          fichas: {
            type: "array",
            items: {
              type: "object",
              properties: {
                nome: { type: "string", description: "Nome da receita" },
                categoria: { type: "string", description: "Categoria (Entradas, Principais, Sobremesas, etc)" },
                rendimento: { type: "number", description: "Quantidade que rende" },
                unidade_saida: { type: "string", description: "Unidade de medida do rendimento (kg, un, porção)" },
                praca: { type: "string", description: "Praça de produção (Geral, Chefia, Delivery)" },
                validade_dias: { type: "number", description: "Validade em dias (resfriado)" },
                preparo_previo: { type: "string", description: "Mise en place / Preparo prévio" },
                modo_preparo: { type: "string", description: "Modo de preparo completo" },
                finalizacao: { type: "string", description: "Instruções de finalização" },
                ingredientes: {
                  type: "array",
                  items: {
                    type: "object",
                    properties: {
                      nome: { type: "string", description: "Nome do ingrediente" },
                      quantidade: { type: "number", description: "Quantidade bruta usada" },
                      unidade: { type: "string", description: "Unidade de medida (kg, g, ml, un)" },
                      fator_correcao: { type: "number", description: "Fator de correção (se houver)" }
                    }
                  }
                }
              },
              required: ["nome"]
            },
            description: "Lista contendo TODAS as fichas técnicas encontradas no arquivo. IMPORTANTE: O arquivo pode ter múltiplas páginas com receitas diferentes. Extraia CADA receita encontrada como um item separado nesta lista. Não pare na primeira página."
          }
        },
        required: ["fichas"]
      };

      // 3. Extract Data using InvokeLLM for better multi-page/tab support
      // ExtractDataFromUploadedFile has strict file type limits, InvokeLLM is more flexible with context
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: "Analise o arquivo fornecido com atenção. Ele contém Fichas Técnicas de receitas. Sua tarefa é extrair TODAS as receitas encontradas no arquivo. \n\nIMPORTANTE:\n1. Se for um Excel com MÚLTIPLAS ABAS, leia todas as abas.\n2. Se for um PDF com MÚLTIPLAS PÁGINAS, leia todas as páginas.\n3. Não pare na primeira receita. Extraia todas.\n4. Para cada receita, extraia nome, ingredientes (com quantidades e unidades), modo de preparo e rendimento.\n5. Se algum valor numérico estiver como texto (ex: '1kg'), converta para numero (1) e unidade ('kg').",
        file_urls: [file_url],
        response_json_schema: extractionSchema
      });

      // InvokeLLM returns the object directly when json_schema is provided
      if (result && result.fichas && Array.isArray(result.fichas)) {
        setExtractedData(result.fichas);
        setStep("review");
      } else {
        throw new Error("A IA não encontrou receitas válidas neste arquivo.");
      }

    } catch (err) {
      console.error(err);
      const isExcel = file?.name?.endsWith('.xlsx') || file?.name?.endsWith('.xls');
      let msg = err.message || "Erro ao processar arquivo.";
      
      if (msg.includes("Unsupported file type") && isExcel) {
         msg = "O formato Excel (.xlsx) teve problemas de leitura. Por favor, SALVE COMO PDF e tente novamente. O PDF garante a leitura de todas as abas.";
      } else if (msg.includes("Unsupported")) {
         msg = "Formato de arquivo não suportado. Tente usar PDF ou Imagem (JPG/PNG).";
      }

      setError(msg);
      setStep("upload");
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    setLoading(true);
    setStep("saving");
    try {
      // Create all preparations
      // Using Promise.all to create them in parallel
      await Promise.all(extractedData.map(ficha => 
        base44.entities.Preparacao.create({ ...ficha, organizacao_id: organizacao.id })
      ));
      
      onSuccess();
      onClose();
    } catch (err) {
      console.error(err);
      setError("Erro ao salvar as fichas no banco de dados.");
      setStep("review");
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FileUp className="w-6 h-6 text-orange-600" />
            Importar Fichas Técnicas (IA)
          </DialogTitle>
          <DialogDescription>
            Envie seus arquivos e a IA irá ler e cadastrar as fichas automaticamente. 
            <span className="block mt-1 font-medium text-orange-700">
              Dica: Para planilhas com várias abas, prefira enviar em PDF (Salvar como PDF) para garantir a leitura de todas.
            </span>
          </DialogDescription>
        </DialogHeader>

        <div className="py-4">
          {step === "upload" && (
            <div className="space-y-4">
              <div className="border-2 border-dashed border-gray-300 rounded-xl p-8 text-center hover:bg-gray-50 transition-colors">
                <Input
                  type="file"
                  accept=".xlsx,.xls,.csv,.pdf,.jpg,.jpeg,.png"
                  onChange={handleFileChange}
                  className="hidden"
                  id="file-upload"
                />
                <Label htmlFor="file-upload" className="cursor-pointer block">
                  <div className="flex flex-col items-center gap-3">
                    <div className="p-3 bg-orange-100 rounded-full text-orange-600">
                      <Upload className="w-6 h-6" />
                    </div>
                    <div className="text-sm font-medium text-gray-900">
                      {file ? file.name : "Clique para selecionar o arquivo"}
                    </div>
                    <div className="text-xs text-gray-500">
                      Excel, PDF ou Imagem (Ficha Digitalizada)
                    </div>
                  </div>
                </Label>
              </div>
              
              {error && (
                <Alert variant="destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertTitle>Erro</AlertTitle>
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}
            </div>
          )}

          {step === "processing" && (
            <div className="flex flex-col items-center justify-center py-8 space-y-4">
              <Loader2 className="w-10 h-10 text-orange-600 animate-spin" />
              <div className="text-center">
                <h3 className="font-semibold text-gray-900">Processando Arquivo...</h3>
                <p className="text-sm text-gray-500">A IA está lendo e estruturando seus dados.</p>
              </div>
            </div>
          )}

          {(step === "review" || step === "saving") && (
            <div className="space-y-4">
              <div className="bg-green-50 border border-green-200 rounded-lg p-4 flex items-start gap-3">
                <CheckCircle2 className="w-5 h-5 text-green-600 mt-0.5" />
                <div>
                  <h3 className="font-semibold text-green-800">Sucesso! Encontramos {extractedData.length} fichas.</h3>
                  <p className="text-sm text-green-700 mt-1">
                    Revise os itens abaixo antes de importar.
                  </p>
                </div>
              </div>

              <div className="max-h-[300px] overflow-y-auto border rounded-lg divide-y">
                {extractedData.map((item, idx) => (
                  <div key={idx} className="p-3 text-sm hover:bg-gray-50 flex justify-between items-center">
                    <div className="flex items-center gap-3">
                      <div className="bg-gray-100 p-2 rounded">
                        <FileText className="w-4 h-4 text-gray-500" />
                      </div>
                      <div>
                        <div className="font-medium text-gray-900">{item.nome || "Sem nome"}</div>
                        <div className="text-xs text-gray-500">
                          {item.ingredientes?.length || 0} ingredientes • {item.rendimento || 0} {item.unidade_saida}
                        </div>
                      </div>
                    </div>
                    <div className="text-xs font-medium bg-gray-100 px-2 py-1 rounded">
                      {item.categoria || "Outros"}
                    </div>
                  </div>
                ))}
              </div>

              {loading && step === "saving" && (
                 <div className="text-center text-sm text-gray-500 flex items-center justify-center gap-2">
                    <Loader2 className="w-4 h-4 animate-spin" /> Salvando fichas no banco...
                 </div>
              )}
            </div>
          )}
        </div>

        <DialogFooter>
          {step === "upload" && (
            <>
              <Button variant="outline" onClick={onClose}>Cancelar</Button>
              <Button 
                onClick={handleProcess} 
                disabled={!file || loading}
                className="bg-orange-600 hover:bg-orange-700 text-white"
              >
                Processar Arquivo
              </Button>
            </>
          )}
          
          {(step === "review" || step === "saving") && (
            <>
              <Button variant="outline" onClick={() => setStep("upload")} disabled={loading}>Voltar</Button>
              <Button 
                onClick={handleSave} 
                disabled={loading}
                className="bg-green-600 hover:bg-green-700 text-white"
              >
                Confirmar Importação
              </Button>
            </>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}