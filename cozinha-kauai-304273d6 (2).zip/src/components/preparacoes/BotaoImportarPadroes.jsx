import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Database, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { useQueryClient } from "@tanstack/react-query";

const DATA_TO_IMPORT = [
  {nome: "BATATA Rosti (Polvo)", categoria: "Entradas", validade_congelado_dias: 30, validade_dias: 3, unidade_saida: "porção"},
  {nome: "Carpaccio Filé Curado", categoria: "Entradas", validade_congelado_dias: 30, validade_dias: 3, unidade_saida: "peça"},
  {nome: "Salmao Ceviche 180g", categoria: "Entradas", validade_congelado_dias: 30, validade_dias: 3, unidade_saida: "porção"},
  {nome: "Pastel de Costelinha", categoria: "Petiscos", validade_congelado_dias: 30, validade_dias: 3, unidade_saida: "porção"},
  {nome: "Isca de Tilapia 320g", categoria: "Petiscos", validade_congelado_dias: 30, validade_dias: 3, unidade_saida: "porção"},
  {nome: "Croqueta de Cupim 6 und", categoria: "Petiscos", validade_congelado_dias: 30, validade_dias: 3, unidade_saida: "porção"},
  {nome: "Buffalo Blue (coxinha )", categoria: "Petiscos", validade_congelado_dias: 30, validade_dias: 3, unidade_saida: "porção"},
  {nome: "File Mignon Empanado 200g", categoria: "Petiscos", validade_congelado_dias: 30, validade_dias: 3, unidade_saida: "porção"},
  {nome: "Frango Empanado 400g", categoria: "Petiscos", validade_congelado_dias: 30, validade_dias: 3, unidade_saida: "porção"},
  {nome: "Berinjela Empanada", categoria: "Petiscos", validade_congelado_dias: 30, validade_dias: 3, unidade_saida: "porção"},
  {nome: "Ravioli de Rabada 6und", categoria: "Massas e Risotos", validade_congelado_dias: 30, validade_dias: 3, unidade_saida: "un"},
  {nome: "Tagliatelle fresco 130g", categoria: "Massas e Risotos", validade_congelado_dias: 30, validade_dias: 3, unidade_saida: "porção"},
  {nome: "Hamburguer 90gr", categoria: "Lanches", validade_congelado_dias: 30, validade_dias: 3, unidade_saida: "porção"},
  {nome: "BATATA FRITA 400G", categoria: "Petiscos", validade_congelado_dias: 30, validade_dias: 3, unidade_saida: "porção"},
  {nome: "BATATA FRITA 130G", categoria: "Petiscos", validade_congelado_dias: 30, validade_dias: 3, unidade_saida: "porção"},
  {nome: "ANCHO 200G", categoria: "Proteinas", validade_congelado_dias: 30, validade_dias: 3, unidade_saida: "porção"},
  {nome: "ANCHO 300G", categoria: "Proteinas", validade_congelado_dias: 30, validade_dias: 3, unidade_saida: "porção"},
  {nome: "PICANHA CURADA 200G", categoria: "Proteinas", validade_congelado_dias: 30, validade_dias: 3, unidade_saida: "porção"},
  {nome: "GALINHA RECHEADA", categoria: "Proteinas", validade_congelado_dias: 30, validade_dias: 3, unidade_saida: "porção"},
  {nome: "FILE MIGNON 200G", categoria: "Proteinas", validade_congelado_dias: 30, validade_dias: 3, unidade_saida: "porção"},
  {nome: "BACALHAU 200G", categoria: "Proteinas", validade_congelado_dias: 30, validade_dias: 3, unidade_saida: "porção"},
  {nome: "ROBALO 200G", categoria: "Proteinas", validade_congelado_dias: 30, validade_dias: 3, unidade_saida: "porção"},
  {nome: "BARRIGA SUINA", categoria: "Proteinas", validade_congelado_dias: 30, validade_dias: 3, unidade_saida: "porção"},
  {nome: "SALMAO 200G", categoria: "Proteinas", validade_congelado_dias: 30, validade_dias: 3, unidade_saida: "porção"},
  {nome: "COSTELA 250G", categoria: "Proteinas", validade_congelado_dias: 30, validade_dias: 3, unidade_saida: "porção"},
  {nome: "PORCHETTA 300G", categoria: "Proteinas", validade_congelado_dias: 30, validade_dias: 3, unidade_saida: "porção"},
  {nome: "CAMARÃO 250G", categoria: "Petiscos", validade_congelado_dias: 30, validade_dias: 3, unidade_saida: "porção"},
  {nome: "POLVO FUSION 130G", categoria: "Entradas", validade_congelado_dias: 30, validade_dias: 3, unidade_saida: "porção"},
  {nome: "PICANHA 300G", categoria: "Proteinas", validade_congelado_dias: 30, validade_dias: 3, unidade_saida: "porção"},
  {nome: "ARROZ ARBOREO", categoria: "Cozinha Quente", validade_dias: 3, unidade_saida: "kg"},
  {nome: "MIX DE COGUMELOS", categoria: "Cozinha Quente", validade_congelado_dias: 30, validade_dias: 3, unidade_saida: "kg"},
  {nome: "QUEIJO PARMESAO", categoria: "Cozinha Quente", validade_dias: 5, unidade_saida: "kg"},
  {nome: "MANTEIGA", categoria: "Cozinha Quente", validade_dias: 5, unidade_saida: "kg"},
  {nome: "PURE DE BANANA DA TERRA", categoria: "Cozinha Quente", validade_dias: 3, unidade_saida: "kg"},
  {nome: "MOLHO DE LIMÃO ROBALO", categoria: "Cozinha Quente", validade_congelado_dias: 30, validade_dias: 3, unidade_saida: "kg"},
  {nome: "FAROFA DE MILHO TOSTADO", categoria: "Cozinha Quente", validade_dias: 3, unidade_saida: "kg"},
  {nome: "PURÊ DE BATATA", categoria: "Cozinha Quente", validade_dias: 3, unidade_saida: "kg"},
  {nome: "PURÊ DE MANDIOQUINHA", categoria: "Cozinha Quente", validade_congelado_dias: 30, validade_dias: 3, unidade_saida: "kg"},
  {nome: "MOLHO TOMATE", categoria: "Cozinha Quente", validade_congelado_dias: 30, validade_dias: 3, unidade_saida: "kg"},
  {nome: "CANJIQUINHA", categoria: "Cozinha Quente", validade_dias: 3, unidade_saida: "kg"},
  {nome: "RAGÚ DE LINGUIÇA", categoria: "Cozinha Quente", validade_congelado_dias: 30, validade_dias: 3, unidade_saida: "kg"},
  {nome: "SUÃ DESFIADA", categoria: "Cozinha Quente", validade_congelado_dias: 30, validade_dias: 3, unidade_saida: "kg"},
  {nome: "ARROZ AGULHA SUÃ", categoria: "Cozinha Quente", validade_dias: 3, unidade_saida: "porção"},
  {nome: "CREME DE MILHO", categoria: "Cozinha Quente", validade_congelado_dias: 30, validade_dias: 3, unidade_saida: "kg"},
  {nome: "ARROZ DE PEQUI", categoria: "Cozinha Quente", validade_dias: 3, unidade_saida: "porção"},
  {nome: "CREME DE PEQUI", categoria: "Cozinha Quente", validade_congelado_dias: 30, validade_dias: 3, unidade_saida: "kg"},
  {nome: "ESPAGUETINHO", categoria: "Cozinha Quente", validade_dias: 3, unidade_saida: "porção"},
  {nome: "MOLHO BECHAMEL", categoria: "Cozinha Quente", validade_dias: 3, unidade_saida: "kg"},
  {nome: "PORÇÃO DE LEGUMES", categoria: "Cozinha Quente", validade_dias: 3, unidade_saida: "porção"},
  {nome: "BROWNIE PORÇÃO", categoria: "Confeitaria", validade_congelado_dias: 30, validade_dias: 5, unidade_saida: "porção"},
  {nome: "SORVETE DE TAPIOCA", categoria: "Confeitaria", validade_congelado_dias: 30, unidade_saida: "kg"},
  {nome: "TORTA BASCA PORÇÃO", categoria: "Confeitaria", validade_dias: 5, unidade_saida: "porção"},
  {nome: "CARAMELO TOFFE", categoria: "Confeitaria", validade_dias: 15, unidade_saida: "kg"},
  {nome: "PANACOTTA DE MANGA UND", categoria: "Confeitaria", validade_congelado_dias: 30, validade_dias: 3, unidade_saida: "porção"},
  {nome: "PETIT GATEAU UND", categoria: "Confeitaria", validade_congelado_dias: 30, validade_dias: 5, unidade_saida: "porção"},
  {nome: "SORVETE DE CUMARU", categoria: "Confeitaria", validade_congelado_dias: 30, unidade_saida: "kg"}
];

export default function BotaoImportarPadroes() {
  const [loading, setLoading] = useState(false);
  const queryClient = useQueryClient();

  const handleImport = async () => {
    if (!confirm(`Deseja importar ${DATA_TO_IMPORT.length} preparações padrão? Isso pode levar alguns instantes.`)) return;
    
    setLoading(true);
    let count = 0;
    try {
      // Importar em batches para não travar
      for (const item of DATA_TO_IMPORT) {
        // Verifica se já existe (pelo nome) para não duplicar
        // Nota: Isso é "caro" em requisições, mas evita duplicidade
        // Para performance, poderíamos pular, mas aqui queremos segurança
        const existe = await base44.entities.Preparacao.list(undefined, 1, { nome: item.nome });
        if (existe.length === 0) {
            await base44.entities.Preparacao.create(item);
            count++;
        }
      }
      
      queryClient.invalidateQueries(['preparacoes']);
      toast.success(`${count} preparações importadas com sucesso!`);
    } catch (error) {
      console.error(error);
      toast.error("Erro ao importar alguns itens.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <Button 
      onClick={handleImport} 
      variant="secondary" 
      disabled={loading}
      className="gap-2"
    >
      {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Database className="w-4 h-4" />}
      {loading ? "Importando..." : "Atualizar Cardápio Padrão"}
    </Button>
  );
}