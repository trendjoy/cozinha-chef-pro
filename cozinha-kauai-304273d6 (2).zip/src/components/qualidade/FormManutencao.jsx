import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { ClipboardCheck, Save } from "lucide-react";
import { toast } from "sonner";
import { useOrganization } from "@/components/auth/OrganizationProvider";

export default function FormManutencao() {
  const { organizacao } = useOrganization();
  const [formData, setFormData] = useState({
    tipo: "Limpeza",
    item: "",
    responsavel: "",
    observacoes: ""
  });

  const queryClient = useQueryClient();

  const mutation = useMutation({
    mutationFn: (data) => base44.entities.RegistroManutencao.create({ ...data, organizacao_id: organizacao.id }),
    onSuccess: () => {
      queryClient.invalidateQueries(['registros-manutencao']);
      toast.success("Registro salvo com sucesso!");
      setFormData(prev => ({ ...prev, observacoes: "", item: "" }));
    },
    onError: () => toast.error("Erro ao salvar registro")
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.tipo || !formData.item || !formData.responsavel) return;
    mutation.mutate(formData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4 p-4 bg-green-50/50 rounded-lg border border-green-100">
      <div className="flex items-center gap-2 text-green-800 mb-2">
        <ClipboardCheck className="w-5 h-5" />
        <h3 className="font-semibold">Novo Registro</h3>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label>Tipo de Registro</Label>
          <Select 
            value={formData.tipo} 
            onValueChange={(v) => setFormData({...formData, tipo: v})}
          >
            <SelectTrigger className="bg-white">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Limpeza">Limpeza</SelectItem>
              <SelectItem value="Troca de Óleo">Troca de Óleo</SelectItem>
              <SelectItem value="Manutenção Geral">Manutenção Geral</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label>Item / Equipamento</Label>
          <Input 
            value={formData.item}
            onChange={(e) => setFormData({...formData, item: e.target.value})}
            className="bg-white"
            placeholder={formData.tipo === "Troca de Óleo" ? "Ex: Fritadeira 1" : "Ex: Coifa"}
            required
          />
        </div>

        <div className="space-y-2 md:col-span-2">
          <Label>Responsável</Label>
          <Input 
            value={formData.responsavel}
            onChange={(e) => setFormData({...formData, responsavel: e.target.value})}
            className="bg-white"
            placeholder="Nome"
            required
          />
        </div>
      </div>

      <div className="space-y-2">
        <Label>Observações</Label>
        <Textarea 
          value={formData.observacoes}
          onChange={(e) => setFormData({...formData, observacoes: e.target.value})}
          className="bg-white h-20"
          placeholder={formData.tipo === "Troca de Óleo" ? "Ex: Óleo estava muito escuro, filtro trocado..." : "Ex: Limpeza profunda realizada..."}
        />
      </div>

      <Button 
        type="submit" 
        disabled={mutation.isPending}
        className="w-full bg-green-600 hover:bg-green-700"
      >
        <Save className="w-4 h-4 mr-2" />
        Salvar Registro
      </Button>
    </form>
  );
}