import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Thermometer, Save } from "lucide-react";
import { toast } from "sonner";
import { useOrganization } from "@/components/auth/OrganizationProvider";

const EQUIPAMENTOS_SUGESTAO = [
  "01 – Apoio Proteínas",
  "02 – Congelada",
  "03 – Proteínas",
  "04 – Pista Fria",
  "05 – Guarnição 1",
  "06 – Guarnição 2",
  "07 – Pizza 1",
  "08 – Pizza 2",
  "09 – Pizza Vertical",
  "10 – Açougue",
  "11 – Confeitaria",
  "Câmara Congelada",
  "Câmara Resfriada",
  "Câmara de Hortifrutti"
];

export default function FormTemperatura() {
  const { organizacao } = useOrganization();
  const [formData, setFormData] = useState({
    equipamento: "",
    temperatura: "",
    periodo: "Abertura",
    responsavel: "",
    acao_corretiva: ""
  });

  const queryClient = useQueryClient();

  const mutation = useMutation({
    mutationFn: (data) => base44.entities.RegistroTemperatura.create({
      ...data,
      organizacao_id: organizacao.id,
      temperatura: parseFloat(data.temperatura)
    }),
    onSuccess: () => {
      queryClient.invalidateQueries(['registros-temperatura']);
      toast.success("Temperatura registrada!");
      setFormData(prev => ({ ...prev, temperatura: "", acao_corretiva: "" }));
    },
    onError: () => toast.error("Erro ao salvar registro")
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.equipamento || !formData.temperatura || !formData.responsavel) return;

    const tempValue = parseFloat(formData.temperatura);
    const isCongelado = ["02 – Congelada", "Câmara Congelada"].includes(formData.equipamento);

    if (isCongelado && tempValue > 0) {
      toast.error("Equipamentos congelados devem ter temperatura negativa!");
      return;
    }

    mutation.mutate(formData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4 p-4 bg-blue-50/50 rounded-lg border border-blue-100">
      <div className="flex items-center gap-2 text-blue-800 mb-2">
        <Thermometer className="w-5 h-5" />
        <h3 className="font-semibold">Nova Aferição</h3>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label>Equipamento</Label>
          <Select 
            value={formData.equipamento} 
            onValueChange={(v) => setFormData({...formData, equipamento: v})}
          >
            <SelectTrigger className="bg-white">
              <SelectValue placeholder="Selecione..." />
            </SelectTrigger>
            <SelectContent>
              {EQUIPAMENTOS_SUGESTAO.map(eq => (
                <SelectItem key={eq} value={eq}>{eq}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label>Temperatura (°C)</Label>
          <Input 
            type="number" 
            step="0.1" 
            value={formData.temperatura}
            onChange={(e) => setFormData({...formData, temperatura: e.target.value})}
            className="bg-white"
            placeholder="Ex: 4.5"
            required
          />
        </div>

        <div className="space-y-2">
          <Label>Período</Label>
          <Select 
            value={formData.periodo} 
            onValueChange={(v) => setFormData({...formData, periodo: v})}
          >
            <SelectTrigger className="bg-white">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Abertura">Abertura</SelectItem>
              <SelectItem value="Turno Manhã">Turno Manhã</SelectItem>
              <SelectItem value="Turno Tarde">Turno Tarde</SelectItem>
              <SelectItem value="Fechamento">Fechamento</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label>Responsável</Label>
          <Input 
            value={formData.responsavel}
            onChange={(e) => setFormData({...formData, responsavel: e.target.value})}
            className="bg-white"
            placeholder="Nome"
            required
          />
        </div>
      </div>

      <div className="space-y-2">
        <Label>Ação Corretiva (Se necessário)</Label>
        <Textarea 
          value={formData.acao_corretiva}
          onChange={(e) => setFormData({...formData, acao_corretiva: e.target.value})}
          className="bg-white h-20"
          placeholder="Ex: Ajustado termostato, porta estava aberta..."
        />
      </div>

      <Button 
        type="submit" 
        disabled={mutation.isPending}
        className="w-full bg-blue-600 hover:bg-blue-700"
      >
        <Save className="w-4 h-4 mr-2" />
        Registrar Temperatura
      </Button>
    </form>
  );
}