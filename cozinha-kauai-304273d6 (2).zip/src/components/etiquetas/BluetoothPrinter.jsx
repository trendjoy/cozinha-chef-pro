import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Bluetooth, Loader2, Printer, RefreshCw, Smartphone } from "lucide-react";
import { toast } from "sonner";

export default function BluetoothPrinter({ data, quantidade = 1 }) {
  const [device, setDevice] = useState(null);
  const [characteristic, setCharacteristic] = useState(null);
  const [isConnecting, setIsConnecting] = useState(false);
  const [isPrinting, setIsPrinting] = useState(false);

  // Gera os comandos ESC/POS
  const generateCommands = () => {
      const ESC = '\x1B';
      const LF = '\x0A';
      let cmds = '';
      
      cmds += ESC + '@'; // Initialize

      for (let i = 0; i < quantidade; i++) {
          cmds += ESC + 'a' + '\x01'; // Center
          cmds += "CozinhaChefPro" + LF;
          cmds += "--------------------------------" + LF;
          
          cmds += ESC + '!' + '\x10'; // Double height
          cmds += ESC + 'E' + '\x01'; // Bold ON
          cmds += data.produto + LF;
          cmds += ESC + 'E' + '\x00'; // Bold OFF
          cmds += ESC + '!' + '\x00'; // Normal
          
          cmds += LF;
          cmds += `[ ${data.armazenamento} ]` + LF;
          cmds += LF;

          cmds += ESC + 'a' + '\x00'; // Left
          cmds += `PRODUCAO: ${data.dataProducao}` + LF;
          cmds += `VALIDADE: ${data.dataValidade}` + LF;
          cmds += `RESP:     ${data.responsavel}` + LF;
          if (data.observacoes) cmds += `OBS:      ${data.observacoes}` + LF;
          cmds += `LOTE:     ${data.lote}` + LF;
          
          cmds += LF + LF + LF;
      }
      return cmds;
  };

  const handleRawBT = () => {
      try {
          const commands = generateCommands();
          // Converte para Base64
          const base64 = btoa(commands);
          // Abre o intent do RawBT
          window.location.href = 'rawbt:base64,' + base64;
      } catch (error) {
          toast.error("Erro ao abrir RawBT");
      }
  };

  const connectToPrinter = async () => {
    try {
      setIsConnecting(true);
      
      // Solicita dispositivo Bluetooth (Filtro genérico para impressoras)
      const device = await navigator.bluetooth.requestDevice({
        filters: [
          { services: ['000018f0-0000-1000-8000-00805f9b34fb'] } // Serviço padrão de impressoras
        ],
        optionalServices: ['000018f0-0000-1000-8000-00805f9b34fb']
      }).catch(err => {
         // Fallback para aceitar todos se o filtro falhar (comum em genéricas)
         return navigator.bluetooth.requestDevice({
            acceptAllDevices: true,
            optionalServices: ['000018f0-0000-1000-8000-00805f9b34fb']
         });
      });

      const server = await device.gatt.connect();
      const service = await server.getPrimaryService('000018f0-0000-1000-8000-00805f9b34fb');
      const char = await service.getCharacteristic('00002af1-0000-1000-8000-00805f9b34fb');

      setDevice(device);
      setCharacteristic(char);
      toast.success(`Conectado a ${device.name}`);
      
      device.addEventListener('gattserverdisconnected', () => {
        setDevice(null);
        setCharacteristic(null);
        toast.error("Impressora desconectada");
      });

    } catch (error) {
      console.error(error);
      toast.error("Erro ao conectar: " + error.message);
    } finally {
      setIsConnecting(false);
    }
  };

  const printLabel = async () => {
    if (!characteristic) {
        toast.error("Impressora não conectada");
        return;
    }

    setIsPrinting(true);
    try {
      const encoder = new TextEncoder();
      const commands = generateCommands();
      const buffer = encoder.encode(commands);
      
      const chunkSize = 100;
      for (let i = 0; i < buffer.length; i += chunkSize) {
        const chunk = buffer.slice(i, i + chunkSize);
        await characteristic.writeValue(chunk);
      }

      toast.success("Enviado para impressão!");

    } catch (error) {
      console.error(error);
      toast.error("Erro ao imprimir: " + error.message);
    } finally {
      setIsPrinting(false);
    }
  };

  return (
    <div className="flex flex-col gap-3">
      <div className="grid grid-cols-2 gap-3">
        {!device ? (
            <Button 
                onClick={connectToPrinter} 
                disabled={isConnecting}
                className="bg-blue-600 hover:bg-blue-700 text-white gap-2 text-xs"
            >
            {isConnecting ? <Loader2 className="w-3 h-3 animate-spin" /> : <Bluetooth className="w-3 h-3" />}
            Conectar Bluetooth
            </Button>
        ) : (
            <div className="flex gap-1">
                <Button 
                    onClick={printLabel} 
                    disabled={isPrinting || !data.produto}
                    className="flex-1 bg-green-600 hover:bg-green-700 text-white gap-2 text-xs"
                >
                {isPrinting ? <Loader2 className="w-3 h-3 animate-spin" /> : <Printer className="w-3 h-3" />}
                Imprimir
                </Button>
                <Button 
                    variant="outline"
                    onClick={() => { setDevice(null); setCharacteristic(null); }}
                    className="px-2"
                    title="Desconectar"
                >
                    <RefreshCw className="w-3 h-3" />
                </Button>
            </div>
        )}

        <Button 
            onClick={handleRawBT}
            variant="outline"
            className="gap-2 border-indigo-200 text-indigo-700 hover:bg-indigo-50 text-xs"
        >
            <Smartphone className="w-3 h-3" />
            Via RawBT (Android)
        </Button>
      </div>
      
      <p className="text-[10px] text-gray-500 text-center px-4">
        <strong>Opção 1:</strong> Conexão direta (Chrome/Edge Desktop & Android).<br/>
        <strong>Opção 2:</strong> Requer app "RawBT" instalado no Android.
      </p>
    </div>
  );
}