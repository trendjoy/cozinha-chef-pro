import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Clock, User } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { format } from "date-fns";

export default function ProducaoRecente({ producoes, loading }) {
  return (
    <Card className="border-orange-200/50 shadow-lg">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Clock className="w-5 h-5 text-orange-600" />
          Produções Recentes
        </CardTitle>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="space-y-3">
            {Array(5).fill(0).map((_, i) => (
              <Skeleton key={i} className="h-20 w-full" />
            ))}
          </div>
        ) : producoes.length === 0 ? (
          <p className="text-center text-gray-500 py-8">
            Nenhuma produção registrada ainda
          </p>
        ) : (
          <div className="space-y-3">
            {producoes.map((prod) => (
              <div 
                key={prod.id} 
                className="p-4 bg-gradient-to-r from-orange-50 to-amber-50 rounded-lg border border-orange-200/50 hover:shadow-md transition-shadow"
              >
                <div className="flex justify-between items-start mb-2">
                  <h4 className="font-semibold text-gray-900">
                    {prod.preparacao_nome}
                  </h4>
                  <Badge variant="secondary" className="bg-orange-100 text-orange-800">
                    {prod.quantidade_produzida} {prod.unidade}
                  </Badge>
                </div>
                <div className="flex items-center gap-4 text-sm text-gray-600">
                  <span className="flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    {prod.data_producao ? format(new Date(prod.data_producao), 'dd/MM/yyyy') : '-'}
                  </span>
                  {prod.responsavel && (
                    <span className="flex items-center gap-1">
                      <User className="w-3 h-3" />
                      {prod.responsavel}
                    </span>
                  )}
                </div>
                {prod.lote && (
                  <p className="text-xs text-gray-500 mt-2">
                    Lote: {prod.lote}
                  </p>
                )}
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}