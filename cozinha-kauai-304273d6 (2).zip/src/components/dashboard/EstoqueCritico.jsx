import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { AlertTriangle } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";

export default function EstoqueCritico({ produtos, loading }) {
  return (
    <Card className="border-red-200 bg-red-50/50 shadow-lg">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-red-800">
          <AlertTriangle className="w-5 h-5" />
          Estoque Crítico
        </CardTitle>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="space-y-3">
            {Array(5).fill(0).map((_, i) => (
              <Skeleton key={i} className="h-16 w-full" />
            ))}
          </div>
        ) : produtos.length === 0 ? (
          <p className="text-center text-green-700 py-6 text-sm">
            ✓ Todos os produtos estão com estoque adequado
          </p>
        ) : (
          <div className="space-y-3">
            {produtos.slice(0, 8).map((produto) => {
              const falta = produto.par_stock - produto.estoque_atual;
              return (
                <div 
                  key={produto.id} 
                  className="flex justify-between items-start p-3 bg-white rounded-lg border border-red-200 hover:shadow-md transition-shadow"
                >
                  <div className="flex-1">
                    <p className="font-medium text-gray-900 text-sm">
                      {produto.nome}
                    </p>
                    <p className="text-xs text-gray-600 mt-1">
                      Estoque: {produto.estoque_atual} {produto.unidade}
                    </p>
                    <p className="text-xs text-red-700 font-medium mt-0.5">
                      Falta: {falta.toFixed(1)} {produto.unidade}
                    </p>
                  </div>
                  <Badge variant="destructive" className="bg-red-600">
                    COMPRAR
                  </Badge>
                </div>
              );
            })}
          </div>
        )}
      </CardContent>
    </Card>
  );
}