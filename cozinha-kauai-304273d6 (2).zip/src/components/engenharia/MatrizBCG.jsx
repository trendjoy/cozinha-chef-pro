import React, { useMemo, useState } from 'react';
import { 
  ScatterChart, 
  Scatter, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  ReferenceLine,
  Cell,
  Label
} from 'recharts';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Info, Star, TrendingDown, TrendingUp, HelpCircle } from "lucide-react";
import {
  Tooltip as UITooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

export default function MatrizBCG({ dados }) {
  // Calcula as médias para traçar as linhas divisórias (Quadrantes)
  const medias = useMemo(() => {
    if (!dados || dados.length === 0) return { popularidade: 0, margem: 0 };
    
    const totalVendas = dados.reduce((acc, item) => acc + item.quantidade_vendida, 0);
    const mediaPop = totalVendas / dados.length; // Média simples de popularidade
    
    // Margem média ponderada
    const totalMargem = dados.reduce((acc, item) => acc + (item.margem_total), 0);
    const mediaMarg = totalMargem / totalVendas; // Margem média por item vendido
    
    return { popularidade: mediaPop, margem: mediaMarg };
  }, [dados]);

  // Função para determinar a classificação e cor
  const getClassificacao = (item) => {
    const altaPop = item.quantidade_vendida >= medias.popularidade;
    const altaMarg = item.margem_unitaria >= medias.margem;

    if (altaPop && altaMarg) return { label: 'Estrela', color: '#22c55e', icon: Star, desc: 'Alta Popularidade, Alta Lucratividade' };
    if (altaPop && !altaMarg) return { label: 'Burro de Carga', color: '#3b82f6', icon: TrendingUp, desc: 'Alta Popularidade, Baixa Lucratividade' };
    if (!altaPop && altaMarg) return { label: 'Quebra-Cabeça', color: '#eab308', icon: HelpCircle, desc: 'Baixa Popularidade, Alta Lucratividade' };
    return { label: 'Cão', color: '#ef4444', icon: TrendingDown, desc: 'Baixa Popularidade, Baixa Lucratividade' };
  };

  if (!dados || dados.length === 0) {
    return (
      <div className="h-[400px] flex items-center justify-center border-2 border-dashed border-gray-200 rounded-lg">
        <p className="text-gray-400">Sem dados suficientes para gerar a matriz.</p>
      </div>
    );
  }

  const dadosFormatados = dados.map(item => ({
    ...item,
    ...getClassificacao(item)
  }));

  const CustomTooltip = ({ active, payload }) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="bg-white p-3 border border-gray-200 shadow-lg rounded-lg max-w-xs">
          <p className="font-bold text-gray-900 mb-1">{data.nome}</p>
          <div className="flex items-center gap-2 mb-2">
            <Badge style={{ backgroundColor: data.color }} className="text-white">
              {data.label}
            </Badge>
          </div>
          <div className="space-y-1 text-xs text-gray-600">
            <p>Vendas: <span className="font-medium text-gray-900">{data.quantidade_vendida} un</span></p>
            <p>Preço Venda: <span className="font-medium text-gray-900">R$ {data.preco_venda.toFixed(2)}</span></p>
            <p>Custo (CMV): <span className="font-medium text-gray-900">R$ {data.custo_unitario.toFixed(2)}</span></p>
            <p>Margem Unit.: <span className="font-medium text-green-600">R$ {data.margem_unitaria.toFixed(2)}</span></p>
          </div>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <Card className="border-l-4 border-green-500 bg-green-50/30">
          <CardHeader className="p-4 pb-2">
            <CardTitle className="text-sm font-medium text-green-700 flex items-center gap-2">
              <Star className="w-4 h-4" /> Estrelas
            </CardTitle>
          </CardHeader>
          <CardContent className="p-4 pt-0">
            <p className="text-xs text-gray-600 mt-1">
              Mantê-los! Alta venda e lucro. Garanta qualidade e estoque.
            </p>
          </CardContent>
        </Card>
        <Card className="border-l-4 border-blue-500 bg-blue-50/30">
          <CardHeader className="p-4 pb-2">
            <CardTitle className="text-sm font-medium text-blue-700 flex items-center gap-2">
              <TrendingUp className="w-4 h-4" /> Burros de Carga
            </CardTitle>
          </CardHeader>
          <CardContent className="p-4 pt-0">
            <p className="text-xs text-gray-600 mt-1">
              Populares mas pouco lucro. Tente aumentar o preço ou reduzir custo.
            </p>
          </CardContent>
        </Card>
        <Card className="border-l-4 border-yellow-500 bg-yellow-50/30">
          <CardHeader className="p-4 pb-2">
            <CardTitle className="text-sm font-medium text-yellow-700 flex items-center gap-2">
              <HelpCircle className="w-4 h-4" /> Quebra-Cabeças
            </CardTitle>
          </CardHeader>
          <CardContent className="p-4 pt-0">
            <p className="text-xs text-gray-600 mt-1">
              Lucrativos mas vendem pouco. Faça promoções ou destaque no menu.
            </p>
          </CardContent>
        </Card>
        <Card className="border-l-4 border-red-500 bg-red-50/30">
          <CardHeader className="p-4 pb-2">
            <CardTitle className="text-sm font-medium text-red-700 flex items-center gap-2">
              <TrendingDown className="w-4 h-4" /> Cães
            </CardTitle>
          </CardHeader>
          <CardContent className="p-4 pt-0">
            <p className="text-xs text-gray-600 mt-1">
              Baixa venda e lucro. Considere remover do cardápio ou reformular.
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="h-[500px] w-full bg-white p-4 rounded-xl border shadow-sm relative">
        <div className="absolute top-4 right-4 z-10 bg-white/90 p-2 rounded border text-xs text-gray-500">
            <div className="flex items-center gap-2 mb-1"><div className="w-3 h-3 rounded-full bg-green-500"></div> Estrela</div>
            <div className="flex items-center gap-2 mb-1"><div className="w-3 h-3 rounded-full bg-blue-500"></div> Burro de Carga</div>
            <div className="flex items-center gap-2 mb-1"><div className="w-3 h-3 rounded-full bg-yellow-500"></div> Quebra-Cabeça</div>
            <div className="flex items-center gap-2"><div className="w-3 h-3 rounded-full bg-red-500"></div> Cão</div>
        </div>

        <ResponsiveContainer width="100%" height="100%">
          <ScatterChart margin={{ top: 20, right: 20, bottom: 40, left: 40 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
            <XAxis 
              type="number" 
              dataKey="quantidade_vendida" 
              name="Popularidade" 
              stroke="#6b7280"
              label={{ value: 'Popularidade (Qtd Vendida)', position: 'bottom', offset: 20, fill: '#374151' }}
            />
            <YAxis 
              type="number" 
              dataKey="margem_unitaria" 
              name="Lucratividade" 
              stroke="#6b7280"
              label={{ value: 'Lucratividade (Margem R$)', angle: -90, position: 'left', offset: 20, fill: '#374151' }}
            />
            <Tooltip content={<CustomTooltip />} cursor={{ strokeDasharray: '3 3' }} />
            
            {/* Linhas de Média (Quadrantes) */}
            <ReferenceLine x={medias.popularidade} stroke="#9ca3af" strokeDasharray="5 5">
                <Label value="Média Pop." position="insideTopRight" fill="#9ca3af" fontSize={10} />
            </ReferenceLine>
            <ReferenceLine y={medias.margem} stroke="#9ca3af" strokeDasharray="5 5">
                <Label value="Média Margem" position="insideTopRight" fill="#9ca3af" fontSize={10} />
            </ReferenceLine>

            <Scatter name="Pratos" data={dadosFormatados}>
              {dadosFormatados.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={entry.color} />
              ))}
            </Scatter>
          </ScatterChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}