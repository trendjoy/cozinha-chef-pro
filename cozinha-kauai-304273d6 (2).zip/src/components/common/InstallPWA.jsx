import React, { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Download, Share, PlusSquare, X } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";

export default function InstallPWA() {
  const [deferredPrompt, setDeferredPrompt] = useState(null);
  const [showIOSInstructions, setShowIOSInstructions] = useState(false);
  const [isIOS, setIsIOS] = useState(false);
  const [isStandalone, setIsStandalone] = useState(false);

  useEffect(() => {
    // Check if running in standalone mode (installed)
    const isInStandaloneMode = () => 
      ('standalone' in window.navigator) && (window.navigator.standalone) ||
      (window.matchMedia('(display-mode: standalone)').matches);

    if (isInStandaloneMode()) {
      setIsStandalone(true);
    }

    // Check if iOS
    const isIosDevice = /iPad|iPhone|iPod/.test(navigator.userAgent) && !window.MSStream;
    setIsIOS(isIosDevice);

    // Capture install prompt
    const handleBeforeInstallPrompt = (e) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    };
  }, []);

  const handleInstallClick = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      if (outcome === 'accepted') {
        setDeferredPrompt(null);
      }
    } else if (isIOS) {
      setShowIOSInstructions(true);
    } else {
        // Fallback for browsers that don't support beforeinstallprompt but aren't iOS
        alert("Para instalar, procure a opção 'Adicionar à Tela Inicial' ou 'Instalar Aplicativo' no menu do seu navegador.");
    }
  };

  if (isStandalone) return null; // Don't show if already installed

  // Only show button if we have a prompt OR it's iOS (since iOS doesn't fire the event)
  // if (!deferredPrompt && !isIOS) return null; 
  // Comentado para mostrar sempre o botão e dar feedback manual se necessário

  return (
    <>
      <Button 
        onClick={handleInstallClick}
        className="w-full bg-orange-600 hover:bg-orange-700 text-white gap-2 shadow-sm"
        size="sm"
      >
        <Download className="w-4 h-4" />
        Instalar App
      </Button>

      <Dialog open={showIOSInstructions} onOpenChange={setShowIOSInstructions}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Instalar CozinhaChefPro no iPhone</DialogTitle>
            <DialogDescription>
              Siga os passos abaixo para adicionar o sistema à sua tela inicial:
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 pt-2">
            <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
              <div className="bg-white p-2 rounded shadow-sm">
                <Share className="w-6 h-6 text-blue-500" />
              </div>
              <p className="text-sm text-gray-700">1. Toque no botão <strong>Compartilhar</strong> na barra inferior do Safari.</p>
            </div>
            <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
              <div className="bg-white p-2 rounded shadow-sm">
                <PlusSquare className="w-6 h-6 text-gray-700" />
              </div>
              <p className="text-sm text-gray-700">2. Role para baixo e selecione <strong>Adicionar à Tela de Início</strong>.</p>
            </div>
            <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
              <div className="bg-white p-2 rounded shadow-sm">
                <span className="text-blue-600 font-bold">Adic.</span>
              </div>
              <p className="text-sm text-gray-700">3. Confirme tocando em <strong>Adicionar</strong> no canto superior direito.</p>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}