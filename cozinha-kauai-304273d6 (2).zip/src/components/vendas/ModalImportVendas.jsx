import React, { useState, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { useQueryClient } from "@tanstack/react-query";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Upload, AlertCircle, CheckCircle2, X, FileSpreadsheet } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Progress } from "@/components/ui/progress";
import { useOrganization } from "@/components/auth/OrganizationProvider";

export default function ModalImportVendas({ onClose, onSuccess }) {
  const { organizacao } = useOrganization();
  const [file, setFile] = useState(null);
  const [status, setStatus] = useState("idle"); // idle, processing, success, error
  const [stats, setStats] = useState({ total: 0, processed: 0 });
  const [errorMessage, setErrorMessage] = useState("");
  
  const fileInputRef = useRef(null);
  const queryClient = useQueryClient();

  const handleFileChange = (e) => {
    const selected = e.target.files[0];
    if (selected && selected.type === "text/csv") {
      setFile(selected);
      setErrorMessage("");
    } else {
      setErrorMessage("Por favor, selecione um arquivo CSV válido.");
      setFile(null);
    }
  };

  const processCSV = async () => {
    if (!file) return;

    setStatus("processing");
    setStats({ total: 0, processed: 0 });
    
    const reader = new FileReader();
    
    reader.onload = async (e) => {
      try {
        const text = e.target.result;
        const lines = text.split('\n');
        const dataLines = lines.slice(1).filter(line => line.trim() !== ''); // Skip header
        
        setStats({ total: dataLines.length, processed: 0 });

        // Process in chunks to avoid overwhelming the API
        const chunkSize = 50;
        const chunks = [];
        
        // Parse all lines first
        const parsedItems = dataLines.map(line => {
          // Simple CSV parser - assumes semicolon or comma
          const cols = line.includes(';') ? line.split(';') : line.split(',');
          
          // Modelo esperado: Data;Produto;Quantidade;ValorTotal;Canal
          // Tenta ser flexível
          const dataRaw = cols[0]?.replace(/"/g, '').trim();
          const nome = cols[1]?.replace(/"/g, '').trim();
          const qtd = parseFloat(cols[2]?.replace(',', '.').replace(/"/g, '') || 0);
          const valor = parseFloat(cols[3]?.replace(',', '.').replace('R$', '').replace(/"/g, '') || 0);
          const canal = cols[4]?.replace(/"/g, '').trim() || "Salao";
          
          // Parse Date (assume DD/MM/YYYY or YYYY-MM-DD)
          let dataVenda = new Date();
          if (dataRaw.includes('/')) {
             const [d, m, y] = dataRaw.split(' ')[0].split('/');
             // Assume time might be present, but ignore for now or parse if needed
             // Simple fix for year
             const year = y.length === 2 ? `20${y}` : y;
             dataVenda = new Date(`${year}-${m}-${d}`);
          } else {
             dataVenda = new Date(dataRaw);
          }
          
          if (isNaN(dataVenda.getTime())) dataVenda = new Date(); // Fallback to now if fail

          return {
            organizacao_id: organizacao.id,
            data_venda: dataVenda.toISOString(),
            nome_produto: nome || "Item Desconhecido",
            quantidade: qtd,
            valor_total: valor,
            canal: canal,
            arquivo_importacao: file.name
          };
        }).filter(item => item.nome_produto !== "Item Desconhecido" && item.valor_total > 0);

        // Create chunks
        for (let i = 0; i < parsedItems.length; i += chunkSize) {
          chunks.push(parsedItems.slice(i, i + chunkSize));
        }

        // Upload chunks
        let processedCount = 0;
        for (const chunk of chunks) {
            await base44.entities.Venda.bulkCreate(chunk);
            processedCount += chunk.length;
            setStats(prev => ({ ...prev, processed: processedCount }));
        }

        queryClient.invalidateQueries(['vendas']);
        setStatus("success");
        setTimeout(() => {
            onSuccess();
        }, 1500);

      } catch (err) {
        console.error(err);
        setStatus("error");
        setErrorMessage("Erro ao processar arquivo. Verifique o formato.");
      }
    };

    reader.readAsText(file, 'ISO-8859-1'); // Encoding comum para Excel BR
  };

  return (
    <Dialog open onOpenChange={status === 'processing' ? () => {} : onClose}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Importar Relatório de Vendas</DialogTitle>
          <DialogDescription>
            Selecione o arquivo CSV exportado do seu sistema de PDV.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          {status === "idle" && (
            <div className="border-2 border-dashed border-gray-200 rounded-lg p-8 text-center hover:bg-gray-50 transition-colors">
              <input
                type="file"
                ref={fileInputRef}
                onChange={handleFileChange}
                accept=".csv"
                className="hidden"
              />
              <Button 
                variant="outline" 
                onClick={() => fileInputRef.current?.click()}
                className="mx-auto"
              >
                <FileSpreadsheet className="w-4 h-4 mr-2" />
                Selecionar Arquivo CSV
              </Button>
              {file && (
                <p className="mt-2 text-sm text-emerald-600 font-medium">
                  {file.name} selecionado
                </p>
              )}
              <p className="mt-4 text-xs text-gray-500">
                Formato esperado: Data;Produto;Quantidade;Valor;Canal
              </p>
            </div>
          )}

          {status === "processing" && (
            <div className="space-y-2">
              <div className="flex justify-between text-sm text-gray-600">
                <span>Importando vendas...</span>
                <span>{Math.round((stats.processed / stats.total) * 100)}%</span>
              </div>
              <Progress value={(stats.processed / stats.total) * 100} />
              <p className="text-xs text-gray-500 text-center">
                Processando {stats.processed} de {stats.total} registros
              </p>
            </div>
          )}

          {status === "success" && (
            <Alert className="bg-green-50 border-green-200">
              <CheckCircle2 className="h-4 w-4 text-green-600" />
              <AlertTitle className="text-green-800">Sucesso!</AlertTitle>
              <AlertDescription className="text-green-700">
                Vendas importadas com sucesso. Atualizando lista...
              </AlertDescription>
            </Alert>
          )}

          {status === "error" && (
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>Erro</AlertTitle>
              <AlertDescription>{errorMessage}</AlertDescription>
            </Alert>
          )}
        </div>

        <DialogFooter>
          {status !== "processing" && status !== "success" && (
            <>
              <Button variant="outline" onClick={onClose}>Cancelar</Button>
              <Button 
                onClick={processCSV} 
                disabled={!file}
                className="bg-emerald-600 hover:bg-emerald-700 text-white"
              >
                <Upload className="w-4 h-4 mr-2" />
                Iniciar Importação
              </Button>
            </>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}