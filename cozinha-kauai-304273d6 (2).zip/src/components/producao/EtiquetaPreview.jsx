import React from "react";
import { Button } from "@/components/ui/button";
import { Printer, Download, FileText } from "lucide-react";

export default function EtiquetaPreview({ data }) {
  const handlePrint = (isPdf = false) => {
    const printContent = document.getElementById('etiqueta-print');
    const printWindow = window.open('', '', 'height=600,width=800');
    
    // Define nome do arquivo para salvar como PDF
    const filename = `etiqueta-${data.nome.replace(/[^a-z0-9]/gi, '_')}-${data.lote}`;
    
    printWindow.document.write(`<html><head><title>${filename}</title>`);
    printWindow.document.write('<style>');
    printWindow.document.write(`
      @page { margin: 0; }
      body { 
        font-family: Arial, sans-serif; 
        padding: 20px; 
        display: flex; 
        justify-content: center; 
        align-items: center;
      }
      .etiqueta-container {
        width: 100%;
        max-width: 300px; /* Tamanho otimizado para etiqueta */
        border: 2px solid #000 !important;
        padding: 15px !important;
        border-radius: 8px;
      }
      /* Forçar cores para impressão */
      * { -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; }
    `);
    printWindow.document.write('</style></head><body>');
    
    // Envolve o conteúdo numa div para centralizar e aplicar estilos específicos de impressão
    printWindow.document.write('<div class="etiqueta-container">');
    printWindow.document.write(printContent.innerHTML);
    printWindow.document.write('</div>');
    
    printWindow.document.write('</body></html>');
    printWindow.document.close();
    
    // Pequeno delay para garantir carregamento dos estilos
    setTimeout(() => {
      printWindow.focus();
      printWindow.print();
      // Fecha a janela apenas se for PDF (usuário clica rápido em salvar)
      // Se for impressão normal, mantém aberta para debug se necessário, ou fecha depois
      if (isPdf) {
        // Não fechamos automaticamente para dar tempo do usuário salvar
      }
    }, 250);
  };

  const handleDownload = () => {
    const content = `
ETIQUETA DE PRODUÇÃO - CozinhaChefPro
=====================================

Produto: ${data.nome}
Quantidade: ${data.quantidade}
Data Produção: ${data.data}
Data Validade: ${data.validade}
Lote: ${data.lote}
Responsável: ${data.responsavel}

=====================================
    `.trim();

    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `etiqueta-${data.lote}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-4">
      <div 
        id="etiqueta-print"
        className="p-6 border-4 border-orange-500 rounded-lg bg-white max-w-md mx-auto"
      >
        <div className="text-center border-b-2 border-orange-300 pb-3 mb-4">
          <h2 className="text-2xl font-bold text-orange-600">CozinhaChefPro</h2>
          <p className="text-sm text-gray-600">Etiqueta de Produção</p>
        </div>

        <div className="space-y-3">
          <div>
            <p className="text-xs text-gray-500 uppercase">Produto</p>
            <p className="text-lg font-bold text-gray-900">{data.nome}</p>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <p className="text-xs text-gray-500 uppercase">Quantidade</p>
              <p className="font-semibold text-gray-900">{data.quantidade}</p>
            </div>
            <div>
              <p className="text-xs text-gray-500 uppercase">Lote</p>
              <p className="font-semibold text-gray-900 text-sm">{data.lote}</p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <p className="text-xs text-gray-500 uppercase">Produção</p>
              <p className="font-semibold text-gray-900">{data.data}</p>
            </div>
            <div>
              <p className="text-xs text-gray-500 uppercase">Validade</p>
              <p className="font-semibold text-red-600">{data.validade}</p>
            </div>
          </div>

          <div>
            <p className="text-xs text-gray-500 uppercase">Responsável</p>
            <p className="font-semibold text-gray-900">{data.responsavel}</p>
          </div>
        </div>
      </div>

      <div className="flex justify-center gap-3">
        <Button
          onClick={() => handlePrint(false)}
          variant="outline"
          className="gap-2 flex-1"
        >
          <Printer className="w-4 h-4" />
          Imprimir
        </Button>
        <Button
          onClick={() => {
            alert("Na janela de impressão, altere o 'Destino' para 'Salvar como PDF'.");
            handlePrint(true);
          }}
          className="gap-2 flex-1 bg-gray-800 hover:bg-gray-900 text-white"
        >
          <FileText className="w-4 h-4" />
          Baixar PDF
        </Button>
        <Button
          onClick={handleDownload}
          className="gap-2 flex-1 bg-gradient-to-r from-orange-500 to-amber-600 hover:from-orange-600 hover:to-amber-700"
        >
          <Download className="w-4 h-4" />
          TXT
        </Button>
      </div>
    </div>
  );
}