import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Search, Check } from "lucide-react";

export default function BuscaPreparacao({ onSelect, selecionado }) {
  const [busca, setBusca] = useState("");
  const [aberto, setAberto] = useState(false);

  const { data: preparacoes = [] } = useQuery({
    queryKey: ['preparacoes'],
    queryFn: () => base44.entities.Preparacao.list(),
  });

  const preparacoesFiltradas = preparacoes.filter(p =>
    p.nome?.toLowerCase().includes(busca.toLowerCase())
  ).slice(0, 8);

  const handleSelect = (prep) => {
    onSelect(prep);
    setBusca("");
    setAberto(false);
  };

  return (
    <div className="space-y-2">
      <Label>Buscar Preparação *</Label>
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
        <Input
          value={busca}
          onChange={(e) => {
            setBusca(e.target.value);
            setAberto(true);
          }}
          onFocus={() => setAberto(true)}
          placeholder="Digite o nome da preparação..."
          className="pl-10 border-orange-200 focus:border-orange-400"
        />
        
        {aberto && busca && preparacoesFiltradas.length > 0 && (
          <div className="absolute z-10 w-full mt-1 bg-white border border-orange-200 rounded-lg shadow-lg max-h-64 overflow-auto">
            {preparacoesFiltradas.map((prep) => (
              <div
                key={prep.id}
                onClick={() => handleSelect(prep)}
                className="p-3 hover:bg-orange-50 cursor-pointer border-b border-orange-100 last:border-0"
              >
                <div className="flex justify-between items-center">
                  <span className="font-medium text-gray-900">{prep.nome}</span>
                  <Badge variant="outline" className="bg-orange-50 text-orange-700 border-orange-200">
                    {prep.categoria}
                  </Badge>
                </div>
                <p className="text-xs text-gray-600 mt-1">
                  {prep.rendimento} {prep.unidade_saida} • {prep.praca}
                </p>
              </div>
            ))}
          </div>
        )}
      </div>

      {selecionado && (
        <div className="p-4 bg-gradient-to-r from-green-50 to-emerald-50 border border-green-200 rounded-lg">
          <div className="flex items-center gap-2 text-green-800">
            <Check className="w-5 h-5" />
            <span className="font-semibold">{selecionado.nome}</span>
          </div>
          <p className="text-sm text-green-700 mt-1">
            Rendimento: {selecionado.rendimento} {selecionado.unidade_saida} • Validade: {selecionado.validade_dias} dias
          </p>
        </div>
      )}
    </div>
  );
}