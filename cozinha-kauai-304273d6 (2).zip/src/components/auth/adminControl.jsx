export const SUPER_ADMINS = [
  "rmart24.rm@gmail.com"
];

export const isSuperAdmin = (email) => {
  return SUPER_ADMINS.includes(email);
};