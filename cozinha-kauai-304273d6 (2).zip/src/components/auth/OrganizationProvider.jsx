import React, { createContext, useContext, useState, useEffect } from 'react';
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { useNavigate, useLocation } from 'react-router-dom';
import { Loader2 } from "lucide-react";

const OrganizationContext = createContext(null);

export function OrganizationProvider({ children }) {
  const [user, setUser] = useState(null);
  const navigate = useNavigate();
  const location = useLocation();

  // Função auxiliar para determinar se é página pública
  const checkIsPublic = (pathname) => {
    const p = pathname.toLowerCase();
    return (
      p === '/' || 
      p === '' || 
      p === '/index.html' ||
      p.startsWith('/landing') || 
      p.startsWith('/links') ||
      p.includes('exportarlanding')
    );
  };

  const isPublicPage = checkIsPublic(location.pathname);

  // 1. Autenticação Inicial
  useEffect(() => {
    // Verificação de segurança usando window.location para garantir que pegamos a URL real do navegador
    const isPublic = checkIsPublic(window.location.pathname);

    // Se for pública, tentamos pegar o usuário apenas para melhorar a UX (mostrar botão Dashboard),
    // mas JAMAIS redirecionamos para login, mesmo se falhar.
    if (isPublic) {
        base44.auth.me().then(setUser).catch(console.error);
        return; 
    }
    
    // Se for privada, o fluxo segue normal
    base44.auth.me().then(u => {
      if (u) {
        setUser(u);
      } else {
        base44.auth.redirectToLogin();
      }
    }).catch((err) => {
      console.error("Auth Error:", err);
      base44.auth.redirectToLogin();
    });
  }, []); // Executa apenas uma vez na montagem

  // 2. Busca dados do membro
  const { data: membro, isLoading: loadingMembro } = useQuery({
    queryKey: ['membro-equipe', user?.email],
    queryFn: async () => {
      if (!user?.email) return null;
      try {
        const membros = await base44.entities.MembroEquipe.filter({ email_usuario: user.email });
        if (!membros || membros.length === 0) return null;

        // Tenta recuperar a última organização acessada do localStorage
        const savedOrgId = localStorage.getItem('chefpro_org_id');
        
        if (savedOrgId) {
          const preferred = membros.find(m => m.organizacao_id === savedOrgId && m.status === 'ativo');
          if (preferred) return preferred;
        }

        const mainOrgId = '692e71c90edccbefb225a48e';

        // Se for Super Admin, tenta priorizar a conta mãe (Escritório Central)
        if (isSuperAdmin(user?.email)) {
          const mainMember = membros.find(m => m.organizacao_id === mainOrgId && m.status === 'ativo');
          if (mainMember) return mainMember;
        }

        // Para usuários normais (ou se Super Admin não tiver acesso à mãe), prioriza outras organizações
        const userOrg = membros.find(m => m.organizacao_id !== mainOrgId && m.status === 'ativo');
        if (userOrg) return userOrg;

        // Fallback: qualquer organização ativa
        const activeMember = membros.find(m => m.status === 'ativo');
        if (activeMember) return activeMember;

        return membros[0];
      } catch (error) {
        return null;
      }
    },
    enabled: !!user?.email,
  });

  // 3. Busca dados da organização
  const { data: organizacao, isLoading: loadingOrg } = useQuery({
    queryKey: ['organizacao', membro?.organizacao_id],
    queryFn: () => base44.entities.Organizacao.get(membro.organizacao_id),
    enabled: !!membro?.organizacao_id,
  });

  // 4. Roteamento Interno (Setup vs Dashboard)
  useEffect(() => {
    if (!user || loadingMembro || loadingOrg) return;

    // Se for página pública, nunca redireciona automaticamente
    if (isPublicPage) return;

    const isSetupPage = location.pathname.toLowerCase().startsWith("/setup");

    if (!membro && !isSetupPage) {
      navigate('/SetupOrganizacao');
    } else if (membro && isSetupPage) {
      navigate('/Dashboard');
    }
  }, [user, membro, loadingMembro, loadingOrg, isPublicPage, location.pathname, navigate]);

  const switchOrganization = (orgId) => {
    localStorage.setItem('chefpro_org_id', orgId);
    window.location.reload();
  };

  // 5. Controle de Renderização
  // Se for página pública, SEMPRE renderiza o conteúdo (Landing Page)
  if (isPublicPage) {
    return (
      <OrganizationContext.Provider value={{ user, organizacao, membro, switchOrganization }}>
        {children}
      </OrganizationContext.Provider>
    );
  }

  // Se for privada e estiver carregando usuário/dados, mostra loading
  if (loadingMembro || loadingOrg || !user) {
    return (
      <div className="h-screen w-full flex flex-col items-center justify-center bg-orange-50 gap-4">
        <Loader2 className="w-10 h-10 text-orange-600 animate-spin" />
        <p className="text-orange-800 font-medium animate-pulse">Carregando sua cozinha...</p>
      </div>
    );
  }

  return (
    <OrganizationContext.Provider value={{ user, organizacao, membro, switchOrganization }}>
      {children}
    </OrganizationContext.Provider>
  );
}

export const useOrganization = () => useContext(OrganizationContext);