import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { Utensils, Save, Search, ArrowRightLeft, Coffee } from "lucide-react";
import { toast } from "sonner";
import { useOrganization } from "@/components/auth/OrganizationProvider";

export default function FormRefeitorio() {
  const { organizacao } = useOrganization();
  const [activeTab, setActiveTab] = useState("diario");
  const [formData, setFormData] = useState({
    produto_id: "",
    quantidade: "",
    origem_estoque: "cozinha",
    observacao: "",
    responsavel: ""
  });
  const [busca, setBusca] = useState("");

  const queryClient = useQueryClient();

  useEffect(() => {
    // Reset form and set origin based on tab
    setFormData(prev => ({
        ...prev,
        produto_id: "",
        quantidade: "",
        origem_estoque: activeTab === "diario" ? "cozinha" : "almoxarifado"
    }));
    setBusca("");
  }, [activeTab]);

  const { data: produtos = [], isLoading: loadingProdutos } = useQuery({
    queryKey: ['produtos', organizacao?.id],
    queryFn: () => {
      if (!organizacao?.id) return [];
      return base44.entities.Produto.filter({ organizacao_id: organizacao.id }, undefined, 1000);
    },
    enabled: !!organizacao?.id,
  });

  const { data: preparacoes = [], isLoading: loadingPreparacoes } = useQuery({
    queryKey: ['preparacoes', organizacao?.id],
    queryFn: () => {
      if (!organizacao?.id) return [];
      return base44.entities.Preparacao.filter({ organizacao_id: organizacao.id }, undefined, 1000);
    },
    enabled: !!organizacao?.id,
  });

  const loading = loadingProdutos || loadingPreparacoes;

  // Combina produtos e preparações com verificação de segurança
  const todosItens = [
    ...produtos.map(p => ({ ...p, tipo_origem: 'produto', label_tipo: 'Insumo' })),
    ...preparacoes.map(p => ({ ...p, tipo_origem: 'preparacao', label_tipo: 'Prep' }))
  ];

  // Filtrar itens disponíveis baseado na aba
  const itensDisponiveis = activeTab === 'almoxarifado' 
    ? todosItens.filter(i => i.tipo_origem === 'produto') // Almoxarifado só tem produtos/insumos
    : todosItens; // Diário (Cozinha) tem produtos e preparações

  const itensFiltrados = itensDisponiveis.filter(p => {
    const termo = busca.toLowerCase();
    const nome = (p.nome || "").toLowerCase();
    const codigo = (p.codigo || "").toLowerCase();
    return nome.includes(termo) || codigo.includes(termo);
  }).sort((a, b) => (a.nome || "").localeCompare(b.nome || "")).slice(0, 100);

  const selectedItem = todosItens.find(p => p.id === formData.produto_id);

  const mutation = useMutation({
    mutationFn: async (data) => {
      if (!selectedItem) throw new Error("Item não encontrado");

      const qtd = parseFloat(data.quantidade);
      const novoEstoque = (selectedItem.estoque_atual || 0) - qtd;
      const custoUnit = selectedItem.custo_unitario || 0;
      const custoTotal = qtd * custoUnit;

      // 1. Atualiza estoque (Produto ou Preparação)
      let estoqueAnterior = 0;
      let estoqueNovoCalculado = 0;

      if (selectedItem.tipo_origem === 'preparacao') {
        // Preparações sempre saem da cozinha (estoque_atual)
        estoqueAnterior = selectedItem.estoque_atual || 0;
        estoqueNovoCalculado = estoqueAnterior - qtd;
        await base44.entities.Preparacao.update(selectedItem.id, { estoque_atual: estoqueNovoCalculado });
      } else {
        // Produto: depende da origem escolhida
        if (data.origem_estoque === 'almoxarifado') {
            estoqueAnterior = selectedItem.estoque_primario || 0;
            estoqueNovoCalculado = estoqueAnterior - qtd;
            await base44.entities.Produto.update(selectedItem.id, { estoque_primario: estoqueNovoCalculado });
        } else {
            estoqueAnterior = selectedItem.estoque_atual || 0;
            estoqueNovoCalculado = estoqueAnterior - qtd;
            await base44.entities.Produto.update(selectedItem.id, { estoque_atual: estoqueNovoCalculado });
        }
      }

      // 2. Cria histórico
      await base44.entities.HistoricoEstoque.create({
        organizacao_id: organizacao.id,
        tipo_item: selectedItem.tipo_origem,
        item_id: selectedItem.id,
        item_nome: selectedItem.nome,
        movimento: "saida",
        quantidade: qtd,
        estoque_anterior: estoqueAnterior,
        estoque_novo: estoqueNovoCalculado,
        motivo: "refeitorio",
        custo_unitario: custoUnit,
        custo_total: custoTotal,
        observacao: data.observacao,
        responsavel: data.responsavel,
        data_movimento: new Date().toISOString()
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['produtos']);
      queryClient.invalidateQueries(['preparacoes']);
      queryClient.invalidateQueries(['historico-estoque']);
      toast.success("Saída para refeitório registrada!");
      setFormData({ ...formData, quantidade: "", observacao: "" });
    },
    onError: () => toast.error("Erro ao registrar saída")
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.produto_id || !formData.quantidade) return;
    mutation.mutate(formData);
  };

  return (
    <div className="space-y-4 p-4 bg-indigo-50/50 rounded-lg border border-indigo-100">
      <div className="flex items-center gap-2 text-indigo-800 mb-2">
        <Utensils className="w-5 h-5" />
        <h3 className="font-semibold">Gestão Refeitório</h3>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-2 mb-4">
          <TabsTrigger value="diario" className="gap-2 data-[state=active]:bg-indigo-600 data-[state=active]:text-white">
            <Coffee className="w-4 h-4" />
            Consumo Diário
          </TabsTrigger>
          <TabsTrigger value="almoxarifado" className="gap-2 data-[state=active]:bg-indigo-600 data-[state=active]:text-white">
            <ArrowRightLeft className="w-4 h-4" />
            Req. Almoxarifado
          </TabsTrigger>
        </TabsList>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label>Buscar Item ({activeTab === 'diario' ? 'Insumo ou Preparação' : 'Somente Insumos'})</Label>
            <div className="relative">
              <Search className="absolute left-2 top-2.5 h-4 w-4 text-gray-400" />
              <Input 
                placeholder={activeTab === 'diario' ? "Buscar item consumo diário..." : "Buscar insumo do almoxarifado..."}
                value={busca}
                onChange={(e) => setBusca(e.target.value)}
                className="pl-8 bg-white border-indigo-200 focus:border-indigo-400"
              />
            </div>
            <p className="text-xs text-gray-500">
              {loading ? "Carregando itens..." : `Mostrando ${itensFiltrados.length} de ${itensDisponiveis.length} itens disponíveis`}
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Selecione o Item</Label>
              <Select 
                value={formData.produto_id} 
                onValueChange={(v) => setFormData({...formData, produto_id: v})}
              >
                <SelectTrigger className="bg-white border-indigo-200">
                  <SelectValue placeholder={loading ? "Carregando..." : "Selecione na lista..."} />
                </SelectTrigger>
                <SelectContent>
                  {itensFiltrados.length === 0 && !loading && (
                     <SelectItem value="none" disabled>Nenhum item encontrado</SelectItem>
                  )}
                  {itensFiltrados.map(p => (
                    <SelectItem key={p.id} value={p.id}>
                      [{p.label_tipo}] {p.nome}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Quantidade Usada</Label>
              <div className="flex gap-2 items-center">
                <Input 
                  type="number" 
                  step="0.001" 
                  value={formData.quantidade}
                  onChange={(e) => setFormData({...formData, quantidade: e.target.value})}
                  className="bg-white border-indigo-200"
                  placeholder="Qtd"
                  required
                />
                <span className="text-sm text-gray-500 w-12">
                  {selectedItem?.unidade || selectedItem?.unidade_saida || 'un'}
                </span>
              </div>
            </div>

            {/* Campo de Origem agora é controlado pela Aba e meramente informativo se necessário, ou oculto */}
            <div className="space-y-2">
               <Label>Origem do Estoque</Label>
               <div className="h-10 flex items-center px-3 bg-indigo-100/50 rounded text-sm font-medium text-indigo-700 border border-indigo-200">
                  {activeTab === 'diario' ? 'Cozinha / Produção (Diário)' : 'Almoxarifado / Central'}
               </div>
            </div>

            <div className="space-y-2">
              <Label>Responsável</Label>
          <Input 
            value={formData.responsavel}
            onChange={(e) => setFormData({...formData, responsavel: e.target.value})}
            className="bg-white border-indigo-200"
            placeholder="Nome"
            required
          />
        </div>
        
        <div className="space-y-2">
          <Label>Estoque Disponível ({activeTab === 'almoxarifado' ? 'Almox' : 'Cozinha'})</Label>
          <div className="h-10 flex items-center px-3 bg-white rounded text-sm border border-indigo-200 text-gray-700">
            {selectedItem ? (
                activeTab === 'almoxarifado' && selectedItem.tipo_origem !== 'preparacao'
                ? `${selectedItem.estoque_primario || 0} ${selectedItem.unidade}`
                : `${selectedItem.estoque_atual || 0} ${selectedItem.unidade || selectedItem.unidade_saida}`
            ) : '-'}
          </div>
        </div>

        <div className="space-y-2">
          <Label>Custo Estimado</Label>
          <div className="h-10 flex items-center px-3 bg-indigo-100 rounded text-sm font-medium text-indigo-700 border border-indigo-200">
            R$ {selectedItem && formData.quantidade ? 
              ((selectedItem.custo_unitario || 0) * parseFloat(formData.quantidade)).toFixed(2) 
              : '0.00'}
          </div>
        </div>
      </div>

      <div className="space-y-2">
        <Label>Observações</Label>
        <Textarea 
          value={formData.observacao}
          onChange={(e) => setFormData({...formData, observacao: e.target.value})}
          className="bg-white h-20 border-indigo-200"
          placeholder="Detalhes do cardápio ou uso..."
        />
      </div>

          <Button 
            type="submit" 
            disabled={mutation.isPending || !selectedItem}
            className="w-full bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-700 hover:to-blue-700 text-white shadow"
          >
            <Save className="w-4 h-4 mr-2" />
            {activeTab === 'diario' ? 'Registrar Consumo Diário' : 'Registrar Requisição Almox.'}
          </Button>
        </form>
      </Tabs>
    </div>
  );
}