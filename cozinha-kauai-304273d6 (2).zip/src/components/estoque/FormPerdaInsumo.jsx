import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Trash2, Save, Search } from "lucide-react";
import { toast } from "sonner";
import { useOrganization } from "@/components/auth/OrganizationProvider";

export default function FormPerdaInsumo() {
  const { organizacao } = useOrganization();
  const [formData, setFormData] = useState({
    produto_id: "",
    quantidade: "",
    motivo: "aparas",
    observacao: "",
    responsavel: ""
  });
  const [busca, setBusca] = useState("");

  const queryClient = useQueryClient();

  // Busca produtos
  const { data: produtos = [] } = useQuery({
    queryKey: ['produtos', organizacao?.id],
    queryFn: () => {
      if (!organizacao?.id) return [];
      return base44.entities.Produto.filter({ organizacao_id: organizacao.id });
    },
    enabled: !!organizacao?.id,
  });

  const produtosFiltrados = produtos.filter(p => 
    p.nome.toLowerCase().includes(busca.toLowerCase()) || 
    (p.codigo && p.codigo.toLowerCase().includes(busca.toLowerCase()))
  ).slice(0, 50); // Limita display

  const selectedProd = produtos.find(p => p.id === formData.produto_id);

  const mutation = useMutation({
    mutationFn: async (data) => {
      if (!selectedProd) throw new Error("Produto não encontrado");

      const qtd = parseFloat(data.quantidade);
      const novoEstoque = (selectedProd.estoque_atual || 0) - qtd;

      // 1. Atualiza estoque do produto
      await base44.entities.Produto.update(selectedProd.id, {
        estoque_atual: novoEstoque
      });

      // 2. Cria histórico
      await base44.entities.HistoricoEstoque.create({
        organizacao_id: organizacao.id,
        tipo_item: "produto",
        item_id: selectedProd.id,
        item_nome: selectedProd.nome,
        movimento: "perda",
        quantidade: qtd,
        estoque_anterior: selectedProd.estoque_atual || 0,
        estoque_novo: novoEstoque,
        motivo: data.motivo,
        observacao: data.observacao,
        responsavel: data.responsavel,
        data_movimento: new Date().toISOString()
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['produtos']);
      queryClient.invalidateQueries(['historico-estoque']);
      toast.success("Perda registrada com sucesso!");
      setFormData({ ...formData, quantidade: "", observacao: "" });
    },
    onError: () => toast.error("Erro ao registrar perda")
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.produto_id || !formData.quantidade) return;
    mutation.mutate(formData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4 p-4 bg-red-50/50 rounded-lg border border-red-100">
      <div className="flex items-center gap-2 text-red-800 mb-2">
        <Trash2 className="w-5 h-5" />
        <h3 className="font-semibold">Registro de Perda de Insumo</h3>
      </div>

      <div className="space-y-2">
        <Label>Buscar Produto</Label>
        <div className="relative">
          <Search className="absolute left-2 top-2.5 h-4 w-4 text-gray-400" />
          <Input 
            placeholder="Digite o nome do insumo..." 
            value={busca}
            onChange={(e) => setBusca(e.target.value)}
            className="pl-8 bg-white"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label>Selecione o Insumo</Label>
          <Select 
            value={formData.produto_id} 
            onValueChange={(v) => setFormData({...formData, produto_id: v})}
          >
            <SelectTrigger className="bg-white">
              <SelectValue placeholder="Selecione na lista..." />
            </SelectTrigger>
            <SelectContent>
              {produtosFiltrados.map(p => (
                <SelectItem key={p.id} value={p.id}>
                  {p.nome} (Est: {p.estoque_atual || 0} {p.unidade})
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label>Quantidade Perdida</Label>
          <div className="flex gap-2 items-center">
            <Input 
              type="number" 
              step="0.001" 
              value={formData.quantidade}
              onChange={(e) => setFormData({...formData, quantidade: e.target.value})}
              className="bg-white"
              placeholder="Qtd"
              required
            />
            <span className="text-sm text-gray-500 w-12">
              {selectedProd?.unidade || 'un'}
            </span>
          </div>
        </div>

        <div className="space-y-2">
          <Label>Motivo da Perda</Label>
          <Select 
            value={formData.motivo} 
            onValueChange={(v) => setFormData({...formData, motivo: v})}
          >
            <SelectTrigger className="bg-white">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="aparas">Aparas / Limpeza (Descarte Técnico)</SelectItem>
              <SelectItem value="vencimento">Vencimento</SelectItem>
              <SelectItem value="avaria">Avaria / Mau estado</SelectItem>
              <SelectItem value="outros">Outros</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label>Responsável</Label>
          <Input 
            value={formData.responsavel}
            onChange={(e) => setFormData({...formData, responsavel: e.target.value})}
            className="bg-white"
            placeholder="Nome"
            required
          />
        </div>
      </div>

      <div className="space-y-2">
        <Label>Observações</Label>
        <Textarea 
          value={formData.observacao}
          onChange={(e) => setFormData({...formData, observacao: e.target.value})}
          className="bg-white h-20"
          placeholder="Ex: Produto chegou estragado, ou sobra de limpeza excessiva..."
        />
      </div>

      <Button 
        type="submit" 
        disabled={mutation.isPending || !selectedProd}
        className="w-full bg-red-600 hover:bg-red-700"
      >
        <Save className="w-4 h-4 mr-2" />
        Registrar Perda
      </Button>
    </form>
  );
}