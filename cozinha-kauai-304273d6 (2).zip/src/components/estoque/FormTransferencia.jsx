import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ArrowRightLeft, Save, Search } from "lucide-react";
import { toast } from "sonner";
import { useOrganization } from "@/components/auth/OrganizationProvider";

export default function FormTransferencia() {
  const { organizacao } = useOrganization();
  const [busca, setBusca] = useState("");
  const [formData, setFormData] = useState({
    produto_id: "",
    quantidade: "",
    responsavel: "",
    centro_custo: "Cozinha Central"
  });

  const queryClient = useQueryClient();

  // Busca produtos
  const { data: produtos = [] } = useQuery({
    queryKey: ['produtos', organizacao?.id],
    queryFn: () => {
      if (!organizacao?.id) return [];
      return base44.entities.Produto.filter({ organizacao_id: organizacao.id }, undefined, 1000);
    },
    enabled: !!organizacao?.id,
  });

  const produtosFiltrados = produtos.filter(p => 
    (p.nome || "").toLowerCase().includes(busca.toLowerCase()) ||
    (p.codigo || "").toLowerCase().includes(busca.toLowerCase())
  );

  const selectedProd = produtos.find(p => p.id === formData.produto_id);

  const mutation = useMutation({
    mutationFn: async (data) => {
      if (!selectedProd) throw new Error("Produto não encontrado");

      const qtd = parseFloat(data.quantidade);
      const novoEstoquePrimario = (selectedProd.estoque_primario || 0) - qtd;
      const novoEstoqueSecundario = (selectedProd.estoque_atual || 0) + qtd;

      // 1. Atualiza estoque do produto (ambos)
      await base44.entities.Produto.update(selectedProd.id, {
        estoque_primario: novoEstoquePrimario,
        estoque_atual: novoEstoqueSecundario
      });

      // 2. Cria histórico (Registrando a entrada no secundário/cozinha com Centro de Custo)
      await base44.entities.HistoricoEstoque.create({
        organizacao_id: organizacao.id,
        tipo_item: "produto",
        item_id: selectedProd.id,
        item_nome: selectedProd.nome,
        movimento: "entrada", // Entrada na cozinha/setor
        quantidade: qtd,
        estoque_anterior: selectedProd.estoque_atual || 0,
        estoque_novo: novoEstoqueSecundario,
        motivo: "transferencia",
        centro_custo_destino: data.centro_custo,
        observacao: `Transferência para ${data.centro_custo}`,
        responsavel: data.responsavel,
        data_movimento: new Date().toISOString()
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['produtos']);
      queryClient.invalidateQueries(['historico-estoque']);
      toast.success("Transferência realizada com sucesso!");
      setFormData({ ...formData, quantidade: "" });
    },
    onError: () => toast.error("Erro ao registrar transferência")
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.produto_id || !formData.quantidade) return;
    mutation.mutate(formData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4 p-4 bg-indigo-50/50 rounded-lg border border-indigo-100">
      <div className="flex items-center gap-2 text-indigo-800 mb-2">
        <ArrowRightLeft className="w-5 h-5" />
        <h3 className="font-semibold">Requisição ao Almoxarifado</h3>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2 md:col-span-2">
             <Label>Buscar Produto</Label>
             <div className="relative">
               <Search className="absolute left-2 top-2.5 h-4 w-4 text-gray-400" />
               <Input 
                 placeholder="Digite para buscar produto por nome ou código..." 
                 value={busca}
                 onChange={(e) => setBusca(e.target.value)}
                 className="pl-8 bg-white"
               />
             </div>
        </div>

        <div className="space-y-2">
          <Label>Produto (Almoxarifado)</Label>
          <Select 
            value={formData.produto_id} 
            onValueChange={(v) => setFormData({...formData, produto_id: v})}
          >
            <SelectTrigger className="bg-white">
              <SelectValue placeholder={produtosFiltrados.length === 0 ? "Nenhum produto encontrado" : "Selecione o produto..."} />
            </SelectTrigger>
            <SelectContent>
              {produtosFiltrados.length === 0 ? (
                  <SelectItem value="none" disabled>Nenhum produto encontrado com "{busca}"</SelectItem>
              ) : (
                  produtosFiltrados.map(p => (
                    <SelectItem key={p.id} value={p.id}>
                      {p.nome} (Almox: {p.estoque_primario || 0} {p.unidade})
                    </SelectItem>
                  ))
              )}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label>Quantidade a Transferir</Label>
          <div className="flex gap-2 items-center">
            <Input 
              type="number" 
              step="0.01" 
              value={formData.quantidade}
              onChange={(e) => setFormData({...formData, quantidade: e.target.value})}
              className="bg-white"
              placeholder="Qtd"
              required
            />
            <span className="text-sm text-gray-500 w-12">
              {selectedProd?.unidade || 'un'}
            </span>
          </div>
        </div>

        <div className="space-y-2">
          <Label>Centro de Custo (Destino)</Label>
          <Select 
            value={formData.centro_custo} 
            onValueChange={(v) => setFormData({...formData, centro_custo: v})}
          >
            <SelectTrigger className="bg-white">
              <SelectValue placeholder="Selecione o destino..." />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Cozinha Central">Cozinha Central</SelectItem>
              <SelectItem value="Bebidas">Bebidas / Bar</SelectItem>
              <SelectItem value="Refeitório">Refeitório</SelectItem>
              <SelectItem value="DML">DML (Limpeza)</SelectItem>
              <SelectItem value="Descartáveis">Descartáveis</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label>Responsável</Label>
          <Input 
            value={formData.responsavel}
            onChange={(e) => setFormData({...formData, responsavel: e.target.value})}
            className="bg-white"
            placeholder="Nome"
            required
          />
        </div>
        
        <div className="flex items-end md:col-span-2">
           <div className="text-xs text-indigo-600 bg-indigo-100 p-3 rounded w-full border border-indigo-200">
              <p className="font-semibold mb-1">Resumo da Operação:</p>
              <ul className="list-disc pl-4 space-y-1">
                <li>Origem: <strong>Almoxarifado Central</strong> (Estoque Atual: {selectedProd?.estoque_primario || 0})</li>
                <li>Destino: <strong>{formData.centro_custo}</strong> (Será adicionado ao Estoque Operacional)</li>
                <li>Quantidade: <strong>{formData.quantidade || 0} {selectedProd?.unidade || ''}</strong></li>
              </ul>
           </div>
        </div>
      </div>

      <Button 
        type="submit" 
        disabled={mutation.isPending || !selectedProd}
        className="w-full bg-indigo-600 hover:bg-indigo-700"
      >
        <Save className="w-4 h-4 mr-2" />
        Confirmar Transferência
      </Button>
    </form>
  );
}