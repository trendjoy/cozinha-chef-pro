import React from "react";
import { useOrganization } from "@/components/auth/OrganizationProvider";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { ChevronsUpDown, Check, ChefHat, Building2, PlusCircle } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function OrgSwitcher() {
  const { organizacao, user, switchOrganization } = useOrganization();

  // Busca todas as organizações que o usuário tem acesso
  const { data: minhasOrgs = [] } = useQuery({
    queryKey: ['minhas-organizacoes', user?.email],
    queryFn: async () => {
      if (!user?.email) return [];
      // 1. Pega os vínculos
      const membros = await base44.entities.MembroEquipe.filter({ email_usuario: user.email });
      if (!membros.length) return [];

      // 2. Pega os detalhes de cada organização
      const orgs = await Promise.all(
        membros.map(async (m) => {
          if (!m.organizacao_id) return null;
          try {
            const org = await base44.entities.Organizacao.get(m.organizacao_id);
            if (!org) return null;
            return { ...org, role: m.cargo }; // Inclui o cargo
          } catch (e) {
            return null;
          }
        })
      );
      return orgs.filter(o => o && o.id && o.status !== 'cancelado');
    },
    enabled: !!user?.email
  });

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <button className="flex items-center gap-3 w-full p-2 rounded-lg hover:bg-orange-50 transition-colors outline-none group">
          <div className="relative w-10 h-10 bg-gray-900 rounded-lg flex items-center justify-center shadow-lg border border-gray-800 overflow-hidden flex-shrink-0">
             <div className="absolute inset-0 bg-gradient-to-tr from-gray-900 to-gray-800"></div>
             <ChefHat className="w-5 h-5 text-white relative z-10" />
             <div className="absolute -right-2 -top-2 w-6 h-6 bg-orange-500/20 rounded-full blur-xl"></div>
          </div>
          <div className="flex-1 text-left overflow-hidden">
            <h2 className="font-bold text-gray-900 text-sm truncate leading-tight">
              {organizacao?.nome || 'Selecione'}
            </h2>
            <p className="text-[10px] text-gray-500 font-medium truncate">
              {organizacao?.plano === 'enterprise' ? 'Enterprise Plan' : 'Cozinha Profissional'}
            </p>
          </div>
          <ChevronsUpDown className="w-4 h-4 text-gray-400 group-hover:text-orange-500" />
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="start" className="w-64 p-2">
        <DropdownMenuLabel className="text-xs text-gray-500 font-normal uppercase tracking-wider">
          Minhas Cozinhas
        </DropdownMenuLabel>
        
        {minhasOrgs.map((org) => (
          <DropdownMenuItem
            key={org.id}
            onClick={() => switchOrganization(org.id)}
            className="flex items-center gap-2 p-2 cursor-pointer"
          >
            <div className={`w-8 h-8 rounded-md flex items-center justify-center border ${org.id === organizacao?.id ? 'bg-orange-100 border-orange-200' : 'bg-white border-gray-200'}`}>
              <Building2 className={`w-4 h-4 ${org.id === organizacao?.id ? 'text-orange-600' : 'text-gray-500'}`} />
            </div>
            <div className="flex-1 overflow-hidden">
              <p className={`text-sm font-medium truncate ${org.id === organizacao?.id ? 'text-orange-700' : 'text-gray-700'}`}>
                {org.nome}
              </p>
            </div>
            {org.id === organizacao?.id && <Check className="w-4 h-4 text-orange-600" />}
          </DropdownMenuItem>
        ))}
        
        <DropdownMenuSeparator />
        
        <Link to={createPageUrl("SetupOrganizacao")}>
          <DropdownMenuItem className="gap-2 cursor-pointer text-orange-600 font-medium hover:text-orange-700 focus:text-orange-700">
            <PlusCircle className="w-4 h-4" />
            Nova Cozinha
          </DropdownMenuItem>
        </Link>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}