import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Trash2, Plus, Tag } from "lucide-react";
import { toast } from "sonner";

export default function ModalGerenciarCategorias({ onClose }) {
  const [novaCategoria, setNovaCategoria] = useState("");
  const queryClient = useQueryClient();

  const { data: categorias = [], isLoading } = useQuery({
    queryKey: ['categorias-produto'],
    queryFn: async () => {
      const res = await base44.entities.CategoriaProduto.list('nome');
      return Array.isArray(res) ? res : [];
    },
  });

  const createMutation = useMutation({
    mutationFn: (nome) => base44.entities.CategoriaProduto.create({ nome }),
    onSuccess: () => {
      queryClient.invalidateQueries(['categorias-produto']);
      setNovaCategoria("");
      toast.success("Categoria adicionada!");
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.CategoriaProduto.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries(['categorias-produto']);
      toast.success("Categoria removida!");
    },
  });

  const handleAdd = (e) => {
    e.preventDefault();
    if (!novaCategoria.trim()) return;
    // Check if exists
    if (categorias.some(c => c.nome.toLowerCase() === novaCategoria.trim().toLowerCase())) {
      toast.error("Categoria já existe.");
      return;
    }
    createMutation.mutate(novaCategoria.trim());
  };

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[400px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Tag className="w-5 h-5 text-orange-600" />
            Gerenciar Categorias
          </DialogTitle>
        </DialogHeader>

        <div className="py-4 space-y-4">
          <form onSubmit={handleAdd} className="flex gap-2">
            <Input
              value={novaCategoria}
              onChange={(e) => setNovaCategoria(e.target.value)}
              placeholder="Nova categoria..."
              className="flex-1"
            />
            <Button 
              type="submit" 
              disabled={createMutation.isPending || !novaCategoria.trim()}
              className="bg-green-600 hover:bg-green-700 text-white"
            >
              <Plus className="w-4 h-4" />
            </Button>
          </form>

          <div className="border rounded-lg divide-y max-h-[300px] overflow-y-auto">
            {isLoading ? (
              <div className="p-4 text-center text-sm text-gray-500">Carregando...</div>
            ) : categorias.length === 0 ? (
              <div className="p-4 text-center text-sm text-gray-500">Nenhuma categoria cadastrada.</div>
            ) : (
              categorias.map((cat) => (
                <div key={cat.id} className="flex justify-between items-center p-3 hover:bg-gray-50 text-sm">
                  <span>{cat.nome}</span>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => {
                        if(confirm(`Excluir categoria "${cat.nome}"?`)) {
                            deleteMutation.mutate(cat.id);
                        }
                    }}
                    className="h-8 w-8 text-red-500 hover:text-red-700 hover:bg-red-50"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              ))
            )}
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Fechar</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}