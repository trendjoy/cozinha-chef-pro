import React from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { useOrganization } from "@/components/auth/OrganizationProvider";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { format } from "date-fns";
import { ArrowDownCircle, Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";

export default function HistoricoEntradas() {
  const { organizacao } = useOrganization();
  const [busca, setBusca] = React.useState("");

  // Busca as últimas 100 entradas de estoque da organização atual
  const { data: historico = [], isLoading } = useQuery({
    queryKey: ['historico-entradas', organizacao?.id],
    queryFn: async () => {
      if (!organizacao?.id) return [];
      const res = await base44.entities.HistoricoEstoque.filter({ 
        movimento: 'entrada', 
        organizacao_id: organizacao.id 
      }, '-created_date', 100);
      return Array.isArray(res) ? res : [];
    },
    enabled: !!organizacao?.id
  });

  const safeHistorico = Array.isArray(historico) ? historico : [];
  const filtrados = safeHistorico.filter(item => 
    (item.item_nome || "").toLowerCase().includes(busca.toLowerCase()) ||
    (item.observacao || "").toLowerCase().includes(busca.toLowerCase())
  );

  if (isLoading) {
    return <div className="space-y-2">
      <Skeleton className="h-10 w-full" />
      <Skeleton className="h-10 w-full" />
      <Skeleton className="h-10 w-full" />
    </div>;
  }

  return (
    <div className="space-y-4">
      <div className="bg-white p-4 rounded-lg border border-gray-200 shadow-sm flex items-center gap-2">
        <Search className="w-4 h-4 text-gray-400" />
        <Input 
            placeholder="Filtrar entradas por produto ou observação..." 
            value={busca}
            onChange={(e) => setBusca(e.target.value)}
            className="border-none shadow-none focus-visible:ring-0"
        />
      </div>

      <div className="bg-white rounded-xl border border-green-200/50 shadow-lg overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow className="bg-green-50 hover:bg-green-50">
              <TableHead>Data</TableHead>
              <TableHead>Produto</TableHead>
              <TableHead>Quantidade</TableHead>
              <TableHead>Custo Unit.</TableHead>
              <TableHead>Total</TableHead>
              <TableHead>Observação / Nota</TableHead>
              <TableHead>Responsável</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filtrados.length === 0 ? (
              <TableRow>
                <TableCell colSpan={7} className="text-center py-8 text-gray-500">
                  Nenhuma entrada registrada recentemente.
                </TableCell>
              </TableRow>
            ) : (
              filtrados.map((mov) => (
                <TableRow key={mov.id} className="hover:bg-gray-50">
                  <TableCell className="text-xs text-gray-600">
                    {mov.data_movimento ? format(new Date(mov.data_movimento), "dd/MM/yyyy HH:mm") : "-"}
                  </TableCell>
                  <TableCell className="font-medium text-gray-900">
                    {mov.item_nome}
                  </TableCell>
                  <TableCell>
                    <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200 gap-1">
                      <ArrowDownCircle className="w-3 h-3" />
                      +{mov.quantidade}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    R$ {mov.custo_unitario?.toFixed(2)}
                  </TableCell>
                  <TableCell className="font-medium">
                    R$ {mov.custo_total?.toFixed(2)}
                  </TableCell>
                  <TableCell className="text-xs text-gray-500 max-w-[250px] truncate" title={mov.observacao}>
                    {mov.observacao || "-"}
                  </TableCell>
                  <TableCell className="text-xs text-gray-400">
                    {mov.responsavel}
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}