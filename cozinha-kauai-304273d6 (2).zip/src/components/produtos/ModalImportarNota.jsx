import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { 
    Camera, 
    Upload, 
    Loader2, 
    CheckCircle2, 
    AlertCircle, 
    ArrowRight, 
    Save, 
    ScanLine 
} from "lucide-react";
import { toast } from "sonner";
import { useOrganization } from "@/components/auth/OrganizationProvider";

export default function ModalImportarNota({ onClose }) {
  const { organizacao } = useOrganization();
  const [step, setStep] = useState('upload'); // upload, analyzing, review
  const [file, setFile] = useState(null);
  const [previewUrl, setPreviewUrl] = useState(null);
  const [extractedData, setExtractedData] = useState({
    nota_fiscal: "",
    fornecedor: "",
    itens: []
  });
  const [itemsMap, setItemsMap] = useState([]); // { index, produto_id, selected }

  const queryClient = useQueryClient();

  const { data: produtos = [] } = useQuery({
    queryKey: ['produtos', organizacao?.id],
    queryFn: async () => {
      if (!organizacao?.id) return [];
      const res = await base44.entities.Produto.filter({ organizacao_id: organizacao.id }, undefined, 1000);
      return Array.isArray(res) ? res : [];
    },
    enabled: !!organizacao?.id,
  });

  // Upload e Análise IA
  const analyzeMutation = useMutation({
    mutationFn: async (fileToUpload) => {
      // 1. Upload
      const { file_url } = await base44.integrations.Core.UploadFile({ 
        file: fileToUpload 
      });

      // 2. Extract Data
      const schema = {
        type: "object",
        properties: {
          numero_nota: { type: "string", description: "Número da Nota Fiscal" },
          fornecedor: { type: "string", description: "Nome do Fornecedor/Emitente" },
          itens: {
            type: "array",
            items: {
              type: "object",
              properties: {
                nome_produto: { type: "string", description: "Nome do produto na nota" },
                quantidade: { type: "number", description: "Quantidade comprada" },
                unidade_medida: { type: "string", description: "Unidade (KG, UN, CX, etc)" },
                valor_unitario: { type: "number", description: "Valor unitário do item" },
                valor_total: { type: "number", description: "Valor total do item" }
              },
              required: ["nome_produto", "quantidade", "valor_unitario"]
            }
          }
        },
        required: ["itens"]
      };

      const result = await base44.integrations.Core.ExtractDataFromUploadedFile({
        file_url: file_url,
        json_schema: schema
      });

      if (result.status === 'error') throw new Error(result.details || "Erro na análise");
      return result.output;
    },
    onSuccess: (data) => {
      setExtractedData(data);
      
      // Auto-match logic
      const mapping = (data.itens || []).map((item, idx) => {
        const normalizedName = (item.nome_produto || "").toLowerCase();
        // Tenta encontrar match exato ou parcial
        const match = produtos.find(p => 
            normalizedName.includes((p.nome || "").toLowerCase()) || 
            (p.nome || "").toLowerCase().includes(normalizedName)
        );
        return {
          index: idx,
          ...item,
          produto_id: match ? match.id : "new", // 'new' could mean "create new" or "ignore"
          ignore: !match
        };
      });
      
      setItemsMap(mapping);
      setStep('review');
    },
    onError: (err) => {
      toast.error("Falha ao analisar nota: " + err.message);
      setStep('upload');
    }
  });

  // Processar Entrada em Lote
  const processMutation = useMutation({
    mutationFn: async () => {
      // Agora processamos itens vinculados E novos (produto_id === "new")
      const itemsToProcess = itemsMap.filter(i => !i.ignore && i.produto_id);
      
      if (itemsToProcess.length === 0) throw new Error("Nenhum item selecionado para processar.");

      const promises = itemsToProcess.map(async (item) => {
        let produto = null;
        const qtd = parseFloat(item.quantidade);
        const custo = parseFloat(item.valor_unitario);
        
        // Lógica para Hortifruti (Baixa Direta / Custo Direto)
        // Tenta detectar por categoria (se prod existe) ou por nome (se novo)
        const keywordsHortifruti = ['tomate', 'alface', 'cebola', 'batata', 'cenoura', 'legume', 'fruta', 'verdura', 'banana', 'maca', 'limao', 'laranja', 'abacaxi', 'hortela', 'coentro', 'salsa', 'couve'];
        
        // 1. Identificar ou Criar Produto
        if (item.produto_id === "new") {
          // Gerar Código Único
          let codigoBase = (item.nome_produto || "PROD").toLowerCase()
            .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
            .replace(/[^a-z0-9]+/g, '-').toUpperCase();
            
          // Evitar duplicidade de código
          if (produtos.some(p => p.codigo === codigoBase)) {
             codigoBase = `${codigoBase}-${Math.floor(Math.random() * 1000)}`;
          }

          // Tentar categorizar automaticamente
          const isHortiName = keywordsHortifruti.some(k => (item.nome_produto || "").toLowerCase().includes(k));
          const categoria = isHortiName ? "Hortifruti" : "Outros";
          const unidade = (item.unidade_medida || "UN").toUpperCase().slice(0, 3); // Limit to common size

          produto = await base44.entities.Produto.create({
             organizacao_id: organizacao.id,
             nome: item.nome_produto,
             codigo: codigoBase,
             categoria: categoria,
             unidade: unidade,
             custo_unitario: custo,
             estoque_primario: 0,
             estoque_atual: 0,
             praca: "Geral",
             par_stock: 0
          });
        } else {
          produto = produtos.find(p => p.id === item.produto_id);
        }

        if (!produto) return;

        // 2. Definir Destino do Estoque (Hortifruti vs Geral)
        const isHortifruti = 
            ['hortifruti', 'vegetais', 'frutas', 'hortaliças', 'legumes'].includes((produto.categoria || "").toLowerCase()) ||
            keywordsHortifruti.some(k => (produto.nome || "").toLowerCase().includes(k));

        if (isHortifruti) {
             // BAIAXA DIRETA / ESTOQUE SECUNDÁRIO (COZINHA)
             // Entra direto na cozinha (estoque_atual) e não passa pelo primário
             const estoqueAnterior = produto.estoque_atual || 0;
             const novoEstoque = estoqueAnterior + qtd;

             await base44.entities.Produto.update(produto.id, {
                estoque_atual: novoEstoque,
                custo_unitario: custo
             });

             await base44.entities.HistoricoEstoque.create({
                organizacao_id: organizacao.id,
                tipo_item: "produto",
                item_id: produto.id,
                item_nome: produto.nome,
                movimento: "entrada",
                quantidade: qtd,
                estoque_anterior: estoqueAnterior,
                estoque_novo: novoEstoque,
                motivo: "compra",
                custo_unitario: custo,
                custo_total: item.valor_total || (qtd * custo),
                observacao: `Entrada Direta (Hortifruti) - Nota ${extractedData.numero_nota || ''}`,
                responsavel: "Sistema (Importação)",
                data_movimento: new Date().toISOString()
             });

        } else {
             // FLUXO PADRÃO: ESTOQUE PRIMÁRIO (ALMOXARIFADO)
             const estoqueAnterior = produto.estoque_primario || 0;
             const novoEstoque = estoqueAnterior + qtd;

             await base44.entities.Produto.update(produto.id, {
                estoque_primario: novoEstoque,
                custo_unitario: custo
             });

             await base44.entities.HistoricoEstoque.create({
                organizacao_id: organizacao.id,
                tipo_item: "produto",
                item_id: produto.id,
                item_nome: produto.nome,
                movimento: "entrada",
                quantidade: qtd,
                estoque_anterior: estoqueAnterior,
                estoque_novo: novoEstoque,
                motivo: "compra",
                custo_unitario: custo,
                custo_total: item.valor_total || (qtd * custo),
                observacao: `Imp. Nota ${extractedData.numero_nota || ''} - ${extractedData.fornecedor || ''}`,
                responsavel: "Sistema (Importação)",
                data_movimento: new Date().toISOString()
             });
        }
      });

      await Promise.all(promises);
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['produtos']);
      queryClient.invalidateQueries(['historico-estoque']);
      toast.success("Entrada em lote realizada com sucesso!");
      onClose();
    },
    onError: (err) => toast.error("Erro ao processar: " + err.message)
  });

  const handleFileChange = (e) => {
    const f = e.target.files[0];
    if (f) {
      setFile(f);
      setPreviewUrl(URL.createObjectURL(f));
    }
  };

  const handleAnalyze = () => {
    if (!file) return;
    setStep('analyzing');
    analyzeMutation.mutate(file);
  };

  const updateMapping = (index, field, value) => {
    const newMap = [...itemsMap];
    newMap[index] = { ...newMap[index], [field]: value };
    setItemsMap(newMap);
  };

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[800px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-indigo-700">
            <ScanLine className="w-5 h-5" />
            Importar Nota Fiscal (IA)
          </DialogTitle>
        </DialogHeader>

        {step === 'upload' && (
          <div className="py-8 flex flex-col items-center justify-center space-y-4 border-2 border-dashed border-gray-200 rounded-xl bg-gray-50">
            {previewUrl ? (
                <div className="relative w-full max-w-md h-64 rounded-lg overflow-hidden border border-gray-200">
                    <img src={previewUrl} alt="Preview" className="w-full h-full object-contain bg-black/5" />
                    <button 
                        onClick={() => { setFile(null); setPreviewUrl(null); }}
                        className="absolute top-2 right-2 bg-white/90 p-1 rounded-full shadow hover:bg-red-50 text-red-500"
                    >
                        <AlertCircle className="w-5 h-5" />
                    </button>
                </div>
            ) : (
                <>
                    <div className="w-16 h-16 bg-indigo-100 rounded-full flex items-center justify-center text-indigo-600">
                    <Camera className="w-8 h-8" />
                    </div>
                    <div className="text-center">
                    <h3 className="font-medium text-gray-900">Fotografe ou envie a nota</h3>
                    <p className="text-sm text-gray-500">Formatos: JPG, PNG, PDF</p>
                    </div>
                    <Input 
                        type="file" 
                        accept="image/*,application/pdf" 
                        className="hidden" 
                        id="file-upload"
                        onChange={handleFileChange}
                    />
                    <Button asChild variant="outline">
                    <label htmlFor="file-upload" className="cursor-pointer">
                        <Upload className="w-4 h-4 mr-2" />
                        Selecionar Arquivo
                    </label>
                    </Button>
                </>
            )}

            {file && (
                <Button 
                    onClick={handleAnalyze} 
                    className="mt-4 bg-indigo-600 hover:bg-indigo-700 text-white"
                >
                    Processar Nota Fiscal <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
            )}
          </div>
        )}

        {step === 'analyzing' && (
          <div className="py-16 flex flex-col items-center justify-center text-center space-y-4">
            <Loader2 className="w-12 h-12 text-indigo-600 animate-spin" />
            <div>
              <h3 className="text-lg font-medium text-gray-900">Analisando Nota Fiscal...</h3>
              <p className="text-gray-500">Nossa IA está lendo os itens, quantidades e valores.</p>
            </div>
          </div>
        )}

        {step === 'review' && (
          <div className="space-y-6">
            <div className="bg-indigo-50 p-4 rounded-lg border border-indigo-100 grid grid-cols-2 gap-4 text-sm">
                <div>
                    <span className="text-gray-500 block">Fornecedor Detectado</span>
                    <span className="font-medium text-indigo-900">{extractedData.fornecedor || "Não identificado"}</span>
                </div>
                <div>
                    <span className="text-gray-500 block">Número da Nota</span>
                    <span className="font-medium text-indigo-900">{extractedData.numero_nota || "Não identificado"}</span>
                </div>
            </div>

            <div className="space-y-2">
                <h4 className="font-medium text-gray-900 flex items-center justify-between">
                    Itens Detectados ({itemsMap.length})
                    <span className="text-xs font-normal text-gray-500">Vincule os itens aos produtos do sistema</span>
                </h4>
                
                <div className="border rounded-lg divide-y divide-gray-100 max-h-[400px] overflow-y-auto">
                    {itemsMap.map((item, idx) => (
                        <div key={idx} className={`p-3 flex flex-col md:flex-row gap-3 items-start md:items-center ${item.ignore ? 'bg-gray-50 opacity-75' : 'bg-white'}`}>
                            <div className="flex-1 min-w-0">
                                <p className="font-medium text-sm text-gray-900 truncate" title={item.nome_produto}>
                                    {item.nome_produto}
                                </p>
                                <p className="text-xs text-gray-500">
                                    {item.quantidade} {item.unidade_medida} x R$ {item.valor_unitario?.toFixed(2)} = <span className="font-semibold">R$ {item.valor_total?.toFixed(2)}</span>
                                </p>
                            </div>

                            <div className="flex items-center gap-2 w-full md:w-auto">
                                <Select 
                                    value={item.produto_id} 
                                    onValueChange={(v) => updateMapping(idx, 'produto_id', v)}
                                    disabled={item.ignore}
                                >
                                    <SelectTrigger className="w-[200px] h-8 text-xs">
                                        <SelectValue placeholder="Vincular Produto..." />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="new" className="text-green-600 font-medium">➕ Cadastrar Novo Produto</SelectItem>
                                        {produtos.map(p => (
                                            <SelectItem key={p.id} value={p.id}>{p.nome}</SelectItem>
                                        ))}
                                    </SelectContent>
                                </Select>

                                <Button
                                    variant="ghost"
                                    size="sm"
                                    onClick={() => updateMapping(idx, 'ignore', !item.ignore)}
                                    className={item.ignore ? "text-gray-400" : "text-green-600"}
                                    title={item.ignore ? "Ativar" : "Ignorar"}
                                >
                                    {item.ignore ? <AlertCircle className="w-4 h-4" /> : <CheckCircle2 className="w-4 h-4" />}
                                </Button>
                            </div>
                        </div>
                    ))}
                </div>
            </div>

            <DialogFooter className="gap-2">
                <Button variant="outline" onClick={() => setStep('upload')}>Voltar</Button>
                <Button 
                    onClick={() => processMutation.mutate()} 
                    disabled={processMutation.isPending || itemsMap.filter(i => !i.ignore && i.produto_id).length === 0}
                    className="bg-green-600 hover:bg-green-700 text-white"
                >
                    {processMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Save className="w-4 h-4 mr-2" />}
                    Processar Entrada ({itemsMap.filter(i => !i.ignore && i.produto_id).length} itens)
                </Button>
            </DialogFooter>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}