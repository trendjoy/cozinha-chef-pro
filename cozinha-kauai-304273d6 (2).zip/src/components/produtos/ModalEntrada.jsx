import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Search, PackagePlus, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { useOrganization } from "@/components/auth/OrganizationProvider";

export default function ModalEntrada({ onClose }) {
  const { organizacao } = useOrganization();
  const [step, setStep] = useState(1);
  const [busca, setBusca] = useState("");
  const [formData, setFormData] = useState({
    produto_id: "",
    quantidade: "",
    custo_unitario: "",
    nota_fiscal: "",
    fornecedor: "",
    observacao: ""
  });

  const queryClient = useQueryClient();

  const { data: produtos = [], isLoading } = useQuery({
    queryKey: ['produtos', organizacao?.id],
    queryFn: async () => {
      if (!organizacao?.id) return [];
      const res = await base44.entities.Produto.filter({ organizacao_id: organizacao.id }, undefined, 1000);
      return Array.isArray(res) ? res : [];
    },
    enabled: !!organizacao?.id,
  });

  const produtosFiltrados = produtos.filter(p => {
    const termo = busca.toLowerCase();
    return (p.nome || "").toLowerCase().includes(termo) || 
           (p.codigo || "").toLowerCase().includes(termo);
  }).slice(0, 50);

  const selectedProduto = produtos.find(p => p.id === formData.produto_id);

  const mutation = useMutation({
    mutationFn: async (data) => {
      if (!selectedProduto) throw new Error("Produto não selecionado");

      const qtd = parseFloat(data.quantidade);
      const custo = parseFloat(data.custo_unitario);
      const estoqueAnterior = selectedProduto.estoque_primario || 0;
      const novoEstoque = estoqueAnterior + qtd;
      const custoTotal = qtd * custo;

      // 1. Atualiza o produto (Estoque Primário + Custo Unitário)
      // Nota: Atualizar o custo unitário com o da nova entrada é o comportamento padrão simples.
      // Para média ponderada seria necessário mais cálculo, mas vamos manter simples/último preço.
      await base44.entities.Produto.update(selectedProduto.id, {
        estoque_primario: novoEstoque,
        custo_unitario: custo
      });

      // 2. Registra histórico
      await base44.entities.HistoricoEstoque.create({
        organizacao_id: organizacao.id,
        tipo_item: "produto",
        item_id: selectedProduto.id,
        item_nome: selectedProduto.nome,
        movimento: "entrada",
        quantidade: qtd,
        estoque_anterior: estoqueAnterior,
        estoque_novo: novoEstoque,
        motivo: "compra",
        custo_unitario: custo,
        custo_total: custoTotal,
        observacao: `NF: ${data.nota_fiscal} - Forn: ${data.fornecedor} ${data.observacao ? '- ' + data.observacao : ''}`,
        responsavel: "Sistema",
        data_movimento: new Date().toISOString()
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['produtos']);
      queryClient.invalidateQueries(['historico-estoque']);
      toast.success("Entrada registrada com sucesso!");
      onClose();
    },
    onError: () => {
      toast.error("Erro ao registrar entrada.");
    }
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.produto_id || !formData.quantidade || !formData.custo_unitario) {
      toast.error("Preencha os campos obrigatórios");
      return;
    }
    mutation.mutate(formData);
  };

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-green-700">
            <PackagePlus className="w-5 h-5" />
            Entrada de Mercadoria (Almoxarifado)
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4 py-2">
          
          <div className="space-y-2">
            <Label>Buscar Produto</Label>
            <div className="relative">
              <Search className="absolute left-2 top-2.5 h-4 w-4 text-gray-400" />
              <Input 
                placeholder="Nome ou código..." 
                value={busca}
                onChange={(e) => setBusca(e.target.value)}
                className="pl-8"
                autoFocus
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label>Selecione o Produto</Label>
            <Select 
              value={formData.produto_id} 
              onValueChange={(v) => {
                const prod = produtos.find(p => p.id === v);
                setFormData({
                    ...formData, 
                    produto_id: v, 
                    custo_unitario: prod?.custo_unitario || "" 
                });
              }}
            >
              <SelectTrigger>
                <SelectValue placeholder="Selecione..." />
              </SelectTrigger>
              <SelectContent>
                {isLoading ? (
                    <div className="p-2 flex justify-center"><Loader2 className="w-4 h-4 animate-spin" /></div>
                ) : produtosFiltrados.length === 0 ? (
                    <SelectItem value="none" disabled>Nenhum produto encontrado</SelectItem>
                ) : (
                    produtosFiltrados.map(p => (
                        <SelectItem key={p.id} value={p.id}>
                            {p.codigo ? `[${p.codigo}] ` : ''}{p.nome} 
                            <span className="text-gray-400 ml-2">
                                (Atual: {p.estoque_primario || 0} {p.unidade})
                            </span>
                        </SelectItem>
                    ))
                )}
              </SelectContent>
            </Select>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Quantidade Entrada ({selectedProduto?.unidade || 'un'})</Label>
              <Input 
                type="number" 
                step="0.001" 
                value={formData.quantidade}
                onChange={(e) => setFormData({...formData, quantidade: e.target.value})}
                placeholder="0.000"
                className="border-green-200 focus:border-green-500"
                required
              />
            </div>
            <div className="space-y-2">
              <Label>Custo Unitário (R$)</Label>
              <Input 
                type="number" 
                step="0.01" 
                value={formData.custo_unitario}
                onChange={(e) => setFormData({...formData, custo_unitario: e.target.value})}
                placeholder="0.00"
                className="border-green-200 focus:border-green-500"
                required
              />
            </div>
          </div>

          {formData.quantidade && formData.custo_unitario && (
              <div className="p-3 bg-green-50 rounded-lg border border-green-100 text-green-800 text-sm font-medium flex justify-between">
                  <span>Total da Entrada:</span>
                  <span>R$ {(parseFloat(formData.quantidade) * parseFloat(formData.custo_unitario)).toFixed(2)}</span>
              </div>
          )}

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Nota Fiscal / Recibo</Label>
              <Input 
                value={formData.nota_fiscal}
                onChange={(e) => setFormData({...formData, nota_fiscal: e.target.value})}
                placeholder="Opcional"
              />
            </div>
            <div className="space-y-2">
              <Label>Fornecedor</Label>
              <Input 
                value={formData.fornecedor}
                onChange={(e) => setFormData({...formData, fornecedor: e.target.value})}
                placeholder="Opcional"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label>Observação</Label>
            <Input 
                value={formData.observacao}
                onChange={(e) => setFormData({...formData, observacao: e.target.value})}
                placeholder="Detalhes adicionais..."
            />
          </div>

          <DialogFooter className="gap-2">
            <Button type="button" variant="outline" onClick={onClose}>Cancelar</Button>
            <Button 
                type="submit" 
                className="bg-green-600 hover:bg-green-700 text-white"
                disabled={mutation.isPending || !formData.produto_id}
            >
                {mutation.isPending ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <PackagePlus className="w-4 h-4 mr-2" />}
                Confirmar Entrada
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}