import React, { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Save, X } from "lucide-react";
import { useQueryClient, useMutation, useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";

const unidades = ["kg", "g", "L", "ml", "un", "pct", "cx", "dz"];
const pracas = ["CozinhaChefPro", "Delivery", "Eventos", "Geral"];

export default function ModalProduto({ produto, onClose, onSave, saving }) {
  const [formData, setFormData] = useState({
    nome: "",
    categoria: "Outros",
    unidade: "kg",
    praca: "Geral",
    estoque_atual: 0,
    par_stock: 0,
    custo_unitario: 0,
    estoque_primario: 0
  });

  const { data: categoriasData = [] } = useQuery({
    queryKey: ['categorias-produto'],
    queryFn: async () => {
      const res = await base44.entities.CategoriaProduto.list('nome');
      return Array.isArray(res) ? res : [];
    },
  });

  const categorias = categoriasData.length > 0 
    ? categoriasData.map(c => c.nome).sort() 
    : ["Outros"];

  useEffect(() => {
    if (produto) {
      setFormData(produto);
    }
  }, [produto]);

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSave(formData);
  };

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold text-gray-900">
            {produto ? 'Editar Produto' : 'Novo Produto'}
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="col-span-2">
              <Label>Nome do Produto *</Label>
              <Input
                value={formData.nome}
                onChange={(e) => handleChange('nome', e.target.value)}
                placeholder="Ex: Frango Orgânico"
                required
                className="border-orange-200 focus:border-orange-400"
              />
            </div>

            <div>
              <Label>Categoria</Label>
              <Select value={formData.categoria} onValueChange={(v) => handleChange('categoria', v)}>
                <SelectTrigger className="border-orange-200">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {categorias.map(cat => (
                    <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label>Unidade</Label>
              <Select value={formData.unidade} onValueChange={(v) => handleChange('unidade', v)}>
                <SelectTrigger className="border-orange-200">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {unidades.map(un => (
                    <SelectItem key={un} value={un}>{un}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label>Praça</Label>
              <Select value={formData.praca} onValueChange={(v) => handleChange('praca', v)}>
                <SelectTrigger className="border-orange-200">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {pracas.map(p => (
                    <SelectItem key={p} value={p}>{p}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label>Estoque Primário (Almoxarifado)</Label>
              <Input
                type="number"
                step="0.01"
                value={formData.estoque_primario || 0}
                onChange={(e) => handleChange('estoque_primario', parseFloat(e.target.value) || 0)}
                className="border-blue-200 focus:border-blue-400 bg-blue-50/50"
              />
            </div>

            <div>
              <Label>Estoque Secundário (Cozinha)</Label>
              <Input
                type="number"
                step="0.01"
                value={formData.estoque_atual}
                onChange={(e) => handleChange('estoque_atual', parseFloat(e.target.value) || 0)}
                className="border-orange-200 focus:border-orange-400"
              />
            </div>

            <div>
              <Label>Par-Stock (mínimo)</Label>
              <Input
                type="number"
                step="0.01"
                value={formData.par_stock}
                onChange={(e) => handleChange('par_stock', parseFloat(e.target.value) || 0)}
                className="border-orange-200 focus:border-orange-400"
              />
            </div>

            <div>
              <Label>Custo Unitário (R$)</Label>
              <Input
                type="number"
                step="0.01"
                value={formData.custo_unitario}
                onChange={(e) => handleChange('custo_unitario', parseFloat(e.target.value) || 0)}
                className="border-orange-200 focus:border-orange-400"
              />
            </div>
          </div>

          <DialogFooter className="gap-2">
            <Button type="button" variant="outline" onClick={onClose} disabled={saving}>
              <X className="w-4 h-4 mr-2" />
              Cancelar
            </Button>
            <Button 
              type="submit" 
              disabled={saving}
              className="bg-gradient-to-r from-orange-500 to-amber-600 hover:from-orange-600 hover:to-amber-700"
            >
              <Save className="w-4 h-4 mr-2" />
              {saving ? 'Salvando...' : 'Salvar'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}