import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Upload, CheckCircle2, AlertCircle, Loader2, Package, ArrowRight } from "lucide-react";
import { useOrganization } from "@/components/auth/OrganizationProvider";

export default function ModalImportarProdutos({ onClose, onSuccess }) {
  const { organizacao } = useOrganization();
  const [file, setFile] = useState(null);
  const [loading, setLoading] = useState(false);
  const [step, setStep] = useState("upload"); // upload, processing, review, saving
  const [extractedData, setExtractedData] = useState([]);
  const [error, setError] = useState(null);

  const handleFileChange = (e) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
      setError(null);
    }
  };

  const handleProcess = async () => {
    if (!file) return;
    
    setLoading(true);
    setError(null);
    setStep("processing");

    try {
      // 1. Upload File
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      
      // 2. Define Schema for Extraction
      const extractionSchema = {
        type: "object",
        properties: {
          produtos: {
            type: "array",
            items: {
              type: "object",
              properties: {
                codigo: { type: "string", description: "Código do produto" },
                nome: { type: "string", description: "Descrição/Nome do produto" },
                categoria: { type: "string", description: "Grupo ou Categoria (ex: Aves, Bovinos)" },
                unidade: { type: "string", description: "Unidade (Emb/Unid) - ex: KG, L, UN" },
                estoque_loja: { type: "number", description: "Quantidade em Loja/Cozinha (se houver)" },
                estoque_deposito: { type: "number", description: "Quantidade em Depósito (se houver)" }
              },
              required: ["nome"]
            },
            description: "Extraia a lista de produtos/insumos da tabela."
          }
        },
        required: ["produtos"]
      };

      // 3. Extract Data
      const result = await base44.integrations.Core.ExtractDataFromUploadedFile({
        file_url,
        json_schema: extractionSchema
      });

      if (result.status === "success" && result.output && result.output.produtos) {
        setExtractedData(result.output.produtos);
        setStep("review");
      } else {
        throw new Error(result.details || "Não foi possível identificar produtos neste arquivo.");
      }

    } catch (err) {
      console.error(err);
      setError(err.message || "Erro ao processar arquivo.");
      setStep("upload");
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    setLoading(true);
    setStep("saving");
    try {
      let importedCount = 0;
      
      // Process sequentially or parallel
      const promises = extractedData.map(async (item) => {
        // Normalize data
        const prodData = {
          nome: item.nome,
          codigo: item.codigo,
          categoria: item.categoria || "Outros",
          unidade: item.unidade || "un",
          estoque_atual: item.estoque_loja || 0,
          estoque_primario: item.estoque_deposito || 0,
          praca: "Geral", // default
          organizacao_id: organizacao.id
        };

        await base44.entities.Produto.create(prodData);
        importedCount++;
      });

      await Promise.all(promises);
      
      toast.success(`${importedCount} produtos importados com sucesso!`);
      onSuccess();
      onClose();
    } catch (err) {
      console.error(err);
      setError("Erro ao salvar produtos no banco.");
      setStep("review");
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Package className="w-6 h-6 text-orange-600" />
            Importar Produtos (IA)
          </DialogTitle>
          <DialogDescription>
            Envie uma foto da lista ou PDF. A IA identificará os itens automaticamente.
          </DialogDescription>
        </DialogHeader>

        <div className="py-4">
          {step === "upload" && (
            <div className="space-y-4">
              <div className="border-2 border-dashed border-orange-200 bg-orange-50/30 rounded-xl p-8 text-center hover:bg-orange-50 transition-colors">
                <Input
                  type="file"
                  accept=".pdf,.jpg,.jpeg,.png,.xlsx,.csv"
                  onChange={handleFileChange}
                  className="hidden"
                  id="file-upload-prod"
                />
                <Label htmlFor="file-upload-prod" className="cursor-pointer block">
                  <div className="flex flex-col items-center gap-3">
                    <div className="p-3 bg-orange-100 rounded-full text-orange-600">
                      <Upload className="w-6 h-6" />
                    </div>
                    <div className="text-sm font-medium text-gray-900">
                      {file ? file.name : "Clique para selecionar arquivo/foto"}
                    </div>
                    <div className="text-xs text-gray-500">
                      PDF, Imagem ou Excel
                    </div>
                  </div>
                </Label>
              </div>
              
              {error && (
                <Alert variant="destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertTitle>Erro</AlertTitle>
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}
            </div>
          )}

          {step === "processing" && (
            <div className="flex flex-col items-center justify-center py-8 space-y-4">
              <Loader2 className="w-10 h-10 text-orange-600 animate-spin" />
              <div className="text-center">
                <h3 className="font-semibold text-gray-900">Lendo Arquivo...</h3>
                <p className="text-sm text-gray-500">Identificando produtos e categorias.</p>
              </div>
            </div>
          )}

          {(step === "review" || step === "saving") && (
            <div className="space-y-4">
              <div className="bg-green-50 border border-green-200 rounded-lg p-4 flex items-start gap-3">
                <CheckCircle2 className="w-5 h-5 text-green-600 mt-0.5" />
                <div>
                  <h3 className="font-semibold text-green-800">{extractedData.length} produtos encontrados.</h3>
                  <p className="text-sm text-green-700 mt-1">
                    Confira abaixo antes de importar.
                  </p>
                </div>
              </div>

              <div className="max-h-[300px] overflow-y-auto border rounded-lg divide-y">
                {extractedData.map((item, idx) => (
                  <div key={idx} className="p-3 text-sm hover:bg-gray-50 flex justify-between items-center">
                    <div className="flex items-center gap-3">
                      <div className="bg-orange-100 p-2 rounded">
                        <Package className="w-4 h-4 text-orange-600" />
                      </div>
                      <div>
                        <div className="font-medium text-gray-900">{item.nome}</div>
                        <div className="text-xs text-gray-500 flex gap-2">
                          <span>Cod: {item.codigo || '-'}</span>
                          <span>•</span>
                          <span>{item.unidade}</span>
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-xs font-medium bg-gray-100 px-2 py-1 rounded inline-block">
                        {item.categoria}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        <DialogFooter>
          {step === "upload" && (
            <>
              <Button variant="outline" onClick={onClose}>Cancelar</Button>
              <Button 
                onClick={handleProcess} 
                disabled={!file || loading}
                className="bg-orange-600 hover:bg-orange-700 text-white"
              >
                Processar
              </Button>
            </>
          )}
          
          {(step === "review" || step === "saving") && (
            <>
              <Button variant="outline" onClick={() => setStep("upload")} disabled={loading}>Voltar</Button>
              <Button 
                onClick={handleSave} 
                disabled={loading}
                className="bg-green-600 hover:bg-green-700 text-white gap-2"
              >
                {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <ArrowRight className="w-4 h-4" />}
                Confirmar Importação
              </Button>
            </>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}