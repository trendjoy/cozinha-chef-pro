import React, { useState } from "react";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Pencil, Trash2, AlertTriangle } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Checkbox } from "@/components/ui/checkbox";

export default function TabelaProdutos({ produtos, loading, onEdit, onDelete, onBulkDelete, mode = 'todos' }) {
  const [selectedIds, setSelectedIds] = useState([]);

  const toggleSelectAll = () => {
    if (selectedIds.length === produtos.length) {
      setSelectedIds([]);
    } else {
      setSelectedIds(produtos.map(p => p.id));
    }
  };

  const toggleSelect = (id) => {
    if (selectedIds.includes(id)) {
      setSelectedIds(selectedIds.filter(i => i !== id));
    } else {
      setSelectedIds([...selectedIds, id]);
    }
  };

  if (loading) {
    return (
      <div className="bg-white rounded-xl border border-orange-200/50 shadow-lg overflow-hidden">
        <div className="p-6 space-y-3">
          {Array(8).fill(0).map((_, i) => (
            <Skeleton key={i} className="h-12 w-full" />
          ))}
        </div>
      </div>
    );
  }

  if (produtos.length === 0) {
    return (
      <div className="bg-white rounded-xl border border-orange-200/50 shadow-lg p-12 text-center">
        <p className="text-gray-500">Nenhum produto encontrado</p>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl border border-orange-200/50 shadow-lg overflow-hidden relative">
      {selectedIds.length > 0 && (
        <div className="absolute top-0 left-0 right-0 bg-orange-100 p-2 flex justify-between items-center px-4 z-20 border-b border-orange-200 animate-in slide-in-from-top-2 fade-in duration-200">
            <div className="flex items-center gap-2">
                <span className="bg-orange-200 text-orange-800 text-xs font-bold px-2 py-1 rounded-full">{selectedIds.length}</span>
                <span className="text-orange-800 font-medium text-sm">itens selecionados</span>
            </div>
            <Button 
                variant="destructive" 
                size="sm" 
                onClick={() => {
                    if(onBulkDelete) {
                        onBulkDelete(selectedIds);
                        setSelectedIds([]);
                    }
                }}
                className="h-8 shadow-sm"
            >
                <Trash2 className="w-4 h-4 mr-2" />
                Excluir Selecionados
            </Button>
        </div>
      )}

      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow className="bg-gradient-to-r from-orange-50 to-amber-50 border-b border-orange-200">
              <TableHead className="w-[40px] pl-4">
                  <Checkbox 
                    checked={produtos.length > 0 && selectedIds.length === produtos.length}
                    onCheckedChange={toggleSelectAll}
                    className="border-orange-400 data-[state=checked]:bg-orange-600 data-[state=checked]:text-white"
                  />
              </TableHead>
              <TableHead className="font-semibold">Código</TableHead>
              <TableHead className="font-semibold">Nome</TableHead>
              <TableHead className="font-semibold">Categoria</TableHead>
              {(mode === 'todos' || mode === 'primario') && (
                <TableHead className="font-semibold text-blue-700">Estoque Primário</TableHead>
              )}
              {(mode === 'todos' || mode === 'secundario') && (
                <TableHead className="font-semibold text-orange-700">Estoque Secundário</TableHead>
              )}
              <TableHead className="font-semibold">Par-Stock</TableHead>
              <TableHead className="font-semibold">Status</TableHead>
              <TableHead className="font-semibold">Custo Unit.</TableHead>
              <TableHead className="font-semibold text-right">Ações</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {produtos.map((produto) => {
              const estoqueBaixo = produto.estoque_atual < produto.par_stock && produto.par_stock > 0;
              const isSelected = selectedIds.includes(produto.id);
              
              return (
                <TableRow 
                    key={produto.id} 
                    className={`transition-colors ${isSelected ? 'bg-orange-50 hover:bg-orange-100' : 'hover:bg-orange-50/50'}`}
                >
                  <TableCell className="pl-4">
                    <Checkbox 
                        checked={isSelected}
                        onCheckedChange={() => toggleSelect(produto.id)}
                        className="border-gray-300 data-[state=checked]:bg-orange-600 data-[state=checked]:text-white"
                    />
                  </TableCell>
                  <TableCell>
                    <code className="text-xs bg-gray-100 px-2 py-1 rounded">
                      {produto.codigo}
                    </code>
                  </TableCell>
                  <TableCell className="font-medium">{produto.nome}</TableCell>
                  <TableCell>
                    <Badge variant="outline" className="bg-orange-50 text-orange-700 border-orange-200">
                      {produto.categoria}
                    </Badge>
                  </TableCell>
                  {(mode === 'todos' || mode === 'primario') && (
                    <TableCell className="bg-blue-50/30 font-medium text-blue-900">
                      {produto.estoque_primario || 0} {produto.unidade}
                    </TableCell>
                  )}
                  {(mode === 'todos' || mode === 'secundario') && (
                    <TableCell className="bg-orange-50/30 font-medium text-orange-900">
                      {produto.estoque_atual} {produto.unidade}
                    </TableCell>
                  )}
                  <TableCell>
                    {produto.par_stock} {produto.unidade}
                  </TableCell>
                  <TableCell>
                    {estoqueBaixo ? (
                      <Badge variant="destructive" className="gap-1">
                        <AlertTriangle className="w-3 h-3" />
                        Baixo
                      </Badge>
                    ) : (
                      <Badge className="bg-green-600 gap-1">
                        ✓ OK
                      </Badge>
                    )}
                  </TableCell>
                  <TableCell>
                    R$ {produto.custo_unitario?.toFixed(2) || '0.00'}
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-2">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => onEdit(produto)}
                        className="hover:bg-orange-100"
                      >
                        <Pencil className="w-4 h-4 text-orange-600" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => onDelete(produto.id)}
                        className="hover:bg-red-100"
                      >
                        <Trash2 className="w-4 h-4 text-red-600" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}