import React, { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Upload, FileText, CheckCircle, AlertCircle } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { Alert, AlertDescription } from "@/components/ui/alert";

export default function ModalImportCSV({ onClose, onSuccess }) {
  const [arquivo, setArquivo] = useState(null);
  const [processando, setProcessando] = useState(false);
  const [resultado, setResultado] = useState(null);

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file && file.type === 'text/csv') {
      setArquivo(file);
      setResultado(null);
    } else {
      alert('Por favor, selecione um arquivo CSV válido');
    }
  };

  const handleImport = async () => {
    if (!arquivo) return;

    setProcessando(true);
    setResultado(null);

    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file: arquivo });
      
      const schema = await base44.entities.Produto.schema();
      
      const response = await base44.integrations.Core.ExtractDataFromUploadedFile({
        file_url,
        json_schema: {
          type: "object",
          properties: {
            produtos: {
              type: "array",
              items: schema
            }
          }
        }
      });

      if (response.status === 'success' && response.output?.produtos) {
        const produtos = response.output.produtos;
        
        const produtosComCodigo = produtos.map(p => ({
          ...p,
          codigo: p.codigo || p.nome
            ?.toLowerCase()
            .normalize('NFD')
            .replace(/[\u0300-\u036f]/g, '')
            .replace(/[^a-z0-9]+/g, '-')
            .replace(/^-+|-+$/g, '')
            .toUpperCase() || 'PRODUTO',
          categoria: p.categoria || 'Outros',
          praca: p.praca || 'Geral',
          unidade: p.unidade || 'un',
          estoque_atual: p.estoque_atual || 0,
          par_stock: p.par_stock || 0,
          custo_unitario: p.custo_unitario || 0,
        }));

        await base44.entities.Produto.bulkCreate(produtosComCodigo);

        setResultado({
          tipo: 'success',
          mensagem: `${produtosComCodigo.length} produtos importados com sucesso!`
        });

        setTimeout(() => {
          onSuccess();
        }, 2000);
      } else {
        throw new Error('Erro ao processar arquivo CSV');
      }
    } catch (error) {
      console.error('Erro na importação:', error);
      setResultado({
        tipo: 'error',
        mensagem: 'Erro ao importar arquivo. Verifique o formato do CSV.'
      });
    }

    setProcessando(false);
  };

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold">Importar Produtos via CSV</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <Alert>
            <FileText className="h-4 w-4" />
            <AlertDescription className="text-sm">
              O arquivo CSV deve conter as colunas: nome, categoria, unidade, praca, estoque_atual, par_stock, custo_unitario
            </AlertDescription>
          </Alert>

          <div className="border-2 border-dashed border-orange-300 rounded-lg p-8 text-center">
            <input
              type="file"
              accept=".csv"
              onChange={handleFileChange}
              className="hidden"
              id="csv-upload"
            />
            <label htmlFor="csv-upload" className="cursor-pointer">
              <Upload className="w-12 h-12 mx-auto text-orange-500 mb-3" />
              <p className="text-sm font-medium text-gray-700">
                {arquivo ? arquivo.name : 'Clique para selecionar arquivo CSV'}
              </p>
              <p className="text-xs text-gray-500 mt-1">
                Formato: .csv
              </p>
            </label>
          </div>

          {resultado && (
            <Alert variant={resultado.tipo === 'success' ? 'default' : 'destructive'}>
              {resultado.tipo === 'success' ? (
                <CheckCircle className="h-4 w-4" />
              ) : (
                <AlertCircle className="h-4 w-4" />
              )}
              <AlertDescription>{resultado.mensagem}</AlertDescription>
            </Alert>
          )}

          <div className="flex justify-end gap-3">
            <Button variant="outline" onClick={onClose} disabled={processando}>
              Cancelar
            </Button>
            <Button
              onClick={handleImport}
              disabled={!arquivo || processando}
              className="bg-gradient-to-r from-orange-500 to-amber-600 hover:from-orange-600 hover:to-amber-700"
            >
              {processando ? 'Importando...' : 'Importar'}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}